// RoScout window — the RoScout dashboard as a window on roblox.com, so you never leave Roblox.
// • Adds "RoScout" to Roblox's left sidebar and top bar (cloned from Roblox's own items).
// • Window states: open (floating, drag + resize), max (fills the page below Roblox's header,
//   next to the sidebar), min (a small pill), closed. Remembered per tab across page loads.
// • Open it from anywhere with a link to #roscout or #roscout-<tab>, e.g. /home#roscout-communities.
(() => {
  const TABS = ['compare', 'rising', 'rivals', 'heatmap', 'friends', 'requests', 'communities', 'appearance', 'export'];
  const KEY = 'roscout:win';
  const EXT_ORIGIN = new URL(chrome.runtime.getURL('')).origin;
  const LOGO = '<svg class="rsw-logo" viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="13" width="4" height="7" rx="1" opacity=".55"/><rect x="10" y="8.5" width="4" height="11.5" rx="1" opacity=".8"/><rect x="16" y="4" width="4" height="16" rx="1"/></svg>';
  const ICO = {
    min: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 12h12"/></svg>',
    max: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="5" width="14" height="14" rx="2"/></svg>',
    restore: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="8" width="11" height="11" rx="2"/><path d="M9 8V6.5A1.5 1.5 0 0 1 10.5 5H17.5A1.5 1.5 0 0 1 19 6.5V13.5A1.5 1.5 0 0 1 17.5 15H16"/></svg>',
    close: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>',
    pop: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 4h6v6M20 4l-9 9"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>',
  };

  let st = { state: 'closed', tab: 'compare', rect: null };
  try { st = { ...st, ...JSON.parse(sessionStorage.getItem(KEY) || '{}') }; } catch {}
  const save = () => { try { sessionStorage.setItem(KEY, JSON.stringify(st)); } catch {} };

  let win = null, frame = null, pill = null;

  // ---- layout helpers ---------------------------------------------------------
  function headerBottom() {
    const h = document.querySelector('#header.navbar-fixed-top, #header, .rbx-header');
    const b = h?.getBoundingClientRect().bottom;
    return b > 0 && b < 200 ? b : 40;
  }
  function sidebarRight() {
    const nav = document.querySelector('.left-nav');
    if (!nav) return 0;
    const cs = getComputedStyle(nav), r = nav.getBoundingClientRect();
    return cs.visibility !== 'hidden' && r.right > 0 && r.width > 0 ? r.right : 0;
  }
  function defaultRect() {
    const top = headerBottom() + 16, left = Math.max(sidebarRight() + 16, 16);
    const w = Math.min(1180, innerWidth - left - 16), h = Math.min(780, innerHeight - top - 16);
    return { x: Math.max(left, Math.round((innerWidth - w + left - 16) / 2)), y: top, w, h };
  }
  function clampRect(r) {
    const minW = 420, minH = 320, top = headerBottom();
    const w = Math.min(Math.max(r.w, minW), innerWidth - 8), h = Math.min(Math.max(r.h, minH), innerHeight - top - 8);
    return { w, h, x: Math.min(Math.max(r.x, 0), innerWidth - w), y: Math.min(Math.max(r.y, top), innerHeight - h) };
  }

  // ---- window -----------------------------------------------------------------
  function build() {
    if (win) return;
    win = document.createElement('section');
    win.id = 'rsw';
    win.setAttribute('role', 'dialog');
    win.setAttribute('aria-label', 'RoScout');
    win.innerHTML = `
      <header class="rsw-bar">
        <div class="rsw-title">${LOGO}<b>RoScout</b><span class="rsw-tab"></span></div>
        <div class="rsw-btns">
          <button class="rsw-btn" data-w="pop" title="Open in its own browser tab" aria-label="Open in its own browser tab">${ICO.pop}</button>
          <button class="rsw-btn" data-w="min" title="Minimize" aria-label="Minimize">${ICO.min}</button>
          <button class="rsw-btn" data-w="max" title="Maximize" aria-label="Maximize">${ICO.max}</button>
          <button class="rsw-btn rsw-close" data-w="close" title="Close (Esc)" aria-label="Close">${ICO.close}</button>
        </div>
      </header>
      <div class="rsw-body"><iframe class="rsw-frame" title="RoScout dashboard" allow="clipboard-write"></iframe><div class="rsw-shield"></div></div>
      <div class="rsw-grip" aria-hidden="true"></div>`;
    frame = win.querySelector('iframe');
    document.documentElement.appendChild(win);

    win.addEventListener('click', (e) => {
      const b = e.target.closest('[data-w]');
      if (!b) return;
      const act = b.dataset.w;
      if (act === 'close') setState('closed');
      if (act === 'min') setState('min');
      if (act === 'max') setState(st.state === 'max' ? 'open' : 'max');
      if (act === 'pop') { window.open(chrome.runtime.getURL(`dashboard.html#${st.tab}`), '_blank'); }
    });
    win.querySelector('.rsw-bar').addEventListener('dblclick', (e) => { if (!e.target.closest('[data-w]')) setState(st.state === 'max' ? 'open' : 'max'); });
    dragging(win.querySelector('.rsw-bar'), 'move');
    dragging(win.querySelector('.rsw-grip'), 'resize');

    pill = document.createElement('button');
    pill.id = 'rsw-pill';
    pill.innerHTML = `${LOGO}<span>RoScout</span>`;
    pill.title = 'Open RoScout';
    pill.addEventListener('click', () => setState(st.prev === 'max' ? 'max' : 'open'));
    document.documentElement.appendChild(pill);
  }

  function dragging(handle, mode) {
    handle.addEventListener('pointerdown', (e) => {
      if (e.button !== 0 || e.target.closest('[data-w]') || st.state !== 'open') return;
      e.preventDefault();
      handle.setPointerCapture(e.pointerId);
      const start = { x: e.clientX, y: e.clientY, r: { ...st.rect } };
      win.classList.add('rsw-dragging');
      const move = (ev) => {
        const dx = ev.clientX - start.x, dy = ev.clientY - start.y;
        st.rect = clampRect(mode === 'move'
          ? { ...start.r, x: start.r.x + dx, y: start.r.y + dy }
          : { ...start.r, w: start.r.w + dx, h: start.r.h + dy });
        place();
      };
      const up = () => {
        handle.removeEventListener('pointermove', move);
        handle.removeEventListener('pointerup', up);
        handle.removeEventListener('pointercancel', up);
        win.classList.remove('rsw-dragging');
        save();
      };
      handle.addEventListener('pointermove', move);
      handle.addEventListener('pointerup', up);
      handle.addEventListener('pointercancel', up);
    });
  }

  function place() {
    if (!win) return;
    if (st.state === 'max') {
      const top = headerBottom(), left = sidebarRight();
      Object.assign(win.style, { left: `${left}px`, top: `${top}px`, width: `${innerWidth - left}px`, height: `${innerHeight - top}px` });
    } else if (st.state === 'open') {
      st.rect = clampRect(st.rect || defaultRect());
      Object.assign(win.style, { left: `${st.rect.x}px`, top: `${st.rect.y}px`, width: `${st.rect.w}px`, height: `${st.rect.h}px` });
    }
  }

  function setState(next, tab) {
    if (tab && TABS.includes(tab)) st.tab = tab;
    if (next === 'min' && st.state !== 'min') st.prev = st.state;
    st.state = next;
    save();
    render();
  }

  function render() {
    if (st.state === 'closed') {
      win?.classList.add('rsw-hidden'); pill?.classList.add('rsw-hidden');
      markActive(false);
      return;
    }
    build();
    const want = chrome.runtime.getURL(`dashboard.html?embed=1#${st.tab}`);
    if (!frame.src) frame.src = want;
    else if (!frame.src.endsWith(`#${st.tab}`) && frame.dataset.tab !== st.tab) frame.contentWindow?.postMessage({ rs: 'go', tab: st.tab }, EXT_ORIGIN);
    frame.dataset.tab = st.tab;
    win.querySelector('.rsw-tab').textContent = TAB_LABEL[st.tab] || '';
    const maxBtn = win.querySelector('[data-w="max"]');
    maxBtn.innerHTML = st.state === 'max' ? ICO.restore : ICO.max;
    maxBtn.title = st.state === 'max' ? 'Restore' : 'Maximize';
    win.classList.toggle('rsw-hidden', st.state === 'min');
    win.classList.toggle('rsw-max', st.state === 'max');
    pill.classList.toggle('rsw-hidden', st.state !== 'min');
    place();
    markActive(st.state !== 'min');
  }

  const TAB_LABEL = { compare: 'Compare', rising: 'Rising games', rivals: 'Rivals', heatmap: 'Best times', friends: 'Friends are playing', requests: 'Friend requests', communities: 'My communities', appearance: 'Appearance', export: 'Export' };

  // ---- messages from the dashboard inside the window --------------------------------
  window.addEventListener('message', (e) => {
    if (e.origin !== EXT_ORIGIN || !e.data?.rs) return;
    if (e.data.rs === 'tab' && TABS.includes(e.data.tab)) {
      st.tab = e.data.tab; save();
      if (frame) frame.dataset.tab = st.tab;
      const t = win?.querySelector('.rsw-tab'); if (t) t.textContent = TAB_LABEL[st.tab] || '';
    }
    if (e.data.rs === 'nav' && /^https:\/\/www\.roblox\.com\//.test(e.data.url || '')) {
      // Going to a Roblox page: shrink RoScout to its pill so the page is visible.
      setState('min');
      location.href = e.data.url;
    }
  });

  // ---- public API for other RoScout scripts -------------------------------------
  globalThis.RSWin = {
    open: (tab) => setState(st.state === 'max' ? 'max' : 'open', tab),
    toggle: () => setState(st.state === 'closed' || st.state === 'min' ? (st.prev === 'max' ? 'max' : 'open') : 'closed'),
  };
  chrome.runtime.onMessage.addListener((msg) => { if (msg?.type === 'rs-open-window') globalThis.RSWin.open(msg.tab); });

  // ---- entries in Roblox's sidebar and top bar ------------------------------------
  function markActive(on) {
    document.querySelectorAll('.rsw-entry').forEach((a) => a.classList.toggle('rsw-on', on));
  }

  function sidebarEntry() {
    const nav = document.querySelector('.left-nav');
    if (!nav || nav.querySelector('.rsw-entry')) return;
    const links = [...nav.querySelectorAll('li > a')];
    const ref = links.find((a) => a.textContent.trim() === 'Communities') || links.find((a) => a.textContent.trim() === 'Trade') || links.at(-1);
    const li = ref?.closest('li');
    if (!li) return;
    const clone = li.cloneNode(true);
    const a = clone.querySelector('a');
    a.removeAttribute('id');
    a.href = '#roscout';
    a.classList.add('rsw-entry', 'rsw-side');
    const label = [...a.querySelectorAll('span')].find((s) => s.textContent.trim() === ref.textContent.trim());
    if (label) label.textContent = 'RoScout'; else a.append('RoScout');
    const iconWrap = a.querySelector('span .icon')?.parentElement || a.querySelector('span');
    if (iconWrap) iconWrap.innerHTML = LOGO;
    a.addEventListener('click', (e) => { e.preventDefault(); globalThis.RSWin.toggle(); });
    li.insertAdjacentElement('afterend', clone);
    markActive(st.state === 'open' || st.state === 'max');
  }

  function topEntry() {
    if (document.querySelector('.rsw-top')) return;
    const charts = document.querySelector('#nav-charts-md-link') || [...document.querySelectorAll('ul.rbx-navbar a')].find((a) => a.textContent.trim() === 'Charts');
    const li = charts?.closest('li');
    const ul = li?.parentElement;
    if (!li || !ul) return;
    const clone = li.cloneNode(true);
    const a = clone.querySelector('a');
    a.id = 'nav-roscout-link';
    a.href = '#roscout';
    a.textContent = 'RoScout';
    a.classList.add('rsw-entry', 'rsw-top');
    a.addEventListener('click', (e) => { e.preventDefault(); globalThis.RSWin.toggle(); });
    ul.appendChild(clone);
    ul.classList.add('rsw-navbar');
  }

  // ---- startup ------------------------------------------------------------------
  function fromHash() {
    const m = location.hash.match(/^#roscout(?:-([a-z]+))?$/i);
    if (!m) return;
    setState(st.state === 'max' ? 'max' : 'open', m[1]?.toLowerCase());
    history.replaceState(null, '', location.pathname + location.search);
  }

  addEventListener('keydown', (e) => { if (e.key === 'Escape' && (st.state === 'open' || st.state === 'max')) setState('min'); });
  addEventListener('resize', () => { if (st.state === 'open' || st.state === 'max') place(); });
  addEventListener('hashchange', fromHash);

  function boot() {
    sidebarEntry(); topEntry();
    if (st.state !== 'closed') render();
    fromHash();
    // Roblox re-renders its nav; keep our entries in place.
    let pending = false;
    new MutationObserver(() => {
      if (pending) return;
      pending = true;
      requestAnimationFrame(() => { pending = false; sidebarEntry(); topEntry(); });
    }).observe(document.body, { childList: true, subtree: true });
    // the sidebar can slide in/out on narrow screens
    setInterval(() => { if (st.state === 'max') place(); }, 1000);
  }
  if (document.body) boot(); else addEventListener('DOMContentLoaded', boot, { once: true });
})();
