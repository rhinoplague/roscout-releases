// RoScout background: shared player history.
// The RoScout robot (collector/collect.mjs in the public roscout-releases repo, run by GitHub
// every 30 minutes) records player counts for every game on Roblox's top lists and keeps following
// each one for 30 days. Every RoScout install reads the same files, so a game's history is there
// even if you never tracked it yourself.

const SHARED_BASE = 'https://raw.githubusercontent.com/rhinoplague/roscout-releases/data';
const SHARED_SLOT = 30 * 60e3;
const SHARED_BUCKETS = 64;
const sharedMemo = new Map();

// Fetch one shared file; hist/ files are also kept in storage because they only change once a day.
async function sharedFile(file, ttl, { persist = false } = {}) {
  const key = `sh:${file}`;
  const now = Date.now();
  const m = sharedMemo.get(key);
  if (m && now - m.t < ttl) return m.v;
  if (persist) {
    const st = (await chrome.storage.local.get(key))[key];
    if (st && now - st.t < ttl) { sharedMemo.set(key, st); return st.v; }
  }
  try {
    const r = await fetch(`${SHARED_BASE}/${file}`, { cache: 'no-cache' });
    if (r.status === 404) throw new Error('not recorded yet');
    if (!r.ok) throw new Error(`shared data ${r.status}`);
    const v = await r.json();
    const e = { t: now, v };
    sharedMemo.set(key, e);
    if (persist) await chrome.storage.local.set({ [key]: e });
    return v;
  } catch (err) {
    if (m) return m.v; // stale beats nothing
    throw err;
  }
}

// [[time, players], …] oldest first: hourly further back, every 30 minutes for the last ~3 days
async function sharedHistory(universeId) {
  const id = Number(universeId);
  const b = id % SHARED_BUCKETS;
  // hourly history lives in one file per month: this month and last month cover 30+ days
  const d = new Date();
  const months = [new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - 1, 1)), new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1))]
    .map((x) => x.toISOString().slice(0, 7));
  const [rec, ...hists] = await Promise.all([
    sharedFile(`recent/${b}.json`, 15 * 60e3).catch(() => null),
    ...months.map((m, i) => sharedFile(`hist/${m}/${b}.json`, i ? 6 * 36e5 : 7 * 864e5, { persist: true }).catch(() => null)),
  ]);
  const pts = [];
  const recentFrom = rec?.g?.[id] ? rec.s * SHARED_SLOT : Infinity;
  for (const hist of hists) {
    if (!hist?.g?.[id]) continue;
    hist.g[id].forEach((v, i) => {
      const t = (hist.s + i) * 36e5 + 18e5;
      if (v != null && t < recentFrom) pts.push([t, v]);
    });
  }
  if (rec?.g?.[id]) rec.g[id].forEach((v, i) => { if (v != null) pts.push([(rec.s + i) * SHARED_SLOT, v]); });
  return pts;
}

// shared points where we don't have our own within 20 minutes
function mergeShared(local, shared) {
  if (!shared?.length) return local.map((p) => [p[0], p[1]]);
  const own = local.map((p) => [p[0], p[1]]);
  const times = own.map((p) => p[0]);
  const near = (t) => {
    let lo = 0, hi = times.length - 1;
    while (lo <= hi) { const mid = (lo + hi) >> 1; if (Math.abs(times[mid] - t) <= 20 * 60e3) return true; if (times[mid] < t) lo = mid + 1; else hi = mid - 1; }
    return false;
  };
  const out = own.concat(shared.filter((p) => !near(p[0])));
  return out.sort((a, b) => a[0] - b[0]);
}

const hmSamples = (hm) => (hm || []).reduce((n, b) => n + (b?.[1] || 0), 0);

// Called by getStats: shared history plus days/heatmap filled in from it.
async function withShared(universeId, rec) {
  let shared = [];
  try {
    shared = await Promise.race([sharedHistory(universeId), new Promise((r) => setTimeout(() => r([]), 3000))]);
  } catch {}
  if (!shared.length) return { shared: [], days: rec.days, hm: rec.hm };
  const merged = mergeShared(rec.history || [], shared);
  const days = buildDays(merged);
  for (const [k, v] of Object.entries(rec.days || {})) if (v[1] >= (days[k]?.[1] || 0)) days[k] = v; // our own data wins when it covers more
  const hm = hmSamples(rec.hm) >= 7 * 24 ? rec.hm : buildHm(merged);
  return { shared, days, hm };
}

handlers.sharedTop = async () => sharedFile('top.json', 5 * 60e3);
handlers.sharedHistory = async ({ universeId }) => ({ points: await sharedHistory(universeId) });

// live player counts for the Charts page (no cache, max 100 ids)
handlers.liveCounts = async ({ ids }) => {
  const list = (ids || []).map(Number).filter(Boolean).slice(0, 100);
  const out = {};
  for (const c of chunk(list, 50)) {
    try {
      const d = await getJSON(API.games(c));
      for (const g of d.data || []) out[g.id] = g.playing ?? null;
    } catch {}
  }
  return { t: Date.now(), counts: out };
};

// Charts page fallback before the robot has published anything: Roblox's own "Top Playing Now" list
handlers.liveTop = async () => {
  const r = await getJSON(`https://apis.roblox.com/explore-api/v1/get-sorts?sessionId=${crypto.randomUUID()}&device=computer&country=all`);
  const sort = (r.sorts || []).find((s) => s.sortId === 'top-playing-now') || (r.sorts || []).find((s) => (s.games || []).length);
  if (!sort) throw new Error('Roblox returned no charts');
  const now = Date.now();
  return {
    updated: now, s: Math.floor(now / SHARED_SLOT), slotMs: SHARED_SLOT, fallback: true,
    list: sort.games.filter((g) => !g.isSponsored).slice(0, 100).map((g, i) => ({
      id: g.universeId, rank: i + 1, n: g.name, p: g.rootPlaceId, g: g.genreL1 || '', c: g.creatorName || '', v: g.playerCount, d: [],
    })),
  };
};

handlers.gameIcons = async ({ ids }) => iconMap('game', (ids || []).map(Number).filter(Boolean).slice(0, 120));

// drop saved shared-history months we no longer read
chrome.runtime.onStartup.addListener(async () => {
  const all = await chrome.storage.local.get(null);
  const d = new Date();
  const keep = [0, 1].map((k) => new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - k, 1)).toISOString().slice(0, 7));
  const old = Object.keys(all).filter((k) => k.startsWith('sh:hist/') && !keep.some((m) => k.startsWith(`sh:hist/${m}/`)));
  if (old.length) await chrome.storage.local.remove(old);
});
