// RoScout: runs in the page itself (MAIN world) so it can see Roblox's own requests.
// It only watches for one thing: a friend request you send. When Roblox confirms it,
// the user id is handed to RoScout (bridge in appearance.js) so it can track the request.
(() => {
  const RE = /\/\/friends\.roblox\.com\/v1\/users\/(\d+)\/request-friendship/i;
  const tell = (id) => window.postMessage({ __roscout: 'friendReq', userId: Number(id) }, location.origin);

  const open = XMLHttpRequest.prototype.open;
  const send = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url) {
    this.__rsReq = /^post$/i.test(method) ? RE.exec(String(url)) : null;
    return open.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function () {
    const m = this.__rsReq;
    if (m) this.addEventListener('load', () => { if (this.status >= 200 && this.status < 300) tell(m[1]); });
    return send.apply(this, arguments);
  };

  const f = window.fetch;
  window.fetch = function (input, init) {
    const url = typeof input === 'string' ? input : input instanceof URL ? input.href : input?.url || '';
    const method = (init?.method || (typeof input === 'object' && input?.method) || 'GET');
    const m = /^post$/i.test(method) ? RE.exec(url) : null;
    const p = f.apply(this, arguments);
    if (m) p.then((r) => { if (r.ok) tell(m[1]); }, () => {});
    return p;
  };
})();
