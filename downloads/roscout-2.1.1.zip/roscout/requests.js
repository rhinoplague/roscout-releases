// RoScout: friend requests you sent, where you'll see them on roblox.com.
// - Profile pages: a banner when you already have a request waiting with this person.
// - Your Friends page: a bar with how many requests you have waiting, linking to the full list.
(() => {
  const { esc, ago, send, icon } = globalThis.RS;
  const PROFILE_RE = /^\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?users\/(\d+)\/profile/i;
  const FRIENDS_RE = /^\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?users\/(?:(\d+)\/)?friends/i;
  const me = () => Number(document.querySelector('meta[name="user-data"]')?.dataset.userid) || null;

  // remember which account is yours on every page, not just the home page
  try { const id = me(); if (id > 0) chrome.storage.local.get('myUserId').then((r) => { if (r.myUserId !== id) chrome.storage.local.set({ myUserId: id }); }); } catch {}

  let banner = null, bannerFor = null, bar = null, pending = 0;
  const countPending = (r) => Object.values(r || {}).filter((x) => x.status === 'pending').length;
  chrome.storage.local.get('sentReqs').then(({ sentReqs }) => { pending = countPending(sentReqs); paintBar(); });
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === 'local' && ch.sentReqs) { pending = countPending(ch.sentReqs.newValue); paintBar(); }
  });

  // ---- profile banner ------------------------------------------------------------------
  const profileAnchor = () => document.querySelector('.profile-header') || document.querySelector('[data-testid="profile-header"]')
    || document.querySelector('#profile-header-container') || document.querySelector('[class*="profile-header"]');

  async function profileBanner(userId) {
    bannerFor = userId;
    banner?.remove(); banner = null;
    if (!me() || userId === me()) return;
    let r;
    try { r = await send({ type: 'friendStatus', userId }); } catch { return; }
    if (bannerFor !== userId || !r?.status) return;
    let html = '';
    if (r.status === 'RequestSent') {
      const q = r.req || {};
      const when = q.found && Math.abs((q.found || 0) - (q.t || 0)) < 5000 ? `found ${ago(q.found)}` : `sent ${ago(q.t)}`;
      html = `<span class="rsq-ico">${icon('clock', 16)}</span>
        <span class="rsq-text"><b>You already sent ${esc(q.displayName || 'this person')} a friend request.</b> It's still waiting (${esc(when)}).</span>
        <a class="rsq-link" href="#roscout-requests">All requests you sent</a>`;
    } else if (r.status === 'RequestReceived') {
      html = `<span class="rsq-ico rsq-in">${icon('userplus', 16)}</span>
        <span class="rsq-text"><b>This person sent you a friend request.</b> Accept it from your Friends page.</span>`;
    } else return;
    banner = document.createElement('div');
    banner.className = `rsq-banner ${r.status === 'RequestSent' ? 'rsq-sent' : 'rsq-received'}`;
    banner.innerHTML = `<span class="rsq-brand"><span class="rs-logo" aria-hidden="true"><i></i><i></i><i></i></span></span>${html}`;
    const a = profileAnchor();
    if (a) a.insertAdjacentElement('afterend', banner);
  }

  // ---- friends page bar ------------------------------------------------------------------
  function paintBar() {
    if (!bar) return;
    bar.innerHTML = `<span class="rsq-brand"><span class="rs-logo" aria-hidden="true"><i></i><i></i><i></i></span>RoScout</span>
      <span class="rsq-text"><b>Friend requests you sent</b> · ${pending ? `${pending} still waiting` : 'none waiting right now'}. Roblox doesn't show these, RoScout keeps the list.</span>
      <a class="rsq-link" href="#roscout-requests">See who you sent them to</a>`;
  }
  function friendsBar(onPage) {
    if (!onPage) { bar?.remove(); bar = null; return; }
    if (bar?.isConnected) return;
    const hdr = document.querySelector('#friends-web-app .page-header') || document.querySelector('.friends-title')?.closest('.page-header, .container-header');
    if (!hdr) return;
    bar = bar || document.createElement('div');
    bar.className = 'rsq-banner rsq-bar';
    paintBar();
    hdr.insertAdjacentElement('afterend', bar);
  }

  function check() {
    const p = location.pathname.match(PROFILE_RE);
    const id = p ? Number(p[1]) : null;
    if (id !== bannerFor) profileBanner(id);
    else if (banner && !banner.isConnected) { const a = profileAnchor(); if (a) a.insertAdjacentElement('afterend', banner); }
    const f = location.pathname.match(FRIENDS_RE);
    friendsBar(!!f && (!f[1] || Number(f[1]) === me()));
  }

  let raf = 0;
  new MutationObserver(() => { if (!raf) raf = requestAnimationFrame(() => { raf = 0; check(); }); })
    .observe(document.documentElement, { childList: true, subtree: true });
  addEventListener('popstate', check);
  check();
})();
