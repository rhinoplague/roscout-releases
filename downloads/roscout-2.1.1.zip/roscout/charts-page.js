// RoScout on roblox.com/charts: live player counts for the top games, drawn with RoScout's charts.
// History comes from the RoScout robot (shared by everyone); live numbers refresh every minute.
(() => {
  const { esc, fmt, fmtFull, ago, send, icon, sparkline, PALETTE } = globalThis.RS;
  const CHARTS_RE = /^\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?charts\/?$/i;
  const LIVE_EVERY = 60e3;
  const HERO_N = 6;

  const S = {
    root: null, top: null, error: '', range: '24h', limit: 25, open: null, hidden: new Set(),
    live: new Map(),        // id -> [[t, players], …] seen while this page is open
    hist7: new Map(),       // id -> shared 7-day points
    icons: {}, timer: null, charts: [], rowChart: null, collapsed: false, loading: false,
  };
  try { S.collapsed = localStorage.getItem('roscout:charts') === '0'; } catch {}

  const series24 = (g) => {
    const pts = [];
    if (S.top) (g.d || []).forEach((v, i) => { if (v != null) pts.push([(S.top.s + i) * S.top.slotMs, v]); });
    for (const p of S.live.get(g.id) || []) if (!pts.length || p[0] > pts.at(-1)[0] + 60e3) pts.push(p);
    return pts;
  };
  const seriesFor = (g) => (S.range === '7d' && S.hist7.get(g.id)?.length
    ? [...S.hist7.get(g.id).filter((p) => p[0] >= Date.now() - 7 * 864e5), ...(S.live.get(g.id) || [])].sort((a, b) => a[0] - b[0])
    : series24(g));
  const now = (g) => S.live.get(g.id)?.at(-1)?.[1] ?? g.v;
  const change = (g) => {
    const pts = series24(g);
    const first = pts.find((p) => p[0] >= Date.now() - 864e5 - 45 * 60e3);
    if (!first || !first[1]) return null;
    return (now(g) - first[1]) / first[1];
  };
  const changeHTML = (c) => (c == null ? '<span class="rsx-chg">—</span>'
    : `<span class="rsx-chg ${c >= 0 ? 'up' : 'down'}" title="Change over the last 24 hours">${c >= 0 ? '▲' : '▼'} ${c >= 9 ? `${Math.round(c + 1)}×` : `${(Math.abs(c) * 100).toFixed(Math.abs(c) < 0.1 ? 1 : 0)}%`}</span>`);

  async function load() {
    S.loading = true;
    try {
      S.top = await send({ type: 'sharedTop' });
      S.error = '';
    } catch (e) {
      try { S.top = await send({ type: 'liveTop' }); S.error = ''; } catch (e2) { S.error = e2.message || e.message; }
    }
    S.loading = false;
    if (S.top) {
      const ids = S.top.list.map((g) => g.id);
      send({ type: 'gameIcons', ids }).then((m) => { S.icons = m || {}; paintIcons(); }).catch(() => {});
      tick();
    }
    render();
  }

  async function tick() {
    if (!S.top || !S.root?.isConnected || document.hidden) return;
    try {
      const r = await send({ type: 'liveCounts', ids: S.top.list.slice(0, 100).map((g) => g.id) });
      for (const [id, v] of Object.entries(r.counts || {})) {
        if (v == null) continue;
        const arr = S.live.get(Number(id)) || [];
        arr.push([r.t, v]);
        if (arr.length > 600) arr.shift();
        S.live.set(Number(id), arr);
      }
      S.lastLive = r.t;
      if (!S.collapsed) refresh();
    } catch {}
  }

  function paintIcons() {
    S.root?.querySelectorAll('[data-rsx-icon]').forEach((el) => {
      const src = S.icons[el.dataset.rsxIcon];
      if (src && !el.firstChild) el.innerHTML = `<img src="${esc(src)}" alt="" loading="lazy">`;
    });
  }

  function row(g, i) {
    const pts = series24(g);
    const c = change(g);
    const open = S.open === g.id;
    return `<div class="rsx-row ${open ? 'open' : ''}" data-rsx-row="${g.id}">
      <button class="rsx-rowbtn" data-rsx-open="${g.id}" aria-expanded="${open}">
        <span class="rsx-rank">${i + 1}</span>
        <span class="rsx-icon" data-rsx-icon="${g.id}">${S.icons[g.id] ? `<img src="${esc(S.icons[g.id])}" alt="">` : ''}</span>
        <span class="rsx-name"><b>${esc(g.n)}</b><span>${g.c ? `by ${esc(g.c)}` : ''}${g.g ? `${g.c ? ' · ' : ''}${esc(g.g)}` : ''}</span></span>
        <span class="rsx-spark">${pts.length >= 2 ? sparkline(pts, 180, 36, c != null && c < 0 ? '#ff6464' : '#2b8cff') : ''}</span>
        <span class="rsx-now"><i class="rsx-dot"></i><b data-rsx-now="${g.id}">${fmtFull(now(g))}</b></span>
        ${changeHTML(c)}
        <span class="rsx-chev">${icon('down', 16)}</span>
      </button>
      ${open ? `<div class="rsx-detail">
          <div class="rsx-detail-head"><b>${fmtFull(now(g))}</b><span>playing now</span><a href="https://www.roblox.com/games/${encodeURIComponent(g.p)}" class="rsx-go">Open game ${icon('external', 13)}</a></div>
          <div class="rsx-rowchart" data-rsx-chart="${g.id}"></div>
        </div>` : ''}
    </div>`;
  }

  function render() {
    if (!S.root) return;
    destroyCharts();
    const list = S.top?.list || [];
    const total = list.reduce((a, g) => a + (now(g) || 0), 0);
    const updated = S.lastLive || S.top?.updated;
    S.root.classList.toggle('rsx-collapsed', S.collapsed);
    S.root.innerHTML = `
      <header class="rsx-head">
        <span class="rsx-brand"><span class="rs-logo" aria-hidden="true"><i></i><i></i><i></i></span>RoScout</span>
        <div class="rsx-title"><b>Live player counts</b><span>${list.length ? `${fmtFull(total)} playing the top ${list.length}${updated ? ` · updated ${esc(ago(updated))}` : ''}` : 'Top games right now'}</span></div>
        <div class="rsx-seg">${['24h', '7d'].map((r) => `<button data-rsx-range="${r}" class="${S.range === r ? 'on' : ''}">${r}</button>`).join('')}</div>
        <button class="rsx-collapse" data-rsx-collapse title="${S.collapsed ? 'Show' : 'Hide'}">${S.collapsed ? 'Show' : 'Hide'}${icon('down', 14)}</button>
      </header>
      ${S.collapsed ? '' : !S.top ? `<div class="rsx-empty">${S.loading ? 'Loading live player counts…' : `Couldn't load player counts${S.error ? `: ${esc(S.error)}` : ''}.`}</div>` : `
        <div class="rsx-hero">
          <div class="rsx-legend">${list.slice(0, HERO_N).map((g, i) => `<button data-rsx-hide="${g.id}" class="${S.hidden.has(g.id) ? 'off' : ''}" style="--c:${PALETTE[i % PALETTE.length]}"><i></i>${esc(g.n)}<b>${fmt(now(g))}</b></button>`).join('')}</div>
          <div class="rsx-herochart" data-rsx-hero></div>
        </div>
        <div class="rsx-list">${list.slice(0, S.limit).map(row).join('')}</div>
        ${list.length > S.limit ? `<button class="rsx-more" data-rsx-more>Show all ${list.length}</button>` : ''}
        <p class="rsx-note">${icon('users', 13)}History is recorded every 30 minutes by the RoScout robot for every game on Roblox's lists, so everyone with RoScout sees the same data, even for games they never tracked. Live numbers refresh every minute while this page is open.</p>`}`;
    if (!S.collapsed && S.top) { mountHero(); mountRowChart(); }
  }

  // update numbers and charts without rebuilding the list
  function refresh() {
    if (!S.root || S.collapsed || !S.top) return;
    for (const g of S.top.list) {
      const el = S.root.querySelector(`[data-rsx-now="${g.id}"]`);
      if (el) el.textContent = fmtFull(now(g));
    }
    const sub = S.root.querySelector('.rsx-title span');
    if (sub) sub.textContent = `${fmtFull(S.top.list.reduce((a, g) => a + (now(g) || 0), 0))} playing the top ${S.top.list.length} · updated just now`;
    destroyCharts();
    mountHero(); mountRowChart();
  }

  function destroyCharts() { S.charts.forEach((c) => c.destroy()); S.charts = []; }

  function mountHero() {
    const host = S.root.querySelector('[data-rsx-hero]');
    if (!host || !globalThis.RSChart) return;
    const games = S.top.list.slice(0, HERO_N);
    const series = games.map((g, i) => ({ name: g.n, color: PALETTE[i % PALETTE.length], points: seriesFor(g) }))
      .filter((s, i) => !S.hidden.has(games[i].id));
    const t1 = Date.now();
    S.charts.push(globalThis.RSChart.line(host, {
      series, look: 'pro', axes: true, height: 300, area: series.length <= 2,
      t0: t1 - (S.range === '7d' ? 7 * 864e5 : 864e5), t1,
      yFmt: (v) => fmt(v), tipFmt: (v) => fmtFull(Math.round(v)),
      empty: S.range === '7d' ? 'Loading 7 days…' : 'Not enough data yet',
    }));
  }

  function mountRowChart() {
    if (!S.open) return;
    const g = S.top.list.find((x) => x.id === S.open);
    const host = S.root.querySelector(`[data-rsx-chart="${S.open}"]`);
    if (!g || !host || !globalThis.RSChart) return;
    const t1 = Date.now();
    S.charts.push(globalThis.RSChart.line(host, {
      series: [{ name: g.n, color: '#2b8cff', points: seriesFor(g) }],
      look: 'pro', live: true, height: 220, t0: t1 - (S.range === '7d' ? 7 * 864e5 : 864e5), t1,
      yFmt: (v) => fmt(v), tipFmt: (v) => (v >= 1e5 ? fmt(v) : fmtFull(Math.round(v))), empty: 'Not enough data yet',
    }));
  }

  async function load7d(ids) {
    const need = ids.filter((id) => !S.hist7.has(id));
    await Promise.all(need.map(async (id) => {
      try { S.hist7.set(id, (await send({ type: 'sharedHistory', universeId: id })).points || []); } catch { S.hist7.set(id, []); }
    }));
  }

  async function onClick(e) {
    const b = e.target.closest('button');
    if (!b || !S.root.contains(b)) return;
    if ('rsxCollapse' in b.dataset) {
      S.collapsed = !S.collapsed;
      try { localStorage.setItem('roscout:charts', S.collapsed ? '0' : '1'); } catch {}
      render(); return;
    }
    if (b.dataset.rsxRange) {
      S.range = b.dataset.rsxRange;
      render();
      if (S.range === '7d' && S.top) {
        await load7d([...S.top.list.slice(0, HERO_N).map((g) => g.id), ...(S.open ? [S.open] : [])]);
        render();
      }
      return;
    }
    if (b.dataset.rsxHide) {
      const id = Number(b.dataset.rsxHide);
      if (S.hidden.has(id)) S.hidden.delete(id); else S.hidden.add(id);
      render(); return;
    }
    if ('rsxMore' in b.dataset) { S.limit = 100; render(); return; }
    if (b.dataset.rsxOpen) {
      const id = Number(b.dataset.rsxOpen);
      S.open = S.open === id ? null : id;
      render();
      if (S.open && S.range === '7d') { await load7d([S.open]); render(); }
    }
  }

  function spot() {
    const f = document.querySelector('#game-carousel-web-app .filters-container, .games-page-container .filters-container');
    if (f) return { el: f, where: 'afterend' };
    const h = document.querySelector('#game-carousel-web-app .games-list-header, .games-page-container .games-list-header');
    if (h) return { el: h, where: 'afterend' };
    return null;
  }

  function check() {
    const on = CHARTS_RE.test(location.pathname) && !/sortName|sortId/i.test(location.hash);
    if (!on) {
      if (S.root) { destroyCharts(); S.root.remove(); S.root = null; clearInterval(S.timer); S.timer = null; }
      return;
    }
    if (S.root?.isConnected) return;
    const sp = spot();
    if (!sp) return;
    if (!S.root) {
      S.root = document.createElement('section');
      S.root.className = 'rsx-root';
      S.root.addEventListener('click', onClick);
      sp.el.insertAdjacentElement(sp.where, S.root);
      render();
      load();
      clearInterval(S.timer);
      S.timer = setInterval(tick, LIVE_EVERY);
    } else {
      sp.el.insertAdjacentElement(sp.where, S.root);
    }
  }

  let raf = 0;
  new MutationObserver(() => { if (!raf) raf = requestAnimationFrame(() => { raf = 0; check(); }); })
    .observe(document.documentElement, { childList: true, subtree: true });
  addEventListener('popstate', check);
  addEventListener('hashchange', check);
  document.addEventListener('visibilitychange', () => { if (!document.hidden && S.root) tick(); });
  check();
})();
