// RoScout background: Rising games feed.
// Every 30 minutes RoScout reads Roblox's public discovery lists (Top Trending, Up-and-Coming,
// Top Playing Now, the "trending in <genre>" lists, …) plus a search for each keyword you watch,
// and stores everyone's player count. Growth = players now vs. 1h / 6h / 24h ago.
//
// rise = {
//   t,                                    last scan
//   snaps: [{ t, c: { universeId: players } }],   oldest first, ~26h kept
//   meta:  { universeId: { n, p, g, cr, s: [sortIds], up, dn, seen } }
// }
// riseKeywords = ['+1 every second', …]

const RISE_ALARM = 'roscout-rise';
const RISE_EVERY_MIN = 30;
const RISE_KEEP_MS = 26 * 36e5;
const RISE_MAX_IDS = 1500;
const EXPLORE = 'https://apis.roblox.com/explore-api/v1';
const SKIP_SORTS = /music|sponsored|filters/i;

let riseRunning = null;

async function exploreSorts(sid) {
  const out = [];
  let token = '';
  for (let page = 0; page < 5; page++) {
    const r = await getJSON(`${EXPLORE}/get-sorts?sessionId=${sid}&device=computer&country=all${token ? `&sortsPageToken=${encodeURIComponent(token)}` : ''}`);
    for (const s of r.sorts || []) if ((s.games || []).length && !SKIP_SORTS.test(s.sortId)) out.push(s);
    token = r.nextSortsPageToken || '';
    if (!token) break;
  }
  return out;
}

async function searchGames(sid, q) {
  const r = await getJSON(`https://apis.roblox.com/search-api/omni-search?searchQuery=${encodeURIComponent(q)}&sessionId=${sid}&pageType=all`);
  return (r.searchResults || []).filter((x) => x.contentGroupType === 'Game').flatMap((x) => x.contents || []);
}

async function riseScan() {
  if (riseRunning) return riseRunning;
  riseRunning = (async () => {
    const sid = crypto.randomUUID();
    const [sorts, keywords, prev] = await Promise.all([exploreSorts(sid), store.get('riseKeywords', []), store.get('rise', null)]);
    const now = Date.now();
    const meta = prev?.meta || {};
    const counts = {};
    const take = (g, sortId, kw) => {
      const id = g.universeId;
      if (!id || g.isSponsored) return;
      counts[id] = g.playerCount ?? counts[id] ?? 0;
      const m = meta[id] || (meta[id] = { s: [] });
      m.n = g.name || m.n; m.p = g.rootPlaceId || m.p; m.g = g.genreL1 || m.g || '';
      if (g.creatorName) m.cr = g.creatorName;
      m.up = g.totalUpVotes ?? m.up; m.dn = g.totalDownVotes ?? m.dn; m.seen = now;
      if (sortId && !m.s.includes(sortId)) m.s.push(sortId);
      if (kw) { m.kw = m.kw || []; if (!m.kw.includes(kw)) m.kw.push(kw); }
    };
    for (const s of sorts) for (const g of s.games) take(g, s.sortId);
    for (const kw of keywords.slice(0, 8)) {
      try { for (const g of (await searchGames(sid, kw)).slice(0, 60)) take(g, null, kw); } catch {}
    }
    // keep following games that were in the feed recently so their growth line doesn't break
    const ids = Object.keys(counts);
    const recent = Object.keys(meta).filter((id) => !counts[id] && now - (meta[id].seen || 0) < 6 * 36e5);
    if (recent.length) {
      try {
        const d = await fetchGames(recent.slice(0, 300).map(Number));
        for (const id of recent) if (d[id]) counts[id] = d[id].game.playing || 0;
      } catch {}
    }
    const snaps = (prev?.snaps || []).filter((x) => now - x.t < RISE_KEEP_MS);
    snaps.push({ t: now, c: counts });
    // forget games we haven't seen in a day
    const live = new Set(snaps.flatMap((x) => Object.keys(x.c)));
    for (const id of Object.keys(meta)) if (!live.has(id)) delete meta[id];
    if (Object.keys(meta).length > RISE_MAX_IDS) {
      const keep = new Set(Object.entries(meta).sort((a, b) => (b[1].seen || 0) - (a[1].seen || 0)).slice(0, RISE_MAX_IDS).map((k) => k[0]));
      for (const id of Object.keys(meta)) if (!keep.has(id)) delete meta[id];
    }
    const rise = { t: now, snaps, meta };
    await store.set('rise', rise);
    return rise;
  })();
  try { return await riseRunning; } finally { riseRunning = null; }
}

async function ensureRiseAlarm(on) {
  const a = await chrome.alarms.get(RISE_ALARM);
  if (on && !a) chrome.alarms.create(RISE_ALARM, { periodInMinutes: RISE_EVERY_MIN, delayInMinutes: RISE_EVERY_MIN });
  if (!on && a) chrome.alarms.clear(RISE_ALARM);
}

chrome.alarms.onAlarm.addListener((a) => {
  if (a.name !== RISE_ALARM) return;
  store.get('riseScan', true).then((on) => (on ? riseScan() : ensureRiseAlarm(false))).catch(() => {});
});

const WINDOWS = { '1h': 36e5, '6h': 6 * 36e5, '24h': 24 * 36e5 };

// players at time t from the snapshot closest to it (within ±45 min)
function countAt(snaps, id, t) {
  let best = null;
  for (const s of snaps) {
    if (!(id in s.c)) continue;
    const d = Math.abs(s.t - t);
    if (d <= 45 * 60e3 && (!best || d < best.d)) best = { d, v: s.c[id], t: s.t };
  }
  return best;
}

handlers.riseFeed = async ({ window = '6h', q = '', genre = '', min = 100, refresh = false }) => {
  let rise = await store.get('rise', null);
  if (refresh || !rise || Date.now() - rise.t > RISE_EVERY_MIN * 60e3) {
    try { rise = await riseScan(); } catch (e) { if (!rise) throw e; }
  }
  await ensureRiseAlarm(await store.get('riseScan', true));
  const { snaps, meta } = rise;
  const latest = snaps.at(-1);
  const span = WINDOWS[window] || WINDOWS['6h'];
  const oldest = snaps[0]?.t || latest.t;
  const localReady = latest.t - oldest >= span - 45 * 60e3;
  // shared robot data: players now / 1h / 6h / 24h ago for every game on Roblox's lists
  let sh = null;
  try { sh = await sharedFile('rise.json', 10 * 60e3); } catch {}
  const shIdx = { '1h': 1, '6h': 2, '24h': 3 }[window] || 2;
  const pool = new Map();
  if (sh) {
    for (const [id, a] of Object.entries(sh.g)) {
      pool.set(id, { cur: a[0], past: a[shIdx] ?? null, m: { n: a[4], p: a[5], g: a[6] || '', cr: a[7] || '', s: [], ...(meta[id] || {}) },
        spark: [[sh.updated - 864e5, a[3]], [sh.updated - 6 * 36e5, a[2]], [sh.updated - 36e5, a[1]], [sh.updated, a[0]]].filter((p) => p[1] != null) });
    }
  }
  for (const [id, cur] of Object.entries(latest.c)) {
    const m = meta[id];
    if (!m) continue;
    const localPast = localReady ? countAt(snaps, id, latest.t - span)?.v ?? null : null;
    const e = pool.get(id);
    if (e) {
      e.m = { ...e.m, ...m };
      if (e.past == null) e.past = localPast;
      if (!sh || latest.t > sh.updated) e.cur = cur;
    } else pool.set(id, { cur, past: localPast, m });
  }
  const ready = localReady || [...pool.values()].some((e) => e.past != null);
  const needle = q.trim().toLowerCase();
  const genres = {};
  const rows = [];
  for (const [id, e] of pool) {
    const { cur, m } = e;
    if (m.g) genres[m.g] = (genres[m.g] || 0) + 1;
    if (genre && m.g !== genre) continue;
    if (needle && !(`${m.n} ${m.cr || ''}`.toLowerCase().includes(needle) || (m.kw || []).some((k) => k.toLowerCase().includes(needle)))) continue;
    if (cur < min) continue;
    const growth = e.past != null && e.past > 0 ? (cur - e.past) / e.past : null;
    rows.push({ id: Number(id), cur, past: e.past, growth, gain: e.past != null ? cur - e.past : null, m, spark: e.spark });
  }
  const rank = (r) => ((r.m.s || []).includes('up-and-coming') ? 2 : 0) + ((r.m.s || []).includes('top-trending') ? 1 : 0);
  rows.sort(ready
    ? (a, b) => (b.growth ?? -1) - (a.growth ?? -1) || b.cur - a.cur
    : (a, b) => rank(b) - rank(a) || b.cur - a.cur);
  const top = rows.slice(0, 80);
  const [icons, tracked] = await Promise.all([
    iconMap('game', top.map((r) => r.id)).catch(() => ({})),
    store.get('tracked', {}),
  ]);
  const games = top.map((r) => ({
    universeId: r.id, placeId: r.m.p, name: r.m.n, creator: r.m.cr || '', genre: r.m.g || '',
    playing: r.cur, past: r.past, growth: r.growth, gain: r.gain,
    likes: r.m.up + r.m.dn >= 10 ? r.m.up / (r.m.up + r.m.dn) : null,
    lists: r.m.s || [], keywords: r.m.kw || [], icon: icons[r.id] || '',
    spark: (() => { const loc = snaps.filter((s) => r.id in s.c).map((s) => [s.t, s.c[r.id]]); return loc.length >= 3 || !r.spark ? loc : r.spark; })(),
    tracked: !!tracked[r.id], rival: !!tracked[r.id]?.rival,
  }));
  return {
    games, ready, window, scanned: Math.max(latest.t, sh?.updated || 0), since: oldest, total: pool.size, shared: !!sh,
    genres: Object.entries(genres).sort((a, b) => b[1] - a[1]).map(([g]) => g),
    keywords: await store.get('riseKeywords', []), scanning: await store.get('riseScan', true),
  };
};

handlers.riseKeyword = async ({ keyword, remove }) => {
  const kw = String(keyword || '').trim().slice(0, 60);
  const list = await store.get('riseKeywords', []);
  const next = remove ? list.filter((k) => k !== kw) : kw && !list.includes(kw) ? [...list, kw].slice(-8) : list;
  await store.set('riseKeywords', next);
  if (!remove && kw) {
    // search right away so the games show up now, not in 30 minutes
    try {
      const rise = await store.get('rise', null);
      if (rise) {
        const found = await searchGames(crypto.randomUUID(), kw);
        const last = rise.snaps.at(-1);
        for (const g of found.slice(0, 60)) {
          if (!g.universeId || g.isSponsored) continue;
          last.c[g.universeId] = g.playerCount || 0;
          const m = rise.meta[g.universeId] || (rise.meta[g.universeId] = { s: [] });
          m.n = g.name; m.p = g.rootPlaceId; m.cr = g.creatorName || m.cr; m.up = g.totalUpVotes; m.dn = g.totalDownVotes; m.g = m.g || '';
          m.seen = Date.now(); m.kw = [...new Set([...(m.kw || []), kw])];
        }
        await store.set('rise', rise);
      }
    } catch {}
  }
  return { keywords: next };
};

handlers.riseScanSetting = async ({ on }) => {
  await store.set('riseScan', !!on);
  await ensureRiseAlarm(!!on);
  return { on: !!on };
};
