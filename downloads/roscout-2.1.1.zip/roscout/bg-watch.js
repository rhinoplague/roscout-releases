// RoScout background: icon & thumbnail history, and rival (competitor) watching.
// Loaded into the service worker by background.js (importScripts), so it shares its helpers:
// store, getJSON, chunk, notify, passesFor, handlers, creatorLite, fetchGames.
//
// art:<universeId> = {
//   icon:   { key, data, t },              current icon (key = CDN hash, data = saved copy)
//   thumbs: { ids: [...], lead, t },       current thumbnail ids (in order) + saved copy of the first one
//   changes: [{ t, kind: 'icon'|'thumbs', before, after, added, removed }]   newest last
// }
// rivalLog = [{ t, uid, name, placeId, kind, text, img }]   newest last
// rpass:<universeId> = [passId, ...]   game passes seen so far (rivals only)

const ART_MAX_CHANGES = 40;
const RIVAL_LOG_MAX = 300;
const ICON_SIZE = '150x150';
const THUMB_SIZE = '384x216';

// tr.rbxcdn.com/180DAY-<hash>/150/150/Image/Webp/noFilter -> <hash>
const cdnKey = (url) => {
  const seg = String(url || '').replace(/^https?:\/\/[^/]+\//, '').split('/')[0];
  return seg.replace(/^\d+DAY-/i, '');
};

async function imageData(url) {
  const r = await fetch(url, { credentials: 'omit' });
  if (!r.ok) throw new Error(`image ${r.status}`);
  const blob = await r.blob();
  const u8 = new Uint8Array(await blob.arrayBuffer());
  let bin = '';
  for (let i = 0; i < u8.length; i += 0x8000) bin += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000));
  return `data:${blob.type && blob.type.startsWith('image/') ? blob.type.toLowerCase() : 'image/webp'};base64,${btoa(bin)}`;
}

async function fetchArt(ids) {
  const icons = {}, thumbs = {};
  for (const c of chunk(ids, 50)) {
    const [ic, th] = await Promise.all([
      getJSON(`https://thumbnails.roblox.com/v1/games/icons?universeIds=${c.join(',')}&size=${ICON_SIZE}&format=Webp&isCircular=false`).catch(() => ({ data: [] })),
      getJSON(`https://thumbnails.roblox.com/v1/games/multiget/thumbnails?universeIds=${c.join(',')}&countPerUniverse=10&defaults=false&size=${THUMB_SIZE}&format=Webp&isCircular=false`).catch(() => ({ data: [] })),
    ]);
    for (const t of ic.data || []) if (t.state === 'Completed' && t.imageUrl) icons[t.targetId] = t.imageUrl;
    for (const u of th.data || []) {
      if (u.error) continue;
      thumbs[u.universeId] = (u.thumbnails || []).filter((t) => t.state === 'Completed' && t.imageUrl).map((t) => ({ id: t.targetId, url: t.imageUrl }));
    }
  }
  return { icons, thumbs };
}

// Compare what Roblox shows now with what we saved; record and return any changes.
async function checkArt(ids) {
  if (!ids.length) return [];
  const { icons, thumbs } = await fetchArt(ids);
  const keys = ids.map((id) => `art:${id}`);
  const got = await chrome.storage.local.get(keys);
  const now = Date.now();
  const events = [];
  const writes = {};
  for (const id of ids) {
    const rec = got[`art:${id}`] || { icon: null, thumbs: null, changes: [] };
    let dirty = !got[`art:${id}`];
    try {
      const url = icons[id];
      if (url) {
        const key = cdnKey(url);
        if (!rec.icon) { rec.icon = { key, data: await imageData(url), t: now }; dirty = true; }
        else if (rec.icon.key !== key) {
          const data = await imageData(url);
          if (data !== rec.icon.data) {
            const ch = { t: now, kind: 'icon', before: rec.icon.data, after: data };
            rec.changes.push(ch); events.push({ uid: id, ...ch });
          }
          rec.icon = { key, data, t: now }; dirty = true;
        }
      }
      const list = thumbs[id];
      if (list && list.length) {
        const nowIds = list.map((t) => t.id);
        if (!rec.thumbs) { rec.thumbs = { ids: nowIds, lead: await imageData(list[0].url), t: now }; dirty = true; }
        else if (nowIds.join() !== rec.thumbs.ids.join()) {
          const old = rec.thumbs.ids;
          const lead = list[0].id === old[0] ? rec.thumbs.lead : await imageData(list[0].url);
          const added = nowIds.filter((x) => !old.includes(x)).length;
          const removed = old.filter((x) => !nowIds.includes(x)).length;
          const ch = { t: now, kind: 'thumbs', before: rec.thumbs.lead, after: lead, added, removed };
          rec.changes.push(ch); events.push({ uid: id, ...ch });
          rec.thumbs = { ids: nowIds, lead, t: now }; dirty = true;
        }
      }
    } catch { /* image download failed: try again next poll */ }
    if (rec.changes.length > ART_MAX_CHANGES) rec.changes.splice(0, rec.changes.length - ART_MAX_CHANGES);
    if (dirty) writes[`art:${id}`] = rec;
  }
  if (Object.keys(writes).length) await chrome.storage.local.set(writes);
  return events;
}

const artText = (ch) => ch.kind === 'icon'
  ? 'Changed its icon'
  : ch.added || ch.removed
    ? `Changed thumbnails${ch.added ? ` · ${ch.added} new` : ''}${ch.removed ? ` · ${ch.removed} removed` : ''}`
    : 'Reordered its thumbnails';

async function logRival(entry) {
  const log = await store.get('rivalLog', []);
  log.push({ t: Date.now(), ...entry });
  if (log.length > RIVAL_LOG_MAX) log.splice(0, log.length - RIVAL_LOG_MAX);
  await store.set('rivalLog', log);
}

// New game passes on a rival (passesFor is cached for an hour)
async function checkRivalPasses(id, info) {
  const passes = await passesFor(id).catch(() => null);
  if (!passes) return [];
  const key = `rpass:${id}`;
  const seen = await store.get(key, null);
  const ids = passes.map((p) => p.id);
  await store.set(key, ids);
  if (!seen) return []; // first look: just remember them
  return passes.filter((p) => !seen.includes(p.id));
}

// Called from poll() after the snapshots are recorded.
async function watchAfterPoll(ids, tracked, prefs) {
  const art = await checkArt(ids).catch(() => []);
  for (const ch of art) {
    const info = tracked[ch.uid];
    if (!info?.rival) continue;
    const text = artText(ch);
    await logRival({ uid: ch.uid, name: info.name, placeId: info.placeId, kind: ch.kind, text, img: ch.after, before: ch.before });
    if (prefs.alertRivals) await notify(`art:${ch.uid}:${ch.t}`, `🎨 ${info.name}`, `${text}. Open RoScout to see before and after.`, info.placeId);
  }
  for (const id of ids) {
    const info = tracked[id];
    if (!info?.rival) continue;
    const fresh = await checkRivalPasses(id, info).catch(() => []);
    for (const p of fresh) {
      const price = p.price ? `R$ ${p.price.toLocaleString()}` : p.forSale ? 'for sale' : 'not for sale yet';
      await logRival({ uid: id, name: info.name, placeId: info.placeId, kind: 'pass', text: `New game pass: ${p.name} (${price})`, img: p.icon || '' });
      if (prefs.alertRivals) await notify(`pass:${id}:${p.id}`, `🎟️ ${info.name} added a game pass`, `${p.name} · ${price}`, info.placeId);
    }
  }
}

handlers.artHistory = async ({ universeId }) => {
  const rec = await store.get(`art:${universeId}`, null);
  return rec || { icon: null, thumbs: null, changes: [] };
};

// Mark/unmark a game as a rival. Rivals are tracked games with extra alerts.
handlers.toggleRival = async ({ universeId, placeId, name, creator }) => {
  const tracked = await store.get('tracked', {});
  let entry = tracked[universeId];
  if (!entry) {
    const d = await fetchGames([Number(universeId)]).catch(() => ({}));
    const g = d[universeId]?.game;
    entry = tracked[universeId] = {
      placeId: g?.rootPlaceId || placeId, name: g?.name || name || 'Untitled',
      creator: creatorLite(g?.creator) || creator || null, addedAt: Date.now(),
    };
    if (g) { await recordSnapshot(universeId, g, d[universeId].votes); await detectUpdate(universeId, g); }
    await ensureAlarm();
  }
  entry.rival = !entry.rival;
  if (entry.rival) {
    entry.rivalSince = Date.now();
    // remember what they look like and which passes they sell right now
    checkArt([Number(universeId)]).catch(() => {});
    checkRivalPasses(Number(universeId), entry).catch(() => {});
  }
  await store.set('tracked', tracked);
  return { rival: entry.rival, tracked: true };
};

handlers.rivals = async () => {
  const tracked = await store.get('tracked', {});
  const ids = Object.keys(tracked).filter((id) => tracked[id].rival);
  const bundle = await gameBundle(ids);
  const arts = ids.length ? await chrome.storage.local.get(ids.map((id) => `art:${id}`)) : {};
  const passes = await Promise.all(ids.map((id) => passesFor(Number(id)).catch(() => null)));
  const games = ids.map((id, i) => {
    const b = bundle(id);
    const a = arts[`art:${id}`];
    return {
      universeId: Number(id), ...tracked[id], history: b.history, days: b.days, updates: b.updates,
      icon: a?.icon?.data || '', artChanges: (a?.changes || []).map(({ t, kind, added, removed }) => ({ t, kind, added, removed })),
      passCount: passes[i] ? passes[i].filter((p) => p.forSale).length : null,
      passPrices: passes[i] ? passPrices(passes[i]) : tracked[id].passPrices,
    };
  });
  return { games, log: (await store.get('rivalLog', [])).slice(-120).reverse() };
};
