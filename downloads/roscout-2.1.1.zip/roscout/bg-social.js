// RoScout background: friend requests you sent.
// Roblox has no list of the requests you've sent, so RoScout notes each one as you send it
// (netwatch.js sees the request go out on roblox.com) and then checks every 20 minutes
// whether it was accepted.
//
// sentReqs = { userId: { t, status: 'pending'|'accepted'|'gone'|'mutual', done, name, displayName, checked } }

const FREQ_ALARM = 'roscout-freq';
const FREQ_KEEP_DONE = 60 * 864e5;

async function myId() {
  return (await chrome.storage.local.get('myUserId')).myUserId || null;
}

async function ensureFreqAlarm() {
  const reqs = await store.get('sentReqs', {});
  const pending = Object.values(reqs).some((r) => r.status === 'pending');
  const a = await chrome.alarms.get(FREQ_ALARM);
  if (pending && !a) chrome.alarms.create(FREQ_ALARM, { periodInMinutes: 20, delayInMinutes: 5 });
  if (!pending && a) chrome.alarms.clear(FREQ_ALARM);
}

async function friendStatuses(me, ids) {
  const out = {};
  for (const c of chunk(ids, 50)) {
    const r = await fetch(`https://friends.roblox.com/v1/users/${me}/friends/statuses?userIds=${c.join(',')}`, { credentials: 'include' });
    if (r.status === 401 || r.status === 403) throw new Error('Sign in to Roblox in Chrome so RoScout can check your requests');
    if (!r.ok) throw new Error(`Roblox answered ${r.status}`);
    for (const x of (await r.json()).data || []) out[x.id] = x.status;
  }
  return out;
}

async function refreshRequests({ notifyChanges = true } = {}) {
  const me = await myId();
  const reqs = await store.get('sentReqs', {});
  const pending = Object.keys(reqs).filter((id) => reqs[id].status === 'pending');
  const now = Date.now();
  if (me && pending.length) {
    const st = await friendStatuses(me, pending.map(Number));
    for (const id of pending) {
      const s = st[id];
      if (!s) continue;
      const r = reqs[id];
      r.checked = now;
      if (s === 'Friends') {
        r.status = 'accepted'; r.done = now;
        if (notifyChanges) {
          await notify(`freq:${id}:${now}`, '✅ Friend request accepted',
            `${r.displayName || r.name || 'Someone'} accepted your friend request.`, null);
          const links = await store.get('notifLinks', {});
          links[`freq:${id}:${now}`] = { profile: Number(id) };
          await store.set('notifLinks', links);
        }
      } else if (s === 'NotFriends') { r.status = 'gone'; r.done = now; }
      else if (s === 'RequestReceived') { r.status = 'mutual'; }
    }
  }
  for (const id of Object.keys(reqs)) if (reqs[id].done && now - reqs[id].done > FREQ_KEEP_DONE) delete reqs[id];
  await store.set('sentReqs', reqs);
  await ensureFreqAlarm();
  return reqs;
}

chrome.alarms.onAlarm.addListener((a) => { if (a.name === FREQ_ALARM) refreshRequests().catch(() => {}); });

handlers.friendRequestSent = async ({ userId }) => {
  const id = Number(userId);
  if (!id) return { ok: false };
  const reqs = await store.get('sentReqs', {});
  reqs[id] = { ...(reqs[id] || {}), t: Date.now(), status: 'pending', done: null };
  try {
    const u = await getJSON(`https://users.roblox.com/v1/users/${id}`);
    reqs[id].name = u.name; reqs[id].displayName = u.displayName;
  } catch {}
  await store.set('sentReqs', reqs);
  await ensureFreqAlarm();
  return { ok: true };
};

handlers.sentRequests = async ({ refresh = true } = {}) => {
  let reqs = await store.get('sentReqs', {});
  let error = '';
  if (refresh) {
    try { reqs = await refreshRequests({ notifyChanges: false }); } catch (e) { error = e.message; }
  }
  const ids = Object.keys(reqs).map(Number);
  const heads = ids.length ? await thumbs('user', ids.slice(0, 100)) : {};
  const list = ids.map((id) => ({ userId: id, ...reqs[id], headshot: heads[id] || '' }))
    .sort((a, b) => (a.status === 'pending' ? 0 : 1) - (b.status === 'pending' ? 0 : 1) || b.t - a.t);
  return { list, error, signedIn: !!(await myId()) };
};

handlers.forgetRequest = async ({ userId }) => {
  const reqs = await store.get('sentReqs', {});
  delete reqs[userId];
  await store.set('sentReqs', reqs);
  await ensureFreqAlarm();
  return { ok: true };
};

// ---- Finding requests you sent before RoScout (or from inside a game) --------------------
// Roblox can't list them, but it can say, for any person, whether you have a request waiting
// with them. So RoScout asks about the people you're most likely to have sent one to.

async function remember(id, status, extra = {}) {
  const reqs = await store.get('sentReqs', {});
  const now = Date.now();
  const r = reqs[id];
  if (status === 'RequestSent') {
    if (!r || r.status !== 'pending') reqs[id] = { ...(r || {}), t: r?.status === 'pending' ? r.t : now, status: 'pending', done: null, found: !r || r.status !== 'pending' ? now : r.found, ...extra };
  } else if (status === 'Friends' && r?.status === 'pending') { r.status = 'accepted'; r.done = now; }
  else if (status === 'NotFriends' && r?.status === 'pending') { r.status = 'gone'; r.done = now; }
  else return false;
  if (!reqs[id].name) {
    try { const u = await getJSON(`https://users.roblox.com/v1/users/${id}`); reqs[id].name = u.name; reqs[id].displayName = u.displayName; } catch {}
  }
  await store.set('sentReqs', reqs);
  await ensureFreqAlarm();
  return true;
}

// one person: used on profile pages
handlers.friendStatus = async ({ userId }) => {
  const me = await myId();
  if (!me || Number(userId) === Number(me)) return { status: null };
  const st = await friendStatuses(me, [Number(userId)]);
  const status = st[userId] || null;
  if (status) await remember(Number(userId), status);
  const reqs = await store.get('sentReqs', {});
  return { status, req: reqs[userId] || null };
};

async function pagedIds(urlFor, pages, pick) {
  const ids = [];
  let cursor = '';
  for (let i = 0; i < pages; i++) {
    let r;
    try {
      const res = await fetch(urlFor(cursor), { credentials: 'include' });
      if (res.status === 429) { await new Promise((ok) => setTimeout(ok, 4000)); continue; }
      if (!res.ok) break;
      r = await res.json();
    } catch { break; }
    ids.push(...pick(r));
    cursor = r.nextPageCursor || r.NextCursor || '';
    if (!cursor) break;
    await new Promise((ok) => setTimeout(ok, 250));
  }
  return ids;
}

let scanRunning = null;
handlers.scanSentRequests = async () => {
  if (scanRunning) return { started: false };
  const me = await myId();
  if (!me) throw new Error('Open roblox.com once while signed in so RoScout knows which account is yours');
  scanRunning = (async () => {
    const progress = async (p) => store.set('reqScan', { running: true, at: Date.now(), ...p });
    try {
      await progress({ step: 'Looking at who you follow and who follows you', checked: 0, total: 0, found: 0 });
      const F = 'https://friends.roblox.com/v1/users';
      const followings = await pagedIds((c) => `${F}/${me}/followings?limit=100&sortOrder=Desc${c ? `&cursor=${encodeURIComponent(c)}` : ''}`, 10, (r) => (r.data || []).map((x) => x.id));
      const followers = await pagedIds((c) => `${F}/${me}/followers?limit=100&sortOrder=Desc${c ? `&cursor=${encodeURIComponent(c)}` : ''}`, 10, (r) => (r.data || []).map((x) => x.id));
      await progress({ step: "Looking at your friends' friends", checked: 0, total: 0, found: 0 });
      const friends = await pagedIds((c) => `${F}/${me}/friends/find?limit=50${c ? `&cursor=${encodeURIComponent(c)}` : ''}`, 20, (r) => (r.PageItems || r.data || []).map((x) => x.id));
      const fof = [];
      for (const f of friends.slice(0, 40)) {
        fof.push(...await pagedIds((c) => `${F}/${f}/friends/find?limit=50${c ? `&cursor=${encodeURIComponent(c)}` : ''}`, 3, (r) => (r.PageItems || r.data || []).map((x) => x.id)));
      }
      const mine = new Set(friends.map(Number));
      const known = Object.keys(await store.get('sentReqs', {})).map(Number);
      const pool = [...new Set([...known, ...followings, ...followers, ...fof].map(Number))].filter((id) => id && id !== Number(me) && !mine.has(id)).slice(0, 8000);
      let found = 0, checked = 0;
      for (const c of chunk(pool, 50)) {
        let st = {};
        try { st = await friendStatuses(me, c); } catch (e) { if (/Sign in/.test(e.message)) throw e; await new Promise((ok) => setTimeout(ok, 3000)); }
        for (const [id, s] of Object.entries(st)) if (s === 'RequestSent' && await remember(Number(id), s)) found++;
        checked += c.length;
        if (checked % 500 < 50) await progress({ step: 'Checking people', checked, total: pool.length, found });
        await new Promise((ok) => setTimeout(ok, 150));
      }
      await store.set('reqScan', { running: false, at: Date.now(), checked, total: pool.length, found, done: true });
    } catch (e) {
      await store.set('reqScan', { running: false, at: Date.now(), error: e.message });
    }
  })();
  scanRunning.finally(() => { scanRunning = null; });
  return { started: true };
};

handlers.scanStatus = async () => store.get('reqScan', null);
