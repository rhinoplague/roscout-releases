// RoScout dashboard — compare tracked games, best-time heatmaps,
// friends-are-playing trends and CSV export.
(() => {
  const {
    esc, fmt, fmtFull, pct, ago, usd, robux, send, getSettings, PALETTE, niceMax,
    revenueSeries, revenueSummary, updateImpact, impactText, heatmapHTML, heatmapStats,
    DOW, hourLong, downloadCSV, dayKey, monetization, withMon, monText, icon,
  } = globalThis.RS;

  const main = document.getElementById('main');
  // Embedded in the RoScout window on roblox.com
  const EMBED = new URLSearchParams(location.search).has('embed');
  const ROBLOX = 'https://www.roblox.com';
  if (EMBED) {
    document.documentElement.classList.add('embed');
    // Roblox links open in the Roblox page itself, not inside the window
    document.addEventListener('click', (e) => {
      const a = e.target.closest?.('a[href]');
      if (!a || !a.href.startsWith(`${ROBLOX}/`) || e.ctrlKey || e.metaKey || e.shiftKey || e.button !== 0) return;
      e.preventDefault();
      parent.postMessage({ rs: 'nav', url: a.href }, ROBLOX);
    }, true);
    addEventListener('message', (e) => {
      if (e.origin === ROBLOX && e.data?.rs === 'go' && e.data.tab) location.hash = e.data.tab;
    });
  }
  const tabs = document.getElementById('tabs');
  const RANGE_MS = { '24h': 864e5, '7d': 7 * 864e5, '30d': 30 * 864e5 };

  let settings;
  let games = [];
  const icons = {};       // universeId -> url
  const placeIcons = {};  // placeId -> url
  let tab = 'compare';
  let sel = new Set();
  let metric = 'players';
  let range = '7d';
  let hmGame = null;
  let ftRange = 7;
  let trends = null;
  let exportGame = null;
  let chartState = null;
  let scale = 'linear';
  let cmpChart = null;
  const effFor = (g) => withMon(settings, monetization(g.passPrices, settings));

  // ---- Data -----------------------------------------------------------------
  async function loadGames() {
    const r = await send({ type: 'getTracked' });
    const prevSel = sel;
    games = r.games;
    games.forEach((g, i) => { g.color = PALETTE[i % PALETTE.length]; });
    const ids = new Set(games.map((g) => g.universeId));
    sel = new Set([...prevSel].filter((id) => ids.has(id)));
    if (!sel.size) games.slice(0, 4).forEach((g) => sel.add(g.universeId));
    if (!ids.has(hmGame)) hmGame = games[0]?.universeId ?? null;
    if (!ids.has(exportGame)) exportGame = games[0]?.universeId ?? null;
  }

  async function loadIcons() {
    const need = games.map((g) => g.universeId).filter((id) => !icons[id]);
    if (!need.length) return;
    try {
      const r = await (await fetch(`https://thumbnails.roblox.com/v1/games/icons?universeIds=${need.join(',')}&size=50x50&format=Png&isCircular=false&returnPolicy=PlaceHolder`)).json();
      for (const t of r.data || []) if (t.imageUrl) icons[t.targetId] = t.imageUrl;
    } catch {}
  }

  async function loadPlaceIcons(placeIds) {
    const need = placeIds.filter((id) => !placeIcons[id]);
    for (let i = 0; i < need.length; i += 100) {
      try {
        const c = need.slice(i, i + 100);
        const r = await (await fetch(`https://thumbnails.roblox.com/v1/places/gameicons?placeIds=${c.join(',')}&size=50x50&format=Png&isCircular=false&returnPolicy=PlaceHolder`)).json();
        for (const t of r.data || []) if (t.imageUrl) placeIcons[t.targetId] = t.imageUrl;
      } catch {}
    }
  }

  const byLine = (g) => g.creator?.name
    ? `<small class="by">by ${esc(g.creator.name)} · ${g.creator.type === 'Group' ? 'Group' : 'Solo dev'}</small>` : '';

  const gameIcon = (g, cls = 'gicon') =>
    `<span class="${cls}">${icons[g.universeId] ? `<img src="${esc(icons[g.universeId])}" alt="">` : ''}</span>`;

  // ---- Stats helpers ----------------------------------------------------------
  function meanBetween(history, a, b) {
    const pts = history.filter((s) => s[0] >= a && s[0] < b);
    if (pts.length < 2 || pts.at(-1)[0] - pts[0][0] < 864e5) return null; // need ≥1 day of data
    return pts.reduce((x, s) => x + s[1], 0) / pts.length;
  }

  function gameRow(g) {
    const last = g.history.at(-1);
    const now = Date.now();
    const avg7 = meanBetween(g.history, now - 7 * 864e5, now);
    const prev7 = meanBetween(g.history, now - 14 * 864e5, now - 7 * 864e5);
    const delta = avg7 != null && prev7 ? (avg7 - prev7) / prev7 : null;
    const mon = monetization(g.passPrices, settings);
    const sum = revenueSummary(g.days, withMon(settings, mon), last?.[1] || 0);
    const up = last?.[4] || 0, down = last?.[5] || 0;
    const lastUpd = g.updates.at(-1);
    return { last, avg7, delta, sum, mon, likes: up + down ? up / (up + down) : null, lastUpd,
      impact: lastUpd ? updateImpact(g.history, lastUpd) : null };
  }

  // ---- Compare chart ----------------------------------------------------------
  function seriesFor(g) {
    const now = Date.now();
    if (metric === 'players') {
      const from = now - RANGE_MS[range];
      let pts = g.history.filter((s) => s[0] >= from).map((s) => [s[0], s[1]]);
      if (pts.length > 320) {
        const step = (now - from) / 320;
        const buckets = new Map();
        for (const [t, v] of pts) {
          const k = Math.floor((t - from) / step);
          const b = buckets.get(k) || [0, 0, 0];
          b[0] += t; b[1] += v; b[2] += 1;
          buckets.set(k, b);
        }
        pts = [...buckets.values()].map((b) => [b[0] / b[2], b[1] / b[2]]).sort((a, b) => a[0] - b[0]);
      }
      return pts;
    }
    const days = revenueSeries(g.days, effFor(g), 'daily').filter((b) => !b.empty);
    const from = now - RANGE_MS[range === '24h' ? '7d' : range];
    return days.map((b) => {
      const [y, m, d] = b.key.split('-').map(Number);
      return [new Date(y, m - 1, d, 12).getTime(), b.robux];
    }).filter((p) => p[0] >= from - 864e5);
  }

  function compareChart() {
    const wrap = document.getElementById('cmp-chart');
    cmpChart?.destroy(); cmpChart = null;
    if (!wrap || !globalThis.RSChart) return;
    const chosen = games.filter((g) => sel.has(g.universeId));
    if (!chosen.length) { wrap.innerHTML = '<div class="empty">Pick games below to compare.</div>'; return; }
    const now = Date.now();
    const rKey = metric === 'revenue' && range === '24h' ? '7d' : range;
    const from = now - RANGE_MS[rKey];
    const series = chosen.map((g) => {
      let points = seriesFor(g);
      if (scale === 'index' && points.length) {
        const avg = points.reduce((a, p) => a + p[1], 0) / points.length || 1;
        points = points.map(([t, v]) => [t, (v / avg) * 100]);
      }
      const markers = g.updates.filter((u) => u >= from && u <= now).map((t) => {
        const imp = impactText(updateImpact(g.history, t));
        return { t, label: `${g.name} updated ${new Date(t).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}${imp ? ` · ${imp}` : ''}` };
      });
      return { name: g.name, color: g.color, points, markers, g };
    });
    const isRev = metric === 'revenue';
    const yFmt = scale === 'index' ? (v) => `${Math.round(v)}%` : isRev ? (v) => robux(v) : (v) => fmt(v);
    const tipFmt = scale === 'index'
      ? (v) => `${Math.round(v)}% of avg`
      : isRev ? (v, s2) => `${robux(v)} <em>≈ ${usd(v * effFor(s2.g).devex)}</em>` : (v) => fmtFull(Math.round(v));
    cmpChart = globalThis.RSChart.line(wrap, {
      series, height: 320, scale: scale === 'log' ? 'log' : 'linear', area: series.length <= 2,
      gapMs: isRev ? 1.6 * 864e5 : 75 * 60e3, t0: from, t1: now, yFmt, tipFmt,
      xTipFmt: isRev ? (t) => new Date(t).toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' }) : undefined,
      empty: 'Not enough data in this range yet. Tracked games are recorded every 15 minutes.',
    });
  }

  function onChartMove() {}

  function kpis(rows) {
    const playing = rows.reduce((a, r) => a + (r.s.last?.[1] || 0), 0);
    const rev = rows.reduce((a, r) => a + r.s.sum.robuxDay, 0);
    const movers = rows.filter((r) => r.s.delta != null).sort((a, b) => b.s.delta - a.s.delta);
    const best = movers[0], worst = movers.at(-1);
    const lastUpd = rows.filter((r) => r.s.lastUpd).sort((a, b) => b.s.lastUpd - a.s.lastUpd)[0];
    const k = (ico, label, value, sub = '', cls = '') => `
      <div class="kpi"><div class="kpi-label">${icon(ico, 14)}${label}</div><div class="kpi-value ${cls}">${value}</div>${sub ? `<div class="kpi-sub">${sub}</div>` : ''}</div>`;
    return `<div class="kpis">
      ${k('users', 'Playing now', fmtFull(playing), `across ${rows.length} tracked game${rows.length === 1 ? '' : 's'}`)}
      ${k('coins', 'Est. revenue / day', robux(rev), `≈ ${usd(rev * settings.devex)} DevEx`)}
      ${best ? k('trend', 'Biggest gain (7d)', `${best.s.delta >= 0 ? '+' : ''}${pct(best.s.delta, 0)}`, esc(best.g.name), best.s.delta >= 0 ? 'up' : 'down') : k('trend', 'Biggest gain (7d)', '—', 'needs 2 weeks of data')}
      ${lastUpd ? k('clock', 'Latest update', esc(ago(lastUpd.s.lastUpd)), esc(lastUpd.g.name)) : k('clock', 'Latest update', '—')}
    </div>`;
  }

  function renderCompare() {
    if (!games.length) {
      main.innerHTML = `<div class="empty"><b>No tracked games yet.</b><br>Open a game on roblox.com and hit Track in the RoScout panel.</div>`;
      return;
    }
    const rows = games.map((g) => ({ g, s: gameRow(g) }));
    main.innerHTML = `
      ${kpis(rows)}
      <section class="card">
        <div class="card-head">
          <h2>Compare</h2>
          <div class="seg">${['players', 'revenue'].map((m) => `<button data-metric="${m}" class="${metric === m ? 'on' : ''}">${m === 'players' ? 'Players' : 'Est. revenue / day'}</button>`).join('')}</div>
          <div class="seg" title="Scale">${[['linear', 'Linear'], ['log', 'Log'], ['index', '% of avg']].map(([k2, l]) => `<button data-scale="${k2}" class="${scale === k2 ? 'on' : ''}">${l}</button>`).join('')}</div>
          <div class="seg">${Object.keys(RANGE_MS).map((r) => `<button data-range="${r}" class="${range === r ? 'on' : ''}" ${metric === 'revenue' && r === '24h' ? 'disabled' : ''}>${r}</button>`).join('')}</div>
        </div>
        <div class="legend">${games.map((g) => `
          <button class="lg ${sel.has(g.universeId) ? 'on' : ''}" data-sel="${g.universeId}" style="--c:${g.color}" title="${esc(g.name)}${g.creator?.name ? ` · by ${esc(g.creator.name)}` : ''}">
            <i></i><span>${esc(g.name)}</span></button>`).join('')}</div>
        <div id="cmp-chart" class="cmp-chart"></div>
        <p class="note">Diamonds mark game updates. Hover one for the date and player impact. ${scale === 'log' ? 'Log scale keeps small games readable next to big ones. ' : scale === 'index' ? "Each line is shown as a % of that game's own average, so you can compare trends between games of any size. " : ''}${metric === 'revenue' ? 'Revenue uses each game\'s game-pass multiplier.' : ''}</p>
      </section>
      <section class="card">
        <div class="card-head"><h2>Tracked games</h2></div>
        <div class="table-wrap"><table class="tbl">
          <thead><tr><th></th><th>Game</th><th>Now</th><th>7-day avg</th><th>vs prior week</th><th>Est. revenue / day</th><th>Passes</th><th>Likes</th><th>Last update</th></tr></thead>
          <tbody>${rows.map(({ g, s: r }) => `
            <tr>
              <td><input type="checkbox" data-sel="${g.universeId}" ${sel.has(g.universeId) ? 'checked' : ''} style="accent-color:${g.color}" aria-label="Compare ${esc(g.name)}"></td>
              <td><a class="gname" href="https://www.roblox.com/games/${encodeURIComponent(g.placeId)}" target="_blank" rel="noopener">${gameIcon(g)}<span class="gtext"><span>${esc(g.name)}</span>${byLine(g)}</span></a></td>
              <td class="num">${fmt(r.last?.[1])}</td>
              <td class="num">${r.avg7 != null ? fmt(r.avg7) : '<span class="dim">—</span>'}</td>
              <td class="num">${r.delta != null ? `<span class="${r.delta >= 0 ? 'up' : 'down'}">${r.delta >= 0 ? '▲' : '▼'} ${pct(Math.abs(r.delta), 0)}</span>` : '<span class="dim">needs 2 weeks</span>'}</td>
              <td class="num">${robux(r.sum.robuxDay)} <span class="dim">≈ ${usd(r.sum.usdDay)}</span></td>
              <td class="num" title="${esc(monText(r.mon))}">${r.mon.used ? `<span class="mult">×${r.mon.mult.toFixed(2)}</span> <span class="dim">${r.mon.n}</span>` : '<span class="dim">—</span>'}</td>
              <td class="num">${r.likes != null ? pct(r.likes, 0) : '—'}</td>
              <td>${r.lastUpd ? `${esc(ago(r.lastUpd))}${r.impact ? ` <span class="${r.impact.pending ? 'dim' : r.impact.pct >= 0 ? 'up' : 'down'}">${esc(impactText(r.impact))}</span>` : ''}` : '—'}</td>
            </tr>`).join('')}</tbody>
        </table></div>
      </section>`;
    compareChart();
  }

  // ---- Best times (heatmaps) --------------------------------------------------
  function renderHeatmap() {
    if (!games.length) { main.innerHTML = `<div class="empty">Track a game to build its week map.</div>`; return; }
    const g = games.find((x) => x.universeId === hmGame) || games[0];
    const peaks = games.map((x) => ({ x, st: heatmapStats(x.hm) }));
    main.innerHTML = `
      <section class="card">
        <div class="card-head">
          <h2>Best times</h2>
          <select id="hm-sel" aria-label="Game">${games.map((x) => `<option value="${x.universeId}" ${x.universeId === g.universeId ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select>
        </div>
        <p class="note">Average players for every hour of the week (your local time), built from RoScout's 15-minute samples.</p>
        <div class="hm-wrap">${heatmapHTML(g.hm)}</div>
      </section>
      <section class="card">
        <div class="card-head"><h2>Peak hours across tracked games</h2></div>
        <div class="table-wrap"><table class="tbl">
          <thead><tr><th>Game</th><th>Peak hour</th><th>Quietest hour</th><th>Best day</th><th>Coverage</th></tr></thead>
          <tbody>${peaks.map(({ x, st }) => `
            <tr><td><span class="gname">${gameIcon(x)}<span>${esc(x.name)}</span></span></td>
              ${st?.ready ? `<td>${DOW[st.peak.day]} ${hourLong(st.peak.hour)} <span class="dim">${fmt(st.peak.avg)}</span></td>
              <td>${DOW[st.low.day]} ${hourLong(st.low.hour)} <span class="dim">${fmt(st.low.avg)}</span></td>
              <td>${st.bestDay ? DOW[st.bestDay.d] : '—'}</td>` : '<td colspan="3" class="dim">Still collecting data</td>'}
              <td class="num">${st ? `${Math.round((st.filled / 168) * 100)}%` : '0%'}</td></tr>`).join('')}</tbody>
        </table></div>
      </section>`;
  }

  // ---- Friends are playing ----------------------------------------------------
  async function loadTrends() {
    const { ftDays = [], friendCache } = await chrome.storage.local.get(['ftDays', 'friendCache']);
    const got = ftDays.length ? await chrome.storage.local.get(ftDays) : {};
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const keyAt = (n) => { const d = new Date(today); d.setDate(d.getDate() - n); return `ft:${dayKey(d.getTime())}`; };
    const cur = new Set(Array.from({ length: ftRange }, (_, i) => keyAt(i)));
    const prev = new Set(Array.from({ length: ftRange }, (_, i) => keyAt(i + ftRange)));
    const agg = new Map();
    for (const k of ftDays) {
      const inCur = cur.has(k), inPrev = prev.has(k);
      if (!inCur && !inPrev) continue;
      for (const [place, e] of Object.entries(got[k] || {})) {
        const a = agg.get(place) || { place: Number(place), name: '', m: 0, pm: 0, friends: new Set() };
        if (e.n) a.name = e.n;
        if (inCur) { a.m += e.m; e.f.forEach((f) => a.friends.add(f)); } else a.pm += e.m;
        agg.set(place, a);
      }
    }
    const list = [...agg.values()].filter((a) => a.m > 0).sort((a, b) => b.m - a.m).slice(0, 30);
    trends = { list, names: friendCache?.names || {}, hasAny: ftDays.length > 0, dataDays: ftDays.filter((k) => cur.has(k)).length };
    await loadPlaceIcons(list.map((a) => a.place));
  }

  function renderFriends() {
    if (!trends) { main.innerHTML = '<div class="empty">Loading…</div>'; loadTrends().then(renderFriends); return; }
    const trackedPlaces = new Set(games.map((g) => Number(g.placeId)));
    const top = trends.list[0]?.m || 1;
    const nameOf = (id) => { const n = trends.names[id]; return n ? (n[1] || n[0]) : `#${id}`; };
    main.innerHTML = `
      <section class="card">
        <div class="card-head">
          <h2>Friends are playing</h2>
          <div class="seg">${[7, 30].map((n) => `<button data-ft="${n}" class="${ftRange === n ? 'on' : ''}">${n} days</button>`).join('')}</div>
        </div>
        <p class="note">What your friends spend the most time in. RoScout checks every 2 minutes while any roblox.com tab is open${trends.dataDays ? ` · ${trends.dataDays} day${trends.dataDays === 1 ? '' : 's'} of data in this window` : ''}.</p>
        ${!trends.list.length ? `<div class="empty">${trends.hasAny ? 'No friend activity recorded in this window yet.' : 'Nothing recorded yet — open roblox.com and leave a tab open; trends build up automatically.'}</div>` : `
        <ol class="ft">${trends.list.map((a, i) => {
          const trend = a.pm ? (a.m - a.pm) / a.pm : null;
          const friendsArr = [...a.friends];
          return `<li>
            <span class="rank">${i + 1}</span>
            <span class="gicon">${placeIcons[a.place] ? `<img src="${esc(placeIcons[a.place])}" alt="">` : ''}</span>
            <div class="ft-main">
              <a href="https://www.roblox.com/games/${a.place}" target="_blank" rel="noopener" class="ft-name">${esc(a.name || 'Unknown experience')}</a>
              <div class="ft-bar"><i style="width:${((a.m / top) * 100).toFixed(1)}%"></i></div>
              <span class="ft-who">${friendsArr.slice(0, 4).map((f) => esc(nameOf(f))).join(', ')}${friendsArr.length > 4 ? ` +${friendsArr.length - 4} more` : ''}</span>
            </div>
            <div class="ft-num"><b>${(a.m / 60).toFixed(a.m < 600 ? 1 : 0)}h</b><span>${friendsArr.length} friend${friendsArr.length === 1 ? '' : 's'}</span></div>
            <div class="ft-trend">${trend == null ? '<span class="new">NEW</span>' : `<span class="${trend >= 0 ? 'up' : 'down'}">${trend >= 0 ? '▲' : '▼'} ${pct(Math.abs(trend), 0)}</span>`}</div>
            <div>${trackedPlaces.has(a.place) ? '<span class="dim">Tracking</span>' : `<button class="btn sm" data-trackplace="${a.place}">☆ Track</button>`}</div>
          </li>`;
        }).join('')}</ol>`}
      </section>`;
  }

  // ---- Export -------------------------------------------------------------------
  const iso = (t) => new Date(t).toISOString();
  const safe = (s) => String(s || 'game').replace(/[^\w\- ]+/g, '').trim().replace(/\s+/g, '-').slice(0, 40) || 'game';
  const today = () => dayKey(Date.now());

  const EXPORTS = {
    summary() {
      const rows = [['game', 'universe_id', 'place_id', 'playing_now', 'avg_players_7d', 'change_vs_prior_week_pct', 'est_robux_per_day', 'est_usd_per_day', 'like_ratio_pct', 'last_update', 'last_update_player_impact_pct']];
      for (const g of games) {
        const s = gameRow(g);
        rows.push([g.name, g.universeId, g.placeId, s.last?.[1] ?? '', s.avg7 != null ? Math.round(s.avg7) : '',
          s.delta != null ? (s.delta * 100).toFixed(1) : '', Math.round(s.sum.robuxDay), s.sum.usdDay.toFixed(2),
          s.likes != null ? (s.likes * 100).toFixed(1) : '', s.lastUpd ? iso(s.lastUpd) : '',
          s.impact && !s.impact.pending ? (s.impact.pct * 100).toFixed(1) : '']);
      }
      downloadCSV(`roscout-summary-${today()}.csv`, rows);
    },
    snapshots(g) {
      const rows = [['time_utc', 'time_local', 'playing', 'visits', 'favorites', 'upvotes', 'downvotes']];
      for (const s of g.history) rows.push([iso(s[0]), new Date(s[0]).toLocaleString(), ...s.slice(1)]);
      downloadCSV(`roscout-${safe(g.name)}-snapshots-${today()}.csv`, rows);
    },
    daily(g) {
      const rows = [['date', 'avg_players', 'hours_recorded', 'est_robux', 'est_usd', 'updates']];
      for (const k of Object.keys(g.days).sort()) {
        const [ph, ch] = g.days[k];
        if (ch < 0.5) continue;
        const avg = ph / ch, rbx = avg * 24 * settings.rph;
        const n = g.updates.filter((t) => dayKey(t) === k).length;
        rows.push([k, Math.round(avg), ch.toFixed(2), Math.round(rbx), (rbx * settings.devex).toFixed(2), n]);
      }
      downloadCSV(`roscout-${safe(g.name)}-daily-${today()}.csv`, rows);
    },
    heatmap(g) {
      const rows = [['day', 'hour', 'avg_players', 'samples']];
      const hm = g.hm || [];
      for (const d of [1, 2, 3, 4, 5, 6, 0]) for (let h = 0; h < 24; h++) {
        const b = hm[d * 24 + h] || [0, 0];
        rows.push([DOW[d], hourLong(h), b[1] ? Math.round(b[0] / b[1]) : '', b[1]]);
      }
      downloadCSV(`roscout-${safe(g.name)}-heatmap-${today()}.csv`, rows);
    },
    updates(g) {
      const rows = [['update_time_utc', 'update_time_local', 'avg_players_24h_before', 'avg_players_24h_after', 'change_pct']];
      for (const t of g.updates) {
        const imp = updateImpact(g.history, t);
        rows.push([iso(t), new Date(t).toLocaleString(), imp?.before != null ? Math.round(imp.before) : '',
          imp?.after != null ? Math.round(imp.after) : '', imp && !imp.pending ? (imp.pct * 100).toFixed(1) : '']);
      }
      downloadCSV(`roscout-${safe(g.name)}-updates-${today()}.csv`, rows);
    },
    async friends() {
      const { ftDays = [], friendCache } = await chrome.storage.local.get(['ftDays', 'friendCache']);
      const got = ftDays.length ? await chrome.storage.local.get(ftDays) : {};
      const names = friendCache?.names || {};
      const rows = [['date', 'place_id', 'game', 'friend_hours', 'friends']];
      for (const k of [...ftDays].sort()) {
        for (const [place, e] of Object.entries(got[k] || {})) {
          rows.push([k.slice(3), place, e.n, (e.m / 60).toFixed(2), e.f.map((id) => names[id]?.[0] || id).join(' ')]);
        }
      }
      downloadCSV(`roscout-friends-playing-${today()}.csv`, rows);
    },
  };

  function renderExport() {
    const g = games.find((x) => x.universeId === exportGame);
    main.innerHTML = `
      <section class="card">
        <div class="card-head"><h2>Export to CSV</h2></div>
        <p class="note">Opens in Excel, Google Sheets or Numbers. Revenue columns use your current estimate settings (${settings.rph} R$ per player-hour, DevEx $${settings.devex}).</p>
        <div class="ex-grid">
          <div class="ex">
            <h3>All tracked games</h3>
            <p>One row per game: players now, 7-day average, week-over-week change, estimated revenue, likes and last update impact.</p>
            <button class="btn" data-export="summary" ${games.length ? '' : 'disabled'}>Download summary</button>
          </div>
          <div class="ex">
            <h3>One game in detail</h3>
            ${games.length ? `<select id="ex-sel" aria-label="Game">${games.map((x) => `<option value="${x.universeId}" ${x.universeId === exportGame ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select>
            <div class="ex-btns">
              <button class="btn" data-export="snapshots">Snapshots <span>${g ? fmtFull(g.history.length) : 0} rows</span></button>
              <button class="btn" data-export="daily">Daily revenue <span>${g ? Object.keys(g.days).length : 0} rows</span></button>
              <button class="btn" data-export="heatmap">Hourly heatmap <span>168 rows</span></button>
              <button class="btn" data-export="updates">Updates &amp; impact <span>${g ? g.updates.length : 0} rows</span></button>
            </div>` : '<p class="dim">Track a game first.</p>'}
          </div>
          <div class="ex">
            <h3>Friends are playing</h3>
            <p>Friend-hours per game per day, with which friends played.</p>
            <button class="btn" data-export="friends">Download friends activity</button>
          </div>
        </div>
      </section>`;
  }

  // ---- Shell ------------------------------------------------------------------
  // ---- My communities ------------------------------------------------------------
  const CM = { state: 'idle', error: '', list: [], stats: {}, filter: 'owned', sort: 'playing', q: '', open: new Set(), userId: null };

  async function loadCommunities(fresh = false) {
    if (CM.state === 'loading' || (CM.state === 'ready' && !fresh)) return;
    CM.state = 'loading'; CM.error = '';
    try {
      const { myUserId } = await chrome.storage.local.get('myUserId');
      if (!myUserId) { CM.state = 'nouser'; render(); return; }
      CM.userId = myUserId;
      const r = await send({ type: 'myCommunities', userId: myUserId });
      CM.list = r.list; CM.state = 'ready';
      if (!CM.list.some((g) => g.owned)) CM.filter = CM.list.some((g) => g.rank >= 254) ? 'admin' : 'all';
      render();
      // stats for the communities you run first, then everything else
      const order = CM.list.slice().sort((a, b) => b.rank - a.rank).map((g) => g.id);
      for (let i = 0; i < order.length; i += 6) {
        Object.assign(CM.stats, await send({ type: 'groupStatsMany', ids: order.slice(i, i + 6) }));
        if (tab === 'communities') render();
      }
    } catch (e) { CM.state = 'error'; CM.error = e.message; render(); }
  }

  function renderCommunities() {
    if (CM.state === 'idle') { main.innerHTML = '<div class="empty">Loading your communities…</div>'; loadCommunities(); return; }
    if (CM.state === 'loading' && !CM.list.length) { main.innerHTML = '<div class="empty">Loading your communities…</div>'; return; }
    if (CM.state === 'nouser') { main.innerHTML = '<div class="empty"><b>Open roblox.com once while logged in.</b><br>RoScout picks up your account there, then your communities show up here.</div>'; return; }
    if (CM.state === 'error') { main.innerHTML = `<div class="empty">Couldn't load communities: ${esc(CM.error)}</div>`; return; }
    const st = (g) => CM.stats[g.id];
    const q = CM.q.trim().toLowerCase();
    let list = CM.list.filter((g) => (CM.filter === 'owned' ? g.owned : CM.filter === 'admin' ? g.rank >= 254 : true) && (!q || g.name.toLowerCase().includes(q)));
    const key = { playing: (g) => st(g)?.playing ?? -1, visits: (g) => st(g)?.visits ?? -1, members: (g) => g.members, name: null }[CM.sort];
    list.sort(key ? (a, b) => key(b) - key(a) : (a, b) => a.name.localeCompare(b.name));
    const runs = CM.list.filter((g) => g.rank >= 254);
    const sum = (arr, f) => arr.reduce((a, g) => a + (f(g) || 0), 0);
    const loaded = runs.filter((g) => st(g)).length;
    const counts = { owned: CM.list.filter((g) => g.owned).length, admin: runs.length, all: CM.list.length };
    const k = (ico, label, value, sub = '') => `<div class="kpi"><div class="kpi-label">${icon(ico, 14)}${label}</div><div class="kpi-value">${value}</div>${sub ? `<div class="kpi-sub">${sub}</div>` : ''}</div>`;
    main.innerHTML = `
      <div class="kpis">
        ${k('building', 'Communities', fmtFull(CM.list.length), `${counts.owned} owned · ${counts.admin} you run`)}
        ${k('users', 'Playing now', fmtFull(sum(runs, (g) => st(g)?.playing)), `in games of communities you run${loaded < runs.length ? ` · ${loaded}/${runs.length} loaded` : ''}`)}
        ${k('eye', 'Total visits', fmt(sum(runs, (g) => st(g)?.visits)), 'across those games')}
        ${k('users', 'Members', fmt(sum(runs, (g) => g.members)), 'in communities you run')}
      </div>
      <section class="card">
        <div class="card-head">
          <h2>My communities</h2>
          <div class="seg">${[['owned', 'Owned'], ['admin', 'I run'], ['all', 'All']].map(([v, l]) => `<button data-cmf="${v}" class="${CM.filter === v ? 'on' : ''}">${l} <span class="dim">${counts[v]}</span></button>`).join('')}</div>
          <div class="seg">${[['playing', 'Playing'], ['visits', 'Visits'], ['members', 'Members'], ['name', 'A–Z']].map(([v, l]) => `<button data-cms="${v}" class="${CM.sort === v ? 'on' : ''}">${l}</button>`).join('')}</div>
          <input class="cm-search" id="cm-q" type="search" placeholder="Search your communities" value="${esc(CM.q)}" aria-label="Search your communities">
          <button class="btn sm" data-cmr="1">${icon('refresh', 13)}Refresh</button>
        </div>
        <div class="cm-list">${list.map((g) => {
          const s2 = st(g), open = CM.open.has(g.id);
          return `
          <div class="cm-row ${open ? 'open' : ''}">
            <button class="cm-head" data-cmo="${g.id}" aria-expanded="${open}">
              <span class="cm-icon">${g.icon ? `<img src="${esc(g.icon)}" alt="">` : icon('building', 18)}</span>
              <span class="cm-main">
                <span class="cm-name">${esc(g.name)}${g.verified ? ' <span class="cm-ver">✔</span>' : ''}${g.primary ? ' <span class="cm-tag cm-primary">Primary</span>' : ''}</span>
                <span class="cm-sub">${fmtFull(g.members)} members · ${g.owned ? '<b class="cm-owned">Owned</b>' : esc(g.role)}</span>
              </span>
              <span class="cm-stats">${s2 ? `
                <span><b>${s2.playing ? '<i class="cm-live"></i>' : ''}${fmtFull(s2.playing)}</b><em>playing</em></span>
                <span><b>${fmt(s2.visits)}</b><em>visits</em></span>
                <span><b>${s2.games.length}</b><em>games</em></span>` : '<span class="cm-skel"></span>'}</span>
              <span class="cm-chev">${icon('down', 16)}</span>
            </button>
            ${open ? `<div class="cm-body">
              ${s2?.games?.length ? s2.games.map((x) => `
                <a class="cm-game" href="https://www.roblox.com/games/${x.placeId}" target="_blank" rel="noopener">
                  <span class="gicon">${x.icon ? `<img src="${esc(x.icon)}" alt="">` : ''}</span>
                  <span class="cm-gname">${esc(x.name)}</span>
                  <span class="dim">${fmt(x.visits)} visits${x.likes != null ? ` · ${pct(x.likes, 0)} liked` : ''}</span>
                  <b>${x.playing ? `${fmtFull(x.playing)} playing` : '<span class="dim">offline</span>'}</b>
                </a>`).join('') : `<p class="dim">${s2 ? 'No public games.' : 'Loading games…'}</p>`}
              <a class="btn sm" href="https://www.roblox.com/communities/${g.id}" target="_blank" rel="noopener">${icon('external', 13)}Open community</a>
            </div>` : ''}
          </div>`;
        }).join('') || '<div class="empty">No communities match.</div>'}</div>
      </section>`;
    const qi = document.getElementById('cm-q');
    if (CM.focus) { qi.focus(); qi.setSelectionRange(qi.value.length, qi.value.length); CM.focus = false; }
  }

  // ---- Appearance --------------------------------------------------------------------
  const BG_DEFAULT = { on: false, opacity: 0.6, blur: 0, dim: 0.3, fit: 'cover', pos: 'center' };
  const AP = { cfg: null, img: null, msg: '', busy: false };

  async function loadAppearance() {
    const { rsBg, rsBgImg } = await chrome.storage.local.get(['rsBg', 'rsBgImg']);
    AP.cfg = { ...BG_DEFAULT, ...(rsBg || {}) };
    AP.img = rsBgImg || null;
  }

  let saveT;
  function saveBg(now = false) {
    clearTimeout(saveT);
    const go = () => chrome.storage.local.set({ rsBg: AP.cfg });
    if (now) go(); else saveT = setTimeout(go, 120);
  }

  function previewVars() {
    const c = AP.cfg;
    return `--rs-bg-img:${AP.img ? `url('${AP.img}')` : 'none'};--rs-bg-opacity:${c.opacity};--rs-bg-blur:${c.blur * 0.5}px;--rs-bg-dim:${c.dim};--rs-bg-size:${c.fit === 'tile' ? 'auto' : c.fit};--rs-bg-repeat:${c.fit === 'tile' ? 'repeat' : 'no-repeat'};--rs-bg-pos:${c.pos}`;
  }

  function updatePreview() {
    const pv = document.getElementById('bg-preview');
    if (pv) pv.setAttribute('style', previewVars());
    for (const [id, f] of [['bg-op', (v) => `${Math.round(v * 100)}%`], ['bg-dim', (v) => `${Math.round(v * 100)}%`], ['bg-blur', (v) => `${v}px`]]) {
      const out = document.getElementById(`${id}-v`);
      if (out) out.textContent = f(AP.cfg[{ 'bg-op': 'opacity', 'bg-dim': 'dim', 'bg-blur': 'blur' }[id]]);
    }
  }

  // Shrink big photos so they load instantly on every Roblox page.
  async function toDataURL(blob) {
    if (/gif/i.test(blob.type) && blob.size < 6e6) {
      return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(blob); });
    }
    const bmp = await createImageBitmap(blob);
    const scale = Math.min(1, 2560 / Math.max(bmp.width, bmp.height));
    const c = document.createElement('canvas');
    c.width = Math.round(bmp.width * scale); c.height = Math.round(bmp.height * scale);
    c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', 0.86);
  }

  async function useImage(blob) {
    if (!blob || !/^image\//.test(blob.type)) { AP.msg = "That file isn't an image. Pick a PNG, JPG, WebP or GIF."; render(); return; }
    AP.busy = true; AP.msg = ''; render();
    try {
      AP.img = await toDataURL(blob);
      AP.cfg.on = true;
      await chrome.storage.local.set({ rsBgImg: AP.img, rsBg: AP.cfg });
      AP.msg = `Background set (${Math.round(AP.img.length / 1024)} KB). Open roblox.com to see it.`;
    } catch (e) { AP.msg = `Couldn't read that image: ${e.message}`; }
    AP.busy = false; render();
  }

  function renderAppearance() {
    if (!AP.cfg) { main.innerHTML = '<div class="empty">Loading…</div>'; loadAppearance().then(render); return; }
    const c = AP.cfg;
    const sw = (id, label, on, sub) => `<label class="ap-switch"><input type="checkbox" id="${id}" ${on ? 'checked' : ''}><span class="ap-track"><i></i></span><span><b>${label}</b>${sub ? `<em>${sub}</em>` : ''}</span></label>`;
    main.innerHTML = `
      <section class="card">
        <div class="card-head"><h2>Roblox background</h2>${sw('bg-on', c.on ? 'On' : 'Off', c.on && !!AP.img)}</div>
        <div class="ap-grid">
          <div class="ap-preview-wrap">
            <div class="ap-preview" id="bg-preview" style="${previewVars()}">
              <div class="ap-pv-nav"><i></i><span></span><span></span><span></span></div>
              <div class="ap-pv-body">
                <div class="ap-pv-h"></div>
                <div class="ap-pv-row">${'<div class="ap-pv-tile"><i></i><b></b><s></s></div>'.repeat(5)}</div>
                <div class="ap-pv-h"></div>
                <div class="ap-pv-row">${'<div class="ap-pv-tile"><i></i><b></b><s></s></div>'.repeat(5)}</div>
              </div>
              ${AP.img ? '' : '<div class="ap-pv-empty">Pick an image to preview it here</div>'}
            </div>
            <p class="note">Preview of the Roblox home page. Changes apply to open Roblox tabs right away.</p>
          </div>
          <div class="ap-controls">
            <div class="ap-drop" id="ap-drop" tabindex="0">
              ${icon('sparkle', 22)}
              <b>${AP.busy ? 'Processing…' : AP.img ? 'Replace image' : 'Choose an image'}</b>
              <span>Drop a file here or click to browse. Big photos are shrunk to 2560px.</span>
              <input type="file" id="ap-file" accept="image/*" hidden>
            </div>
            <div class="ap-url">
              <input type="url" id="ap-url" placeholder="…or paste an image link" aria-label="Image link">
              <button class="btn" data-ap="url">Use link</button>
            </div>
            ${AP.msg ? `<p class="ap-msg">${esc(AP.msg)}</p>` : ''}
            <div class="ap-slider"><label for="bg-op">Image visibility</label><output id="bg-op-v">${Math.round(c.opacity * 100)}%</output>
              <input type="range" id="bg-op" min="0" max="1" step="0.01" value="${c.opacity}"></div>
            <div class="ap-slider"><label for="bg-dim">Darken</label><output id="bg-dim-v">${Math.round(c.dim * 100)}%</output>
              <input type="range" id="bg-dim" min="0" max="0.9" step="0.01" value="${c.dim}"></div>
            <div class="ap-slider"><label for="bg-blur">Blur</label><output id="bg-blur-v">${c.blur}px</output>
              <input type="range" id="bg-blur" min="0" max="24" step="1" value="${c.blur}"></div>
            <div class="ap-row2">
              <label>Fit<select id="bg-fit">${[['cover', 'Fill screen'], ['contain', 'Fit whole image'], ['tile', 'Tile']].map(([v, l]) => `<option value="${v}" ${c.fit === v ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
              <label>Position<select id="bg-pos">${[['center', 'Center'], ['top', 'Top'], ['bottom', 'Bottom'], ['left', 'Left'], ['right', 'Right']].map(([v, l]) => `<option value="${v}" ${c.pos === v ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
            </div>
            ${AP.img ? `<button class="btn ap-remove" data-ap="remove">Remove image</button>` : ''}
          </div>
        </div>
      </section>
      <section class="card">
        <div class="card-head"><h2>Roblox pages</h2></div>
        <div class="ap-switches">
          ${sw('set-tiles', 'Live stats on game tiles', settings.tileStats !== false, 'Players now, visits, like ratio and last update on every game in Home, Discover and Charts')}
          ${sw('set-tilerev', 'Revenue estimate on tiles', settings.tileRevenue !== false, 'A rough ≈$/day from players right now, using your revenue settings')}
          ${sw('set-mp', 'Your most played', settings.mostPlayed !== false, "Replaces RoPro's Most Played on the home page with RoScout's own playtime tracking")}
        </div>
      </section>`;
  }

  async function setSetting(key, val) {
    settings = { ...settings, [key]: val };
    const { settings: cur } = await chrome.storage.sync.get('settings');
    await chrome.storage.sync.set({ settings: { ...(cur || {}), [key]: val } });
  }

  main.addEventListener('input', (e) => {
    if (tab !== 'appearance' || !AP.cfg) return;
    const map = { 'bg-op': 'opacity', 'bg-dim': 'dim', 'bg-blur': 'blur' };
    if (map[e.target.id]) { AP.cfg[map[e.target.id]] = Number(e.target.value); updatePreview(); saveBg(); }
  });
  main.addEventListener('change', async (e) => {
    if (tab !== 'appearance' || !AP.cfg) return;
    const id = e.target.id;
    if (id === 'bg-on') { AP.cfg.on = e.target.checked; saveBg(true); render(); }
    if (id === 'bg-fit') { AP.cfg.fit = e.target.value; updatePreview(); saveBg(true); }
    if (id === 'bg-pos') { AP.cfg.pos = e.target.value; updatePreview(); saveBg(true); }
    if (id === 'ap-file' && e.target.files?.[0]) useImage(e.target.files[0]);
    if (id === 'set-tiles') setSetting('tileStats', e.target.checked);
    if (id === 'set-tilerev') setSetting('tileRevenue', e.target.checked);
    if (id === 'set-mp') setSetting('mostPlayed', e.target.checked);
  });
  main.addEventListener('click', async (e) => {
    if (tab !== 'appearance') return;
    if (e.target.closest('#ap-drop') && e.target.id !== 'ap-file') { document.getElementById('ap-file')?.click(); return; }
    const b = e.target.closest('[data-ap]');
    if (!b) return;
    if (b.dataset.ap === 'remove') {
      AP.img = null; AP.cfg.on = false; AP.msg = 'Image removed.';
      await chrome.storage.local.remove('rsBgImg'); saveBg(true); render();
    }
    if (b.dataset.ap === 'url') {
      const url = document.getElementById('ap-url')?.value.trim();
      if (!/^https?:\/\//i.test(url || '')) { AP.msg = 'Paste a link that starts with https://'; render(); return; }
      AP.busy = true; render();
      try {
        const res = await fetch(url);
        if (!res.ok) throw new Error(`the site answered ${res.status}`);
        AP.busy = false;
        await useImage(await res.blob());
      } catch (err) {
        AP.busy = false;
        AP.msg = `Couldn't download that image (${err.message}). Some sites block this. Save the image and upload it instead.`;
        render();
      }
    }
  });
  main.addEventListener('keydown', (e) => {
    if (e.target.id === 'ap-drop' && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); document.getElementById('ap-file')?.click(); }
  });
  main.addEventListener('dragover', (e) => { const d = e.target.closest?.('#ap-drop'); if (d) { e.preventDefault(); d.classList.add('over'); } });
  main.addEventListener('dragleave', (e) => { e.target.closest?.('#ap-drop')?.classList.remove('over'); });
  main.addEventListener('drop', (e) => {
    const d = e.target.closest?.('#ap-drop');
    if (!d) return;
    e.preventDefault(); d.classList.remove('over');
    const f = e.dataTransfer?.files?.[0];
    if (f) useImage(f);
  });

  function render() {
    cmpChart?.destroy(); cmpChart = null;
    if (EMBED) parent.postMessage({ rs: 'tab', tab }, ROBLOX);
    tabs.querySelectorAll('a').forEach((a) => a.classList.toggle('on', a.dataset.tab === tab));
    ({ compare: renderCompare, heatmap: renderHeatmap, friends: renderFriends, communities: renderCommunities, appearance: renderAppearance, export: renderExport })[tab]();
  }

  function setTabFromHash() {
    const t = location.hash.slice(1);
    tab = ['compare', 'heatmap', 'friends', 'communities', 'appearance', 'export'].includes(t) ? t : 'compare';
  }

  main.addEventListener('click', async (e) => {
    const b = e.target.closest('button, input[type=checkbox]');
    if (!b) return;
    if (b.dataset.cmf) { CM.filter = b.dataset.cmf; render(); return; }
    if (b.dataset.cms) { CM.sort = b.dataset.cms; render(); return; }
    if (b.dataset.cmo) { const id = Number(b.dataset.cmo); CM.open.has(id) ? CM.open.delete(id) : CM.open.add(id); render(); return; }
    if (b.dataset.cmr) { CM.state = 'idle'; CM.stats = {}; render(); return; }
    if (b.dataset.scale) { scale = b.dataset.scale; render(); return; }
    if (b.dataset.metric) { metric = b.dataset.metric; if (metric === 'revenue' && range === '24h') range = '7d'; render(); }
    else if (b.dataset.range) { range = b.dataset.range; render(); }
    else if (b.dataset.sel) {
      const id = Number(b.dataset.sel);
      if (sel.has(id)) sel.delete(id); else sel.add(id);
      render();
    } else if (b.dataset.ft) { ftRange = Number(b.dataset.ft); trends = null; render(); }
    else if (b.dataset.trackplace) {
      b.disabled = true; b.textContent = 'Adding…';
      try { await send({ type: 'trackPlace', placeId: Number(b.dataset.trackplace) }); await loadGames(); await loadIcons(); }
      catch { b.textContent = 'Failed'; return; }
      render();
    } else if (b.dataset.export) {
      const g = games.find((x) => x.universeId === exportGame);
      const fn = EXPORTS[b.dataset.export];
      await (b.dataset.export === 'summary' || b.dataset.export === 'friends' ? fn() : g && fn(g));
    }
  });

  main.addEventListener('input', (e) => {
    if (e.target.id === 'cm-q') { CM.q = e.target.value; CM.focus = true; render(); }
  });
  main.addEventListener('change', (e) => {
    if (e.target.id === 'hm-sel') { hmGame = Number(e.target.value); render(); }
    if (e.target.id === 'ex-sel') { exportGame = Number(e.target.value); render(); }
  });

  main.addEventListener('mousemove', onChartMove);
  main.addEventListener('mouseleave', () => {
    document.querySelector('#xhair')?.setAttribute('visibility', 'hidden');
    const tip = document.querySelector('.cmp-tip'); if (tip) tip.hidden = true;
  });
  main.addEventListener('mouseover', (e) => {
    const cell = e.target.closest?.('.rs-hm-cell');
    if (cell) { const out = cell.closest('.rs-hm')?.querySelector('.rs-hm-readout'); if (out) out.textContent = cell.dataset.tip; }
  });

  window.addEventListener('hashchange', () => { setTabFromHash(); render(); });
  let rT;
  // charts resize themselves

  (async () => {
    setTabFromHash();
    settings = await getSettings();
    try { await loadGames(); } catch (e) { main.innerHTML = `<div class="empty">Couldn't load data: ${esc(e.message)}</div>`; return; }
    render();
    await loadIcons();
    render();
  })();
})();
