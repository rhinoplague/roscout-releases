// RoScout charts — a small SVG time-series chart built for RoScout (no dependencies).
// RSChart.line(el, opts) draws smooth lines with gradient fills, nice axis ticks,
// a hover crosshair with a tooltip for every series, and optional event markers.
//
// opts = {
//   series: [{ name, color, points: [[timeMs, value], ...], markers: [{ t, label }] }],
//   height: 220, scale: 'linear' | 'log', area: true,
//   yFmt: (v) => string, tipFmt: (v, series) => string, gapMs: 75 * 60e3,
//   xTipFmt: (t) => string,
// }
(() => {
  const NS = 'http://www.w3.org/2000/svg';
  const compact = new Intl.NumberFormat('en', { notation: 'compact', maximumFractionDigits: 1 });
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let uid = 0;

  // Monotone cubic interpolation (no overshoot) through pixel points.
  function monotonePath(pts) {
    const n = pts.length;
    if (n === 0) return '';
    if (n === 1) return `M${pts[0][0]},${pts[0][1]}`;
    if (n === 2) return `M${pts[0][0]},${pts[0][1]}L${pts[1][0]},${pts[1][1]}`;
    const dx = [], dy = [], m = [];
    for (let i = 0; i < n - 1; i++) {
      dx[i] = pts[i + 1][0] - pts[i][0];
      dy[i] = pts[i + 1][1] - pts[i][1];
      m[i] = dx[i] ? dy[i] / dx[i] : 0;
    }
    const t = [m[0]];
    for (let i = 1; i < n - 1; i++) t[i] = m[i - 1] * m[i] <= 0 ? 0 : (m[i - 1] + m[i]) / 2;
    t[n - 1] = m[n - 2];
    for (let i = 0; i < n - 1; i++) {
      if (m[i] === 0) { t[i] = 0; t[i + 1] = 0; continue; }
      const a = t[i] / m[i], b = t[i + 1] / m[i], h = a * a + b * b;
      if (h > 9) { const k = 3 / Math.sqrt(h); t[i] = k * a * m[i]; t[i + 1] = k * b * m[i]; }
    }
    let d = `M${pts[0][0].toFixed(1)},${pts[0][1].toFixed(1)}`;
    for (let i = 0; i < n - 1; i++) {
      const h = dx[i] / 3;
      d += `C${(pts[i][0] + h).toFixed(1)},${(pts[i][1] + t[i] * h).toFixed(1)} ${(pts[i + 1][0] - h).toFixed(1)},${(pts[i + 1][1] - t[i + 1] * h).toFixed(1)} ${pts[i + 1][0].toFixed(1)},${pts[i + 1][1].toFixed(1)}`;
    }
    return d;
  }

  function niceStep(span, count) {
    const raw = span / Math.max(1, count);
    const p = 10 ** Math.floor(Math.log10(raw || 1));
    for (const m of [1, 2, 2.5, 5, 10]) if (m * p >= raw) return m * p;
    return 10 * p;
  }

  function yTicks(min, max, scale) {
    if (scale === 'log') {
      const lo = Math.floor(Math.log10(Math.max(1, min))), hi = Math.ceil(Math.log10(Math.max(10, max)));
      const out = [];
      for (let e = lo; e <= hi; e++) out.push(10 ** e);
      return { ticks: out, lo: 10 ** lo, hi: 10 ** hi };
    }
    const step = niceStep(max - min || 1, 4);
    const lo = Math.floor(min / step) * step, hi = Math.ceil(max / step) * step || step;
    const out = [];
    for (let v = lo; v <= hi + step / 2; v += step) out.push(v);
    return { ticks: out, lo, hi };
  }

  const H = 36e5, D = 864e5;
  function xTicks(t0, t1, width) {
    const span = t1 - t0, want = Math.max(2, Math.floor(width / 90));
    const steps = [H, 2 * H, 3 * H, 4 * H, 6 * H, 12 * H, D, 2 * D, 3 * D, 7 * D, 14 * D, 30 * D];
    const step = steps.find((s) => span / s <= want) || 30 * D;
    const out = [];
    const start = new Date(t0);
    if (step >= D) start.setHours(0, 0, 0, 0); else start.setMinutes(0, 0, 0);
    // step by calendar days (not fixed ms) so daylight-saving changes don't repeat labels
    const next = (d) => (step >= D ? new Date(d.getFullYear(), d.getMonth(), d.getDate() + step / D) : new Date(d.getTime() + step));
    for (let d = start; d.getTime() <= t1; d = next(d)) {
      const t = d.getTime();
      if (t < t0) continue;
      if (step < D && d.getHours() % (step / H) !== 0) continue;
      const label = step < D
        ? (d.getHours() === 0 ? d.toLocaleDateString([], { weekday: 'short' }) : d.toLocaleTimeString([], { hour: 'numeric' }))
        : d.toLocaleDateString([], step >= 7 * D ? { month: 'short', day: 'numeric' } : { weekday: 'short', day: 'numeric' });
      out.push([t, label]);
    }
    return out;
  }

  function el(tag, attrs = {}, parent) {
    const e = document.createElementNS(NS, tag);
    for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
    if (parent) parent.appendChild(e);
    return e;
  }

  function line(host, opts) {
    const o = { height: 220, scale: 'linear', area: true, gapMs: 75 * 60e3, yFmt: (v) => compact.format(v), tipFmt: (v) => compact.format(v), ...opts };
    const id = `rsc${++uid}`;
    host.classList.add('rsc');
    host.style.position = host.style.position || 'relative';
    let ro, state;

    function draw() {
      host.innerHTML = '';
      const W = Math.max(260, host.clientWidth || 600), Ht = o.height;
      const series = o.series.filter((s) => s.points.length);
      if (!series.length) { host.innerHTML = `<div class="rsc-empty">${esc(o.empty || 'No data yet')}</div>`; return; }
      let t0 = Infinity, t1 = -Infinity, vMin = Infinity, vMax = -Infinity;
      for (const s of series) for (const [t, v] of s.points) {
        if (t < t0) t0 = t; if (t > t1) t1 = t;
        if (v < vMin) vMin = v; if (v > vMax) vMax = v;
      }
      if (o.t0 != null) t0 = Math.min(t0, o.t0);
      if (o.t1 != null) t1 = Math.max(t1, o.t1);
      if (t1 === t0) t1 = t0 + H;
      // 'pro' look: no axes, the line fills the height, dotted backdrop, peak label, live pulse
      const pro = o.look === 'pro';
      let yt;
      if (pro) {
        const sp = vMax - vMin || Math.max(1, vMax * 0.1);
        yt = { lo: Math.max(0, vMin - sp * 0.2), hi: vMax + sp * 0.08, ticks: [] };
      } else yt = yTicks(o.scale === 'log' ? Math.max(1, vMin) : Math.min(0, vMin), vMax || 1, o.scale);
      const labelW = pro ? 0 : Math.max(...yt.ticks.map((v) => o.yFmt(v).length)) * 6.6 + 12;
      const M = pro ? { l: 4, r: 18, t: 34, b: 10 } : { l: Math.max(34, labelW), r: 12, t: 12, b: 26 };
      const X = (t) => M.l + ((t - t0) / (t1 - t0)) * (W - M.l - M.r);
      const Y = o.scale === 'log'
        ? (v) => { const a = Math.log10(yt.lo), b = Math.log10(yt.hi); return Ht - M.b - ((Math.log10(Math.max(v, yt.lo)) - a) / (b - a || 1)) * (Ht - M.t - M.b); }
        : (v) => Ht - M.b - ((v - yt.lo) / (yt.hi - yt.lo || 1)) * (Ht - M.t - M.b);

      const svg = el('svg', { class: 'rsc-svg', width: W, height: Ht, viewBox: `0 0 ${W} ${Ht}` });
      const defs = el('defs', {}, svg);
      series.forEach((s, i) => {
        const g = el('linearGradient', { id: `${id}g${i}`, x1: 0, y1: 0, x2: 0, y2: 1 }, defs);
        el('stop', { offset: '0%', 'stop-color': s.color, 'stop-opacity': pro ? 0.34 : series.length > 1 ? 0.16 : 0.32 }, g);
        if (pro) el('stop', { offset: '55%', 'stop-color': s.color, 'stop-opacity': 0.1 }, g);
        el('stop', { offset: '100%', 'stop-color': s.color, 'stop-opacity': 0 }, g);
      });
      if (pro) {
        const pat = el('pattern', { id: `${id}dots`, width: 26, height: 26, patternUnits: 'userSpaceOnUse' }, defs);
        el('circle', { cx: 13, cy: 13, r: 1, class: 'rsc-dotgrid' }, pat);
        el('rect', { x: 0, y: 0, width: W, height: Ht, fill: `url(#${id}dots)` }, svg);
      }
      for (const v of yt.ticks) {
        const y = Y(v);
        el('line', { x1: M.l, x2: W - M.r, y1: y, y2: y, class: v === yt.ticks[0] ? 'rsc-axis' : 'rsc-grid' }, svg);
        const tx = el('text', { x: M.l - 8, y: y + 3.5, 'text-anchor': 'end', class: 'rsc-lab' }, svg);
        tx.textContent = o.yFmt(v);
      }
      for (const [t, label] of pro ? [] : xTicks(t0, t1, W - M.l - M.r)) {
        const tx = el('text', { x: X(t), y: Ht - 8, 'text-anchor': 'middle', class: 'rsc-lab' }, svg);
        tx.textContent = label;
      }

      const pix = series.map((s) => {
        const segs = [];
        let cur = [];
        s.points.forEach((p, i) => {
          if (i && p[0] - s.points[i - 1][0] > o.gapMs) { segs.push(cur); cur = []; }
          cur.push([X(p[0]), Y(p[1])]);
        });
        segs.push(cur);
        return segs;
      });
      series.forEach((s, i) => {
        for (const seg of pix[i]) {
          if (!seg.length) continue;
          const d = monotonePath(seg);
          if (o.area && seg.length > 1) {
            el('path', { d: `${d}L${seg.at(-1)[0]},${Ht - M.b}L${seg[0][0]},${Ht - M.b}Z`, fill: `url(#${id}g${i})`, class: 'rsc-area' }, svg);
          }
          el('path', { d, class: 'rsc-line', stroke: s.color, fill: 'none' }, svg);
        }
        const last = pix[i].at(-1).at(-1);
        if (last && pro) {
          el('circle', { cx: last[0], cy: last[1], r: 11, fill: 'none', stroke: s.color, 'stroke-opacity': 0.35, 'stroke-width': 1.2 }, svg);
          if (o.live) el('circle', { cx: last[0], cy: last[1], r: 5, fill: s.color, class: 'rsc-pulse' }, svg);
          el('circle', { cx: last[0], cy: last[1], r: 4, fill: s.color, class: 'rsc-end' }, svg);
        } else if (last) {
          el('circle', { cx: last[0], cy: last[1], r: 6, fill: s.color, opacity: 0.2 }, svg);
          el('circle', { cx: last[0], cy: last[1], r: 3, fill: s.color }, svg);
        }
      });

      // floating label: "12.4M  7:55 AM" over the peak (and over the hovered point while scrubbing)
      const whenShort = o.whenFmt || ((t) => (t1 - t0 > 36 * H
        ? new Date(t).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })
        : new Date(t).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })));
      function flag(g, x, y, v, t) {
        g.innerHTML = '';
        el('circle', { cx: x, cy: y, r: 3.5, class: 'rsc-flag-dot' }, g);
        const anchor = x < 70 ? 'start' : x > W - 70 ? 'end' : 'middle';
        const tx = el('text', { x: anchor === 'start' ? Math.max(2, x - 6) : anchor === 'end' ? Math.min(W - 2, x + 6) : x, y: Math.max(13, y - 12), 'text-anchor': anchor, class: 'rsc-flag' }, g);
        el('tspan', { class: 'rsc-flag-v' }, tx).textContent = o.tipFmt(v);
        el('tspan', { class: 'rsc-flag-t', dx: 7 }, tx).textContent = whenShort(t);
      }
      let peakG = null;
      if (pro && o.peak !== false) {
        const pts = series[0].points;
        let best = null;
        for (const p of pts) if (!best || p[1] > best[1]) best = p;
        if (best && pts.length > 2) { peakG = el('g', { class: 'rsc-peak' }, svg); flag(peakG, X(best[0]), Y(best[1]), best[1], best[0]); }
      }
      const hoverG = pro ? el('g', { class: 'rsc-peak', visibility: 'hidden' }, svg) : null;

      // markers (e.g. game updates), placed on the line at that time
      const markerHits = [];
      series.forEach((s, i) => {
        for (const mk of s.markers || []) {
          if (mk.t < t0 || mk.t > t1) continue;
          const v = valueAt(s.points, mk.t);
          if (v == null) continue;
          const x = X(mk.t), y = Y(v);
          el('path', { d: `M${x},${y - 6} L${x + 5},${y} L${x},${y + 6} L${x - 5},${y} Z`, class: 'rsc-marker', fill: s.color }, svg);
          markerHits.push({ x, y, s, mk });
        }
      });

      const cross = el('line', { y1: M.t, y2: Ht - M.b, class: 'rsc-cross', visibility: 'hidden' }, svg);
      const dots = series.map((s) => el('circle', { r: 4, fill: s.color, class: 'rsc-dot', visibility: 'hidden' }, svg));
      host.appendChild(svg);
      const tip = document.createElement('div');
      tip.className = 'rsc-tip';
      tip.hidden = true;
      host.appendChild(tip);
      state = { X, Y, M, W, Ht, t0, t1, series, cross, dots, tip, markerHits, svg, pro, peakG, hoverG, flag };
    }

    function valueAt(points, t) {
      if (!points.length || t < points[0][0] || t > points.at(-1)[0]) return null;
      for (let i = 1; i < points.length; i++) {
        if (points[i][0] >= t) {
          const [ta, va] = points[i - 1], [tb, vb] = points[i];
          if (tb - ta > o.gapMs) return null;
          return va + (vb - va) * ((t - ta) / (tb - ta || 1));
        }
      }
      return points.at(-1)[1];
    }

    function nearest(points, t) {
      let lo = 0, hi = points.length - 1;
      while (hi - lo > 1) { const mid = (lo + hi) >> 1; if (points[mid][0] < t) lo = mid; else hi = mid; }
      return Math.abs(points[lo][0] - t) <= Math.abs(points[hi][0] - t) ? points[lo] : points[hi];
    }

    function onMove(e) {
      if (!state) return;
      const r = state.svg.getBoundingClientRect();
      const px = e.clientX - r.left, py = e.clientY - r.top;
      const { X, Y, M, W, t0, t1, series, cross, dots, tip, markerHits } = state;
      if (px < M.l || px > W - M.r) return hide();
      const t = t0 + ((px - M.l) / (W - M.l - M.r)) * (t1 - t0);
      const span = (t1 - t0) / Math.max(20, (W - M.l - M.r) / 6);
      const hitMarker = markerHits.find((h) => Math.abs(h.x - px) < 7 && Math.abs(h.y - py) < 9);
      const rows = [];
      let snapT = null;
      series.forEach((s, i) => {
        const p = nearest(s.points, t);
        if (!p || Math.abs(p[0] - t) > Math.max(span * 3, o.gapMs / 2)) { dots[i].setAttribute('visibility', 'hidden'); return; }
        if (snapT == null || Math.abs(p[0] - t) < Math.abs(snapT - t)) snapT = p[0];
        dots[i].setAttribute('cx', X(p[0])); dots[i].setAttribute('cy', Y(p[1])); dots[i].setAttribute('visibility', 'visible');
        rows.push({ s, v: p[1] });
      });
      if (!rows.length) return hide();
      const cx = X(snapT);
      cross.setAttribute('x1', cx); cross.setAttribute('x2', cx); cross.setAttribute('visibility', 'visible');
      if (state.pro) {
        const v = rows[0].v;
        state.flag(state.hoverG, cx, Y(v), v, snapT);
        state.hoverG.setAttribute('visibility', 'visible');
        state.peakG?.setAttribute('visibility', 'hidden');
        dots.forEach((d) => d.setAttribute('visibility', 'hidden'));
        o.onHover?.({ t: snapT, v, first: series[0].points[0] });
        if (!hitMarker) { tip.hidden = true; return; }
        tip.innerHTML = `<div class="rsc-tip-mark" style="margin:0;padding:0;border:0"><i style="background:${hitMarker.s.color}"></i>${esc(hitMarker.mk.label)}</div>`;
        tip.hidden = false;
        const hr0 = host.getBoundingClientRect();
        let l0 = r.left - hr0.left + cx + 14;
        if (l0 + tip.offsetWidth > hr0.width - 4) l0 = r.left - hr0.left + cx - tip.offsetWidth - 14;
        tip.style.left = `${Math.max(0, l0)}px`; tip.style.top = `${Math.max(0, py - 20)}px`;
        return;
      }
      rows.sort((a, b) => b.v - a.v);
      const when = (o.xTipFmt || ((x) => new Date(x).toLocaleString([], { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })))(snapT);
      tip.innerHTML = `<div class="rsc-tip-when">${esc(when)}</div>${rows.map(({ s, v }) => `
        <div class="rsc-tip-row"><i style="background:${s.color}"></i><span>${esc(s.name)}</span><b>${o.tipFmt(v, s)}</b></div>`).join('')}
        ${hitMarker ? `<div class="rsc-tip-mark"><i style="background:${hitMarker.s.color}"></i>${esc(hitMarker.mk.label)}</div>` : ''}`;
      tip.hidden = false;
      const hr = host.getBoundingClientRect();
      const offX = r.left - hr.left;
      let left = offX + cx + 14;
      if (left + tip.offsetWidth > hr.width - 4) left = offX + cx - tip.offsetWidth - 14;
      tip.style.left = `${Math.max(0, left)}px`;
      tip.style.top = `${Math.max(0, Math.min(py - 20, state.Ht - tip.offsetHeight))}px`;
    }

    function hide() {
      if (!state) return;
      state.cross.setAttribute('visibility', 'hidden');
      state.dots.forEach((d) => d.setAttribute('visibility', 'hidden'));
      state.tip.hidden = true;
      if (state.pro) { state.hoverG.setAttribute('visibility', 'hidden'); state.peakG?.setAttribute('visibility', 'visible'); o.onHover?.(null); }
    }

    draw();
    host.addEventListener('mousemove', onMove);
    host.addEventListener('mouseleave', hide);
    if (typeof ResizeObserver !== 'undefined') {
      let last = host.clientWidth;
      ro = new ResizeObserver(() => { if (Math.abs(host.clientWidth - last) > 2) { last = host.clientWidth; draw(); } });
      ro.observe(host);
    }
    return {
      update(next) { Object.assign(o, next); draw(); },
      destroy() { ro?.disconnect(); host.removeEventListener('mousemove', onMove); host.removeEventListener('mouseleave', hide); host.innerHTML = ''; },
    };
  }

  globalThis.RSChart = { line };
})();
