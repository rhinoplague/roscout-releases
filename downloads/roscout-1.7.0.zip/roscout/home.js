// RoScout home: live stats on game tiles, and "Your most played" in place of RoPro's.
(() => {
  const { esc, fmt, fmtFull, pct, ago, send, getSettings, icon, monetization, withMon } = globalThis.RS;
  const HOME_RE = /^\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?home\/?$/i;
  let settings = null;

  // =====================================================================
  // Live stats on game tiles
  // =====================================================================
  // Roblox's wide tiles are <li class="list-item" id="{universeId}">; the older square
  // cards carry the universe id on <a class="game-card-link" id="{universeId}">.
  const stats = new Map();
  const queue = new Set();
  let flushTimer = null;

  function tileTargets(root = document) {
    const out = [];
    for (const li of root.querySelectorAll('li.list-item[id]')) {
      if (/^\d+$/.test(li.id) && !li.closest('.rs-mp, .rsf-root, .rsg-root, .rs-panel')) out.push({ el: li, id: Number(li.id), kind: 'wide' });
    }
    for (const a of root.querySelectorAll('a.game-card-link[id]')) {
      if (/^\d+$/.test(a.id) && !a.closest('.rs-mp, .rsf-root, .rsg-root, .rs-panel, #mostPlayedContainer')) out.push({ el: a, id: Number(a.id), kind: 'card' });
    }
    return out;
  }

  function revDay(st) {
    if (!settings || st.playing == null) return null;
    const robux = st.playing * 24 * withMon(settings, monetization(null, settings)).rph;
    return robux * settings.devex;
  }

  function statRow(st) {
    const rev = settings?.tileRevenue !== false ? revDay(st) : null;
    return `
      <span class="rs-ts-chip rs-ts-live" title="Playing right now">${st.playing ? '<i></i>' : ''}${fmt(st.playing)}</span>
      <span class="rs-ts-chip" title="${fmtFull(st.visits)} visits">${icon('eye', 11)}${fmt(st.visits)}</span>
      ${st.likes != null ? `<span class="rs-ts-chip ${st.likes >= 0.85 ? 'rs-ts-good' : st.likes >= 0.7 ? 'rs-ts-ok' : 'rs-ts-bad'}" title="Like ratio">${icon('thumb', 11)}${pct(st.likes, 0)}</span>` : ''}
      <span class="rs-ts-chip" title="Last updated ${esc(new Date(st.updated).toLocaleString())}">${icon('clock', 11)}${esc(shortAgo(st.updated))}</span>
      ${rev != null && rev >= 1 ? `<span class="rs-ts-chip rs-ts-rev" title="Rough revenue estimate from players right now (RoScout model)">≈$${fmt(rev)}/d</span>` : ''}`;
  }

  function shortAgo(iso) {
    const s = (Date.now() - Date.parse(iso)) / 1000;
    if (!Number.isFinite(s)) return '—';
    if (s < 3600) return `${Math.max(1, Math.round(s / 60))}m`;
    if (s < 86400) return `${Math.round(s / 3600)}h`;
    if (s < 86400 * 60) return `${Math.round(s / 86400)}d`;
    return `${Math.round(s / (86400 * 30.4))}mo`;
  }

  function decorate(t) {
    const st = stats.get(t.id);
    if (!st) return;
    let row = t.el.querySelector(':scope .rs-ts');
    const html = statRow(st);
    if (row) { if (row.dataset.h !== String(st.playing)) { row.innerHTML = html; row.dataset.h = String(st.playing); } return; }
    row = document.createElement('div');
    row.className = `rs-ts rs-ts-${t.kind}`;
    row.dataset.h = String(st.playing);
    row.innerHTML = html;
    if (t.kind === 'wide') {
      const meta = t.el.querySelector('.info-metadata-container') || t.el.querySelector('.info-container') || t.el.querySelector('a.game-card-link');
      meta?.appendChild(row);
    } else {
      const info = t.el.querySelector('.game-card-info');
      if (info) info.insertAdjacentElement('afterend', row); else t.el.appendChild(row);
    }
  }

  function scan() {
    if (settings?.tileStats === false) return;
    for (const t of tileTargets()) {
      if (stats.has(t.id)) decorate(t);
      else queue.add(t.id);
    }
    if (queue.size && !flushTimer) flushTimer = setTimeout(flush, 250);
  }

  async function flush() {
    flushTimer = null;
    const ids = [...queue].slice(0, 100);
    ids.forEach((id) => queue.delete(id));
    try {
      const res = await send({ type: 'tileStats', ids });
      for (const [id, v] of Object.entries(res)) stats.set(Number(id), v);
      // ids Roblox didn't return (private/removed) shouldn't be asked again
      for (const id of ids) if (!stats.has(id)) stats.set(id, null);
    } catch {}
    for (const t of tileTargets()) if (stats.get(t.id)) decorate(t);
    if (queue.size) flushTimer = setTimeout(flush, 250);
  }

  // refresh live player counts every 2 minutes
  setInterval(() => {
    if (document.hidden || settings?.tileStats === false) return;
    const ids = [...stats.keys()].filter((id) => stats.get(id));
    stats.clear();
    ids.forEach((id) => queue.add(id));
    if (!flushTimer) flushTimer = setTimeout(flush, 50);
  }, 2 * 60 * 1000);

  let scanPending = false;
  const obs = new MutationObserver(() => {
    if (scanPending) return;
    scanPending = true;
    requestAnimationFrame(() => { scanPending = false; scan(); });
  });

  // =====================================================================
  // Your most played (replaces RoPro's)
  // =====================================================================
  const MP = { root: null, range: 30, data: null, fallback: null, loading: false, token: 0 };

  function fmtPlay(min) {
    if (min < 1) return '<1m';
    if (min < 60) return `${Math.round(min)}m`;
    const h = Math.floor(min / 60), m = Math.round(min % 60);
    return h < 100 ? `${h}h${m ? ` ${m}m` : ''}` : `${fmt(h)}h`;
  }

  function mpCard(g, mode) {
    const href = g.placeId ? `/games/${g.placeId}` : '#';
    return `
      <a class="rs-mp-card" href="${href}" title="${esc(g.name)}">
        <span class="rs-mp-thumb">${g.icon ? `<img src="${esc(g.icon)}" alt="" loading="lazy">` : icon('gamepad', 28)}
          ${g.playing ? `<em class="rs-mp-live"><i></i>${fmt(g.playing)}</em>` : ''}
        </span>
        <span class="rs-mp-name">${esc(g.name)}</span>
        <span class="rs-mp-sub">${mode === 'played'
          ? `<b>${fmtPlay(g.minutes)}</b> played`
          : `${g.likes != null ? `${pct(g.likes, 0)} liked` : `${fmt(g.visits)} visits`}`}</span>
        ${g.creator?.name ? `<span class="rs-mp-by">by ${esc(g.creator.name)}</span>` : ''}
      </a>`;
  }

  function renderMP() {
    const r = MP.root;
    if (!r) return;
    const d = MP.data;
    const games = d?.games || [];
    const nowPlaying = d?.tracking?.now;
    const total = games.reduce((a, g) => a + g.minutes, 0);
    const useFallback = !games.length && MP.fallback?.length;
    r.innerHTML = `
      <div class="rs-mp-head">
        <div class="rs-mp-title"><span class="rs-logo" aria-hidden="true"><i></i><i></i><i></i></span>Your most played
          ${games.length ? `<em>${fmtPlay(total)} in ${MP.range ? `the past ${MP.range} days` : 'total'}</em>` : ''}
          ${nowPlaying?.n ? `<span class="rs-mp-now"><i></i>Playing ${esc(nowPlaying.n)}</span>` : ''}
        </div>
        <div class="rs-mp-tools">
          <label class="rs-mp-range"><span class="rs-sr">Time range</span>
            <select data-range aria-label="Time range">
              ${[[7, 'Past 7 days'], [30, 'Past 30 days'], [0, 'All time']].map(([v, l]) => `<option value="${v}" ${MP.range === v ? 'selected' : ''}>${l}</option>`).join('')}
            </select>
          </label>
          <button class="rs-mp-arrow" data-scroll="-1" aria-label="Scroll left">${icon('chevron', 16)}</button>
          <button class="rs-mp-arrow" data-scroll="1" aria-label="Scroll right">${icon('chevron', 16)}</button>
        </div>
      </div>
      ${MP.loading && !d ? '<div class="rs-mp-row"><span class="rs-mp-skel"></span><span class="rs-mp-skel"></span><span class="rs-mp-skel"></span><span class="rs-mp-skel"></span><span class="rs-mp-skel"></span></div>'
        : games.length ? `<div class="rs-mp-row">${games.map((g) => mpCard(g, 'played')).join('')}</div>`
        : useFallback ? `<div class="rs-mp-row">${MP.fallback.map((g) => mpCard(g, 'recent')).join('')}</div>
            <p class="rs-mp-note">Showing your recently played games. RoScout started tracking your playtime${d?.tracking?.since ? ` on ${esc(d.tracking.since)}` : ''}; your hours show up here as you play.</p>`
        : `<p class="rs-mp-note">No playtime recorded ${MP.range ? `in the past ${MP.range} days` : 'yet'}. RoScout checks what you're playing every 2 minutes while Chrome is open.</p>`}`;
  }

  async function loadMP() {
    const token = ++MP.token;
    MP.loading = true; renderMP();
    try {
      const d = await send({ type: 'myMostPlayed', days: MP.range });
      if (token !== MP.token) return;
      MP.data = d;
      if (!d.games.length && !MP.fallback) MP.fallback = await recentFallback();
    } catch { MP.data = MP.data || { games: [] }; }
    MP.loading = false;
    renderMP();
  }

  // Roblox's own "Continue" row, used until RoScout has playtime to show.
  async function recentFallback() {
    const head = [...document.querySelectorAll('.home-sort-header-container')].find((h) => /^\s*Continue/i.test(h.textContent));
    const box = head?.closest('.game-sort-carousel-wrapper, [class*="sort"], .section') || head?.parentElement?.parentElement;
    if (!box) return [];
    const ids = tileTargets(box).map((t) => t.id).filter((v, i, a) => a.indexOf(v) === i).slice(0, 16);
    if (!ids.length) return [];
    try { return await send({ type: 'gameCards', ids }); } catch { return []; }
  }

  function waitFor(fn, timeout = 8000) {
    return new Promise((resolve) => {
      const f = fn(); if (f) return resolve(f);
      const o = new MutationObserver(() => { const el = fn(); if (el) { o.disconnect(); resolve(el); } });
      o.observe(document.documentElement, { childList: true, subtree: true });
      setTimeout(() => { o.disconnect(); resolve(null); }, timeout);
    });
  }

  async function mountMP() {
    if (settings?.mostPlayed === false) return;
    if (!MP.root) {
      MP.root = document.createElement('section');
      MP.root.className = 'rs-mp';
      MP.root.addEventListener('change', (e) => { if (e.target.matches('[data-range]')) { MP.range = Number(e.target.value); MP.fallback = MP.fallback || null; loadMP(); } });
      MP.root.addEventListener('click', (e) => {
        const b = e.target.closest('[data-scroll]');
        if (!b) return;
        const row = MP.root.querySelector('.rs-mp-row');
        row?.scrollBy({ left: Number(b.dataset.scroll) * row.clientWidth * 0.85, behavior: 'smooth' });
      });
      try { MP.range = Number(localStorage.getItem('roscout:mpRange') ?? 30); } catch {}
      MP.root.addEventListener('change', () => { try { localStorage.setItem('roscout:mpRange', String(MP.range)); } catch {} });
    }
    // RoPro's widget is the parent of ul#mostPlayedContainer. Take its place.
    const ropro = await waitFor(() => document.querySelector('#mostPlayedContainer')?.parentElement, 5000);
    if (ropro) {
      ropro.classList.add('rs-hide-ropro');
      ropro.insertAdjacentElement('beforebegin', MP.root);
    } else {
      const home = await waitFor(() => document.querySelector('#HomeContainer'), 5000);
      if (!home) return;
      const friends = home.querySelector('.rsf-root');
      if (friends) friends.insertAdjacentElement('afterend', MP.root);
      else home.prepend(MP.root);
    }
    if (!MP.data) loadMP(); else renderMP();
  }

  // =====================================================================
  // Playtime sampler (while a roblox.com tab is open; the extension also samples on its own)
  // =====================================================================
  let csrf = document.querySelector('meta[name="csrf-token"]')?.dataset.token || '';
  async function sampleSelf() {
    const me = Number(document.querySelector('meta[name="user-data"]')?.dataset.userid);
    if (!(me > 0) || document.hidden) return;
    const post = () => fetch('https://presence.roblox.com/v1/presence/users', {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/json', ...(csrf ? { 'X-CSRF-TOKEN': csrf } : {}) },
      body: JSON.stringify({ userIds: [me] }),
    });
    try {
      let res = await post();
      if (res.status === 403 && res.headers.get('x-csrf-token')) { csrf = res.headers.get('x-csrf-token'); res = await post(); }
      if (!res.ok) return;
      const p = (await res.json()).userPresences?.[0];
      await send({ type: 'mePresence', presence: p || null });
    } catch {}
  }

  // =====================================================================
  let lastPath = '';
  function route() {
    if (location.pathname === lastPath) {
      if (MP.root && !MP.root.isConnected && HOME_RE.test(location.pathname)) mountMP();
      return;
    }
    lastPath = location.pathname;
    if (HOME_RE.test(location.pathname)) mountMP();
    else { MP.root?.remove(); }
  }

  (async () => {
    settings = await getSettings();
    try { const me = Number(document.querySelector('meta[name="user-data"]')?.dataset.userid); if (me > 0) chrome.storage.local.set({ myUserId: me }); } catch {}
    route();
    scan();
    obs.observe(document.body, { childList: true, subtree: true });
    setInterval(route, 1000);
    sampleSelf();
    setInterval(sampleSelf, 2 * 60 * 1000);
  })();

  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === 'sync' && ch.settings) getSettings().then((s) => {
      settings = s;
      document.querySelectorAll('.rs-ts').forEach((e) => e.remove());
      if (s.tileStats !== false) scan();
      if (s.mostPlayed === false) { MP.root?.remove(); document.querySelector('.rs-hide-ropro')?.classList.remove('rs-hide-ropro'); }
      else if (HOME_RE.test(location.pathname) && !MP.root?.isConnected) mountMP();
    });
    if (area === 'local' && ch.mpLast && MP.root?.isConnected && !MP.loading) {
      // refresh quietly at most every 5 minutes
      const now = Date.now();
      if (!MP.lastRefresh || now - MP.lastRefresh > 5 * 60 * 1000) { MP.lastRefresh = now; loadMP(); }
    }
  });
})();
