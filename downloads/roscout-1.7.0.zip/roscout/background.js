// RoScout background service worker
// Talks to Roblox's public APIs (no login cookies sent), stores stat snapshots,
// and polls tracked games every 15 minutes to build history.

const POLL_ALARM = 'roscout-poll';
const POLL_MINUTES = 15;
const SNAP_MIN_GAP = 5 * 60 * 1000; // merge snapshots taken < 5 min apart
const MAX_SNAPS = 3000;              // ~31 days at 15-min intervals

const API = {
  universe: (placeId) => `https://apis.roblox.com/universes/v1/places/${placeId}/universe`,
  games: (ids) => `https://games.roblox.com/v1/games?universeIds=${ids.join(',')}`,
  votes: (ids) => `https://games.roblox.com/v1/games/votes?universeIds=${ids.join(',')}`,
  servers: (placeId) =>
    `https://games.roblox.com/v1/games/${placeId}/servers/Public?limit=100&sortOrder=Desc&excludeFullGames=false`,
};

async function getJSON(url) {
  const res = await fetch(url, { credentials: 'omit' });
  if (res.status === 429) throw new Error('Roblox is rate-limiting requests — try again in a minute');
  if (!res.ok) throw new Error(`Roblox API returned ${res.status}`);
  return res.json();
}

const store = {
  async get(key, fallback) {
    const v = (await chrome.storage.local.get(key))[key];
    return v === undefined ? fallback : v;
  },
  set(key, value) {
    return chrome.storage.local.set({ [key]: value });
  },
};

async function getUniverseId(placeId) {
  const key = `uni:${placeId}`;
  const cached = await store.get(key);
  if (cached) return cached;
  const { universeId } = await getJSON(API.universe(placeId));
  if (!universeId) throw new Error('Could not find this experience');
  await store.set(key, universeId);
  return universeId;
}

async function fetchGames(universeIds) {
  const out = {};
  for (let i = 0; i < universeIds.length; i += 50) {
    const chunk = universeIds.slice(i, i + 50);
    const [games, votes] = await Promise.all([
      getJSON(API.games(chunk)),
      getJSON(API.votes(chunk)).catch(() => ({ data: [] })),
    ]);
    for (const g of games.data || []) out[g.id] = { game: g, votes: null };
    for (const v of votes.data || []) if (out[v.id]) out[v.id].votes = v;
  }
  return out;
}

async function fetchServers(placeId, totalPlaying) {
  try {
    const r = await getJSON(API.servers(placeId));
    const list = r.data || [];
    if (!list.length) return { count: 0, more: false, fill: null, avgPing: null, full: 0, estimate: 0 };
    const players = list.reduce((a, s) => a + (s.playing || 0), 0);
    const cap = list.reduce((a, s) => a + (s.maxPlayers || 0), 0);
    const pings = list.map((s) => s.ping).filter(Number.isFinite);
    const more = !!r.nextPageCursor;
    const perServer = players / list.length;
    return {
      count: list.length,
      more,
      fill: cap ? players / cap : null,
      avgPing: pings.length ? Math.round(pings.reduce((a, b) => a + b, 0) / pings.length) : null,
      full: list.filter((s) => s.playing >= s.maxPlayers).length,
      // Only one page is fetched; estimate the total from players per server.
      estimate: more && perServer > 0 ? Math.round(totalPlaying / perServer) : list.length,
    };
  } catch {
    return null;
  }
}

// ---- Daily player-hour aggregates ------------------------------------------
// day:<universeId> = { 'YYYY-MM-DD': [playerHours, coveredHours] }
// Kept for 2 years; the revenue chart turns these into Robux using the
// user's settings, so changing settings re-prices the whole history.
const MAX_GAP = 75 * 60 * 1000; // don't bridge gaps (Chrome closed, etc.)
const DAY_RETENTION = 730;

function dayKey(t) {
  const d = new Date(t);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function addSegment(days, a, b) {
  const dt = b[0] - a[0];
  if (dt <= 0 || dt > MAX_GAP) return;
  const k = dayKey(a[0] + dt / 2);
  const e = days[k] || (days[k] = [0, 0]);
  e[0] = Math.round((e[0] + (((a[1] + b[1]) / 2) * dt) / 36e5) * 100) / 100;
  e[1] = Math.round((e[1] + dt / 36e5) * 1000) / 1000;
}

function buildDays(history) {
  const days = {};
  for (let i = 1; i < history.length; i++) addSegment(days, history[i - 1], history[i]);
  return days;
}

function pruneDays(days) {
  const cutoff = dayKey(Date.now() - DAY_RETENTION * 864e5);
  for (const k of Object.keys(days)) if (k < cutoff) delete days[k];
}

// ---- Hour-of-week heatmap aggregates -----------------------------------------
// hm:<universeId> = 168 buckets (Sun 0:00 … Sat 23:00, local time) of [sumPlayers, samples]
const how = (t) => { const d = new Date(t); return d.getDay() * 24 + d.getHours(); };
function emptyHm() { return Array.from({ length: 168 }, () => [0, 0]); }
function addHm(hm, snap) { const b = hm[how(snap[0])]; b[0] += snap[1]; b[1] += 1; }
function buildHm(history) {
  const hm = emptyHm();
  // one sample per (snapshot) — older versions merged within 5 min, so this is fair
  for (const s of history) addHm(hm, s);
  return hm;
}

// ---- Update detection ---------------------------------------------------------
// upd:<universeId> = [updateTimeMs, ...]  (from the game's "updated" field)
async function detectUpdate(universeId, game) {
  const key = `upd:${universeId}`;
  const list = await store.get(key, null);
  const t = Date.parse(game.updated);
  if (!Number.isFinite(t)) return { list: list || [], isNew: false };
  if (!list) { await store.set(key, [t]); return { list: [t], isNew: false }; }
  if (list.includes(t) || t <= (list.at(-1) || 0)) return { list, isNew: false };
  list.push(t);
  if (list.length > 300) list.splice(0, list.length - 300);
  await store.set(key, list);
  return { list, isNew: true };
}

async function recordSnapshot(universeId, game, votes) {
  const key = `snap:${universeId}`;
  const dkey = `day:${universeId}`;
  const hkey = `hm:${universeId}`;
  const got = await chrome.storage.local.get([key, dkey, hkey]);
  const arr = got[key] || [];
  const days = got[dkey] || buildDays(arr); // backfills from older versions
  const hm = got[hkey] || buildHm(arr);
  const snap = [
    Date.now(),
    game.playing || 0,
    game.visits || 0,
    game.favoritedCount || 0,
    votes?.upVotes || 0,
    votes?.downVotes || 0,
  ];
  const last = arr[arr.length - 1];
  if (last) addSegment(days, last, snap);
  if (last && snap[0] - last[0] < SNAP_MIN_GAP) {
    arr[arr.length - 1] = snap;
  } else {
    arr.push(snap);
    addHm(hm, snap); // only count distinct samples in the heatmap
  }
  if (arr.length > MAX_SNAPS) arr.splice(0, arr.length - MAX_SNAPS);
  pruneDays(days);
  await chrome.storage.local.set({ [key]: arr, [dkey]: days, [hkey]: hm });
  return { history: arr, days, hm };
}

// ---- Alerts -------------------------------------------------------------------
const DEFAULT_ALERTS = { alertSpikes: true, spikeX: 2, alertUpdates: true };
const SPIKE_COOLDOWN = 6 * 36e5;

async function alertSettings() {
  try {
    const { settings } = await chrome.storage.sync.get('settings');
    return { ...DEFAULT_ALERTS, ...(settings || {}) };
  } catch { return { ...DEFAULT_ALERTS }; }
}

function baseline(hm, history, t) {
  const b = hm[how(t)];
  if (b && b[1] >= 3) return b[0] / b[1];
  const day = history.filter((s) => s[0] >= t - 864e5 && s[0] < t - 30 * 60e3);
  if (day.length >= 24) return day.reduce((a, s) => a + s[1], 0) / day.length;
  return null;
}

async function notify(id, title, message, placeId) {
  try {
    await chrome.notifications.create(id, {
      type: 'basic', iconUrl: 'icons/icon128.png', title, message, priority: 1,
    });
    const links = await store.get('notifLinks', {});
    links[id] = placeId;
    const keys = Object.keys(links);
    if (keys.length > 50) for (const k of keys.slice(0, keys.length - 50)) delete links[k];
    await store.set('notifLinks', links);
  } catch {}
}

const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const hourLabel = (h) => `${((h + 11) % 12) + 1} ${h < 12 ? 'AM' : 'PM'}`;
const compact = new Intl.NumberFormat('en', { notation: 'compact', maximumFractionDigits: 1 });

async function checkSpike(id, info, rec, prefs) {
  if (!prefs.alertSpikes) return;
  const now = Date.now();
  const cur = rec.history.at(-1)?.[1] || 0;
  // exclude the sample we just added from the baseline
  const hm = rec.hm.map((b) => b.slice());
  const bk = hm[how(now)]; bk[0] -= cur; bk[1] -= 1;
  const base = baseline(hm, rec.history.slice(0, -1), now);
  if (!base || cur < 50 || cur < base * prefs.spikeX) return;
  const lastKey = `alerted:${id}`;
  if (now - (await store.get(lastKey, 0)) < SPIKE_COOLDOWN) return;
  await store.set(lastKey, now);
  const d = new Date(now);
  await notify(`spike:${id}:${now}`, `🚀 ${info.name} is spiking`,
    `${compact.format(cur)} playing — ${(cur / base).toFixed(1)}× its usual ${compact.format(base)} for ${DAY_NAMES[d.getDay()]} ${hourLabel(d.getHours())}.`,
    info.placeId);
}

async function poll() {
  const tracked = await store.get('tracked', {});
  const ids = Object.keys(tracked).map(Number);
  if (!ids.length) return;
  const prefs = await alertSettings();
  const data = await fetchGames(ids);
  for (const id of ids) {
    const entry = data[id];
    if (!entry) continue;
    tracked[id].name = entry.game.name;
    tracked[id].creator = creatorLite(entry.game.creator) || tracked[id].creator || null;
    try { tracked[id].passPrices = passPrices(await passesFor(id)); } catch {}
    const rec = await recordSnapshot(id, entry.game, entry.votes);
    const upd = await detectUpdate(id, entry.game);
    if (upd.isNew && prefs.alertUpdates) {
      await notify(`upd:${id}:${Date.now()}`, `🛠️ ${entry.game.name} just updated`,
        `Published ${new Date(upd.list.at(-1)).toLocaleString([], { weekday: 'short', hour: 'numeric', minute: '2-digit' })}. RoScout will measure the player impact over the next 24h.`,
        tracked[id].placeId);
    }
    await checkSpike(id, tracked[id], rec, prefs);
  }
  await store.set('tracked', tracked);
  await store.set('lastPoll', Date.now());
}

async function ensureAlarm() {
  const existing = await chrome.alarms.get(POLL_ALARM);
  if (!existing) chrome.alarms.create(POLL_ALARM, { periodInMinutes: POLL_MINUTES, delayInMinutes: 1 });
}

async function gameBundle(ids) {
  const keys = ids.flatMap((id) => [`snap:${id}`, `day:${id}`, `upd:${id}`, `hm:${id}`]);
  const got = keys.length ? await chrome.storage.local.get(keys) : {};
  return (id) => ({
    history: got[`snap:${id}`] || [],
    days: got[`day:${id}`] || {},
    updates: got[`upd:${id}`] || [],
    hm: got[`hm:${id}`] || null,
  });
}

// ---- Creator (group/studio or user) and places -------------------------------
const META_TTL = 60 * 60 * 1000;

async function cached(key, ttl, fn) {
  const hit = await store.get(key, null);
  if (hit && Date.now() - hit.t < ttl) return hit.v;
  try {
    const v = await fn();
    await store.set(key, { t: Date.now(), v });
    return v;
  } catch (e) {
    if (hit) return hit.v; // stale beats nothing
    throw e;
  }
}

function creatorInfo(creator) {
  if (!creator?.id) return Promise.resolve(null);
  const type = creator.type === 'Group' ? 'Group' : 'User';
  return cached(`cr:${type}:${creator.id}`, META_TTL, async () => {
    if (type === 'Group') {
      const [g, icon] = await Promise.all([
        getJSON(`https://groups.roblox.com/v1/groups/${creator.id}`),
        getJSON(`https://thumbnails.roblox.com/v1/groups/icons?groupIds=${creator.id}&size=150x150&format=Png&isCircular=false`).catch(() => ({ data: [] })),
      ]);
      return {
        id: creator.id, type, name: g.name || creator.name, members: g.memberCount ?? null,
        owner: g.owner ? (g.owner.displayName || g.owner.username) : null,
        ownerId: g.owner?.userId || null,
        verified: !!(g.hasVerifiedBadge || creator.hasVerifiedBadge),
        icon: icon.data?.[0]?.imageUrl || '',
        url: `https://www.roblox.com/communities/${creator.id}`,
      };
    }
    const [u, head] = await Promise.all([
      getJSON(`https://users.roblox.com/v1/users/${creator.id}`),
      getJSON(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${creator.id}&size=150x150&format=Png&isCircular=false`).catch(() => ({ data: [] })),
    ]);
    return {
      id: creator.id, type, name: u.displayName || u.name || creator.name, handle: u.name || creator.name,
      verified: !!(u.hasVerifiedBadge || creator.hasVerifiedBadge),
      icon: head.data?.[0]?.imageUrl || '',
      url: `https://www.roblox.com/users/${creator.id}/profile`,
    };
  });
}

// Every place in the experience (start place + sub-places). Public places only.
function placesFor(universeId) {
  return cached(`pl:${universeId}`, META_TTL, async () => {
    const out = [];
    let cursor = '';
    for (let page = 0; page < 5; page++) {
      const r = await getJSON(`https://develop.roblox.com/v1/universes/${universeId}/places?limit=100${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ''}`);
      for (const p of r.data || []) out.push({ id: p.id, name: p.name || `Place ${p.id}` });
      cursor = r.nextPageCursor || '';
      if (!cursor) break;
    }
    return out;
  });
}

// ---- Game passes + badges ------------------------------------------------------
const chunk = (arr, n) => Array.from({ length: Math.ceil(arr.length / n) }, (_, i) => arr.slice(i * n, i * n + n));

async function iconMap(kind, ids) {
  const out = {};
  const base = {
    pass: (c) => `https://thumbnails.roblox.com/v1/game-passes?gamePassIds=${c.join(',')}&size=150x150&format=Png&isCircular=false`,
    badge: (c) => `https://thumbnails.roblox.com/v1/badges/icons?badgeIds=${c.join(',')}&size=150x150&format=Png&isCircular=false`,
    group: (c) => `https://thumbnails.roblox.com/v1/groups/icons?groupIds=${c.join(',')}&size=150x150&format=Png&isCircular=false`,
    game: (c) => `https://thumbnails.roblox.com/v1/games/icons?universeIds=${c.join(',')}&size=150x150&format=Png&isCircular=false&returnPolicy=PlaceHolder`,
  }[kind];
  await Promise.all(chunk(ids, 100).map(async (c) => {
    try {
      const r = await getJSON(base(c));
      for (const t of r.data || []) if (t.imageUrl) out[t.targetId] = t.imageUrl;
    } catch {}
  }));
  return out;
}

function passesFor(universeId) {
  return cached(`gp:${universeId}`, META_TTL, async () => {
    const list = [];
    let token = '';
    for (let page = 0; page < 5; page++) {
      const r = await getJSON(`https://apis.roblox.com/game-passes/v1/universes/${universeId}/game-passes?passView=Full&pageSize=100${token ? `&pageToken=${encodeURIComponent(token)}` : ''}`);
      for (const p of r.gamePasses || r.data || []) {
        list.push({ id: p.id, name: p.displayName || p.name || 'Game pass', price: p.price ?? null, forSale: !!p.isForSale });
      }
      token = r.nextPageToken || '';
      if (!token) break;
    }
    const icons = await iconMap('pass', list.map((p) => p.id));
    for (const p of list) p.icon = icons[p.id] || '';
    return list;
  });
}

function badgesFor(universeId) {
  return cached(`bd:${universeId}`, 30 * 60 * 1000, async () => {
    const list = [];
    let cursor = '';
    for (let page = 0; page < 3; page++) {
      const r = await getJSON(`https://badges.roblox.com/v1/universes/${universeId}/badges?limit=100&sortOrder=Asc${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ''}`);
      for (const b of r.data || []) {
        if (b.enabled === false) continue;
        list.push({
          id: b.id, name: b.displayName || b.name, awarded: b.statistics?.awardedCount || 0,
          pastDay: b.statistics?.pastDayAwardedCount || 0, winRate: b.statistics?.winRatePercentage ?? null,
        });
      }
      cursor = r.nextPageCursor || '';
      if (!cursor) break;
    }
    const icons = await iconMap('badge', list.map((b) => b.id));
    for (const b of list) b.icon = icons[b.id] || '';
    return list;
  });
}

const passPrices = (passes) => (passes || []).filter((p) => p.forSale && p.price > 0).map((p) => p.price);

// ---- Communities ----------------------------------------------------------------
// Per-group game stats: games (public), live players, visits.
function groupStats(groupId) {
  return cached(`gs:${groupId}`, 15 * 60 * 1000, async () => {
    const r = await getJSON(`https://games.roblox.com/v2/groups/${groupId}/gamesV2?accessFilter=2&limit=50&sortOrder=Desc`);
    const ids = (r.data || []).map((g) => g.id);
    if (!ids.length) return { games: [], playing: 0, visits: 0 };
    const details = await fetchGames(ids);
    const icons = await iconMap('game', ids);
    const games = ids.map((id) => {
      const d = details[id];
      if (!d) return null;
      const up = d.votes?.upVotes || 0, down = d.votes?.downVotes || 0;
      return {
        id, placeId: d.game.rootPlaceId, name: d.game.name, playing: d.game.playing || 0, visits: d.game.visits || 0,
        favorites: d.game.favoritedCount || 0, likes: up + down >= 3 ? up / (up + down) : null, updated: d.game.updated, icon: icons[id] || '',
      };
    }).filter(Boolean).sort((a, b) => b.playing - a.playing || b.visits - a.visits);
    return {
      games,
      playing: games.reduce((s, g) => s + g.playing, 0),
      visits: games.reduce((s, g) => s + g.visits, 0),
    };
  });
}

// Run async jobs with limited parallelism so big community lists don't hammer Roblox.
async function pool(items, n, fn) {
  const out = new Array(items.length);
  let i = 0;
  await Promise.all(Array.from({ length: Math.min(n, items.length) }, async () => {
    while (i < items.length) { const k = i++; try { out[k] = await fn(items[k]); } catch { out[k] = null; } }
  }));
  return out;
}

const creatorLite = (c) => (c?.id ? { id: c.id, name: c.name, type: c.type === 'Group' ? 'Group' : 'User' } : null);

// ---- Profile creator card ----------------------------------------------------
// Everything here is public Roblox data, fetched without cookies and cached 10 min.
const PROFILE_TTL = 10 * 60 * 1000;

async function thumbs(kind, ids) {
  if (!ids.length) return {};
  const url = kind === 'user'
    ? `https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${ids.join(',')}&size=150x150&format=Png&isCircular=false`
    : `https://thumbnails.roblox.com/v1/games/icons?universeIds=${ids.join(',')}&size=150x150&format=Png&isCircular=false&returnPolicy=PlaceHolder`;
  try {
    const r = await getJSON(url);
    return Object.fromEntries((r.data || []).filter((t) => t.imageUrl).map((t) => [t.targetId, t.imageUrl]));
  } catch { return {}; }
}

async function buildProfile(userId) {
  const [user, own, roles] = await Promise.all([
    getJSON(`https://users.roblox.com/v1/users/${userId}`),
    getJSON(`https://games.roblox.com/v2/users/${userId}/games?accessFilter=2&limit=50&sortOrder=Desc`).catch(() => ({ data: [] })),
    getJSON(`https://groups.roblox.com/v2/users/${userId}/groups/roles`).catch(() => ({ data: [] })),
  ]);

  // groups where they hold a top role (owner/admin level), biggest first
  const groups = (roles.data || [])
    .filter((g) => (g.role?.rank || 0) >= 253)
    .sort((a, b) => (b.group?.memberCount || 0) - (a.group?.memberCount || 0))
    .slice(0, 4)
    .map((g) => ({ id: g.group.id, name: g.group.name, members: g.group.memberCount || 0, role: g.role.name, rank: g.role.rank }));

  const groupGames = [];
  await Promise.all(groups.slice(0, 3).map(async (g) => {
    try {
      const r = await getJSON(`https://games.roblox.com/v2/groups/${g.id}/gamesV2?accessFilter=2&limit=10&sortOrder=Desc`);
      for (const x of r.data || []) groupGames.push({ id: x.id, group: g.name, role: g.role });
    } catch {}
  }));

  const ownIds = (own.data || []).map((g) => g.id);
  const allIds = [...new Set([...ownIds, ...groupGames.map((g) => g.id)])];
  const [details, icons, heads] = await Promise.all([
    allIds.length ? fetchGames(allIds) : {},
    thumbs('game', allIds.slice(0, 100)),
    thumbs('user', [userId]),
  ]);

  const toGame = (id, extra = {}) => {
    const d = details[id];
    if (!d) return null;
    const up = d.votes?.upVotes || 0, down = d.votes?.downVotes || 0;
    return {
      id, placeId: d.game.rootPlaceId, name: d.game.name, playing: d.game.playing || 0, visits: d.game.visits || 0,
      favorites: d.game.favoritedCount || 0, likes: up + down ? up / (up + down) : null, votes: up + down,
      updated: d.game.updated, icon: icons[id] || '', ...extra,
    };
  };
  const ownGames = ownIds.map((id) => toGame(id)).filter(Boolean);
  const teamGames = groupGames.filter((g) => !ownIds.includes(g.id))
    .map((g) => toGame(g.id, { group: g.group, role: g.role })).filter(Boolean);

  return {
    t: Date.now(),
    user: { id: user.id, name: user.name, displayName: user.displayName, description: user.description || '', created: user.created, verified: !!user.hasVerifiedBadge },
    headshot: heads[userId] || '',
    ownGames, teamGames, groups,
  };
}

// ---- Tile stats (home / discover / charts) --------------------------------------
const tileCache = new Map(); // universeId -> { t, v }
const TILE_TTL = 2 * 60 * 1000;

async function tileStats(ids) {
  const now = Date.now();
  const out = {};
  const need = [];
  for (const id of ids) {
    const c = tileCache.get(id);
    if (c && now - c.t < TILE_TTL) out[id] = c.v; else need.push(id);
  }
  if (need.length) {
    const d = await fetchGames(need);
    for (const id of need) {
      const e = d[id];
      if (!e) continue;
      const up = e.votes?.upVotes || 0, down = e.votes?.downVotes || 0;
      const v = {
        playing: e.game.playing || 0, visits: e.game.visits || 0, favorites: e.game.favoritedCount || 0,
        likes: up + down >= 3 ? up / (up + down) : null, updated: e.game.updated, created: e.game.created,
        creator: creatorLite(e.game.creator), placeId: e.game.rootPlaceId, name: e.game.name,
      };
      tileCache.set(id, { t: now, v });
      out[id] = v;
    }
  }
  if (tileCache.size > 3000) for (const k of [...tileCache.keys()].slice(0, 1000)) tileCache.delete(k);
  return out;
}

// ---- Your own playtime ("Your most played") --------------------------------------
// mp:YYYY-MM-DD = { universeId: { m: minutes, p: placeId, n: name } }
const ME_ALARM = 'roscout-me';
const MP_GAP_MAX = 5 * 60 * 1000;
const MP_DAYS = 400;
let csrfToken = '';

async function myPresence(userId) {
  const req = () => fetch('https://presence.roblox.com/v1/presence/users', {
    method: 'POST', credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...(csrfToken ? { 'X-CSRF-TOKEN': csrfToken } : {}) },
    body: JSON.stringify({ userIds: [userId] }),
  });
  let res = await req();
  if (res.status === 403 && res.headers.get('x-csrf-token')) { csrfToken = res.headers.get('x-csrf-token'); res = await req(); }
  if (!res.ok) throw new Error(`presence ${res.status}`);
  return (await res.json()).userPresences?.[0] || null;
}

// Credit time to whatever game you're in. Called by the alarm and by open roblox.com tabs;
// mpLast keeps the two from double counting.
async function recordMyPresence(p) {
  const now = Date.now();
  const got = await chrome.storage.local.get(['mpLast', 'mpDays', 'mpNow']);
  const last = got.mpLast || 0;
  if (now - last < 50 * 1000) return { skipped: true };
  const inGame = p && p.userPresenceType === 2 && (p.universeId || p.rootPlaceId || p.placeId);
  const writes = { mpLast: now, mpNow: inGame ? { u: p.universeId || null, p: p.rootPlaceId || p.placeId, n: p.lastLocation || '', since: got.mpNow?.u === p.universeId ? got.mpNow.since : now } : null };
  if (inGame && last && now - last <= MP_GAP_MAX) {
    const k = `mp:${dayKey(now - (now - last) / 2)}`;
    const day = (await chrome.storage.local.get(k))[k] || {};
    const id = p.universeId || `p${p.rootPlaceId || p.placeId}`;
    const e = day[id] || (day[id] = { m: 0, p: p.rootPlaceId || p.placeId, n: '' });
    if (p.lastLocation) e.n = p.lastLocation;
    e.m = Math.round((e.m + (now - last) / 60000) * 10) / 10;
    writes[k] = day;
    const days = new Set(got.mpDays || []); days.add(k);
    const sorted = [...days].sort();
    const drop = sorted.slice(0, Math.max(0, sorted.length - MP_DAYS));
    if (drop.length) await chrome.storage.local.remove(drop);
    writes.mpDays = sorted.slice(-MP_DAYS);
  }
  await chrome.storage.local.set(writes);
  return { ok: true };
}

async function sampleMe() {
  const { myUserId } = await chrome.storage.local.get('myUserId');
  if (!myUserId) return;
  try { await recordMyPresence(await myPresence(myUserId)); } catch {}
}

async function ensureMeAlarm() {
  if (!(await chrome.alarms.get(ME_ALARM))) chrome.alarms.create(ME_ALARM, { periodInMinutes: 2, delayInMinutes: 0.5 });
}

async function mostPlayed(days) {
  const { mpDays = [], mpNow, mpLast } = await chrome.storage.local.get(['mpDays', 'mpNow', 'mpLast']);
  const cutoff = days ? `mp:${dayKey(Date.now() - (days - 1) * 864e5)}` : '';
  const keys = mpDays.filter((k) => k >= cutoff);
  const got = keys.length ? await chrome.storage.local.get(keys) : {};
  const agg = new Map();
  for (const k of keys) for (const [id, e] of Object.entries(got[k] || {})) {
    const a = agg.get(id) || { id, m: 0, p: e.p, n: e.n, days: 0, last: k };
    a.m += e.m; a.days += 1; if (k > a.last) a.last = k; if (e.n) a.n = e.n;
    agg.set(id, a);
  }
  const top = [...agg.values()].sort((a, b) => b.m - a.m).slice(0, 24);
  const uids = top.map((a) => Number(a.id)).filter(Boolean);
  const [stats, icons] = await Promise.all([uids.length ? tileStats(uids) : {}, iconMap('game', uids)]);
  return {
    tracking: { since: mpDays[0]?.slice(3) || null, lastSample: mpLast || null, now: mpNow || null },
    games: top.map((a) => {
      const st = stats[a.id] || {};
      return { universeId: Number(a.id) || null, placeId: st.placeId || a.p, name: st.name || a.n || 'Unknown experience', minutes: a.m, days: a.days, lastDay: a.last.slice(3),
        playing: st.playing ?? null, likes: st.likes ?? null, creator: st.creator || null, icon: icons[a.id] || '' };
    }),
  };
}

const handlers = {
  async tileStats({ ids }) { return tileStats(ids.map(Number).filter(Boolean).slice(0, 200)); },
  async mePresence({ presence }) { return recordMyPresence(presence); },
  async myMostPlayed({ days }) { return mostPlayed(days); },
  async gameCards({ ids }) {
    const uids = ids.map(Number).filter(Boolean).slice(0, 60);
    const [stats, icons] = await Promise.all([tileStats(uids), iconMap('game', uids)]);
    return uids.map((id) => stats[id] ? { universeId: id, ...stats[id], icon: icons[id] || '' } : null).filter(Boolean);
  },

  async profileData({ userId, fresh }) {
    const key = `prof:${userId}`;
    const cached = await store.get(key, null);
    if (!fresh && cached && Date.now() - cached.t < PROFILE_TTL) return cached;
    const data = await buildProfile(userId);
    await store.set(key, data);
    // keep the cache small: drop the oldest profiles past 30
    const all = await chrome.storage.local.get(null);
    const profs = Object.keys(all).filter((k) => k.startsWith('prof:')).sort((a, b) => all[a].t - all[b].t);
    if (profs.length > 30) await chrome.storage.local.remove(profs.slice(0, profs.length - 30));
    return data;
  },

  async getStats({ placeId }) {
    const universeId = await getUniverseId(placeId);
    const data = await fetchGames([universeId]);
    const entry = data[universeId];
    if (!entry) throw new Error('No stats returned for this experience');
    const [servers, rec, tracked, upd, creator, places, passes, badges] = await Promise.all([
      fetchServers(placeId, entry.game.playing || 0),
      recordSnapshot(universeId, entry.game, entry.votes),
      store.get('tracked', {}),
      detectUpdate(universeId, entry.game),
      creatorInfo(entry.game.creator).catch(() => null),
      placesFor(universeId).catch(() => []),
      passesFor(universeId).catch(() => null),
      badgesFor(universeId).catch(() => null),
    ]);
    const gameIcon = (await cached(`gi:${universeId}`, META_TTL, () => iconMap('game', [universeId])).catch(() => ({})))[universeId] || '';
    if (tracked[universeId]) {
      tracked[universeId].creator = tracked[universeId].creator || creatorLite(entry.game.creator);
      if (passes) tracked[universeId].passPrices = passPrices(passes);
      await store.set('tracked', tracked);
    }
    return {
      universeId, placeId: Number(placeId), ...entry, servers,
      creator: creator || (entry.game.creator ? { ...creatorLite(entry.game.creator), icon: '' } : null),
      places, passes, badges, icon: gameIcon,
      history: rec.history, days: rec.days, hm: rec.hm, updates: upd.list,
      tracked: !!tracked[universeId],
    };
  },

  async toggleTrack({ placeId, universeId, name, creator }) {
    const tracked = await store.get('tracked', {});
    const isTracked = !!tracked[universeId];
    if (isTracked) delete tracked[universeId];
    else tracked[universeId] = { placeId, name, creator: creator || null, addedAt: Date.now() };
    await store.set('tracked', tracked);
    await ensureAlarm();
    return { tracked: !isTracked };
  },

  // Track by place id (used by the dashboard's friends-trends "Track" button)
  async trackPlace({ placeId }) {
    const universeId = await getUniverseId(placeId);
    const tracked = await store.get('tracked', {});
    if (!tracked[universeId]) {
      const data = await fetchGames([universeId]);
      const entry = data[universeId];
      tracked[universeId] = {
        placeId: entry?.game?.rootPlaceId || placeId, name: entry?.game?.name || 'Untitled',
        creator: creatorLite(entry?.game?.creator), addedAt: Date.now(),
      };
      await store.set('tracked', tracked);
      if (entry) { await recordSnapshot(universeId, entry.game, entry.votes); await detectUpdate(universeId, entry.game); }
      await ensureAlarm();
    }
    return { universeId, tracked: true };
  },

  async untrack({ universeId }) {
    const tracked = await store.get('tracked', {});
    delete tracked[universeId];
    await store.set('tracked', tracked);
    return { ok: true };
  },

  async getTracked() {
    const tracked = await store.get('tracked', {});
    const ids = Object.keys(tracked);
    const missing = ids.filter((id) => !tracked[id].creator);
    if (missing.length) {
      try {
        const d = await fetchGames(missing.map(Number));
        for (const id of missing) if (d[id]) tracked[id].creator = creatorLite(d[id].game.creator);
        await store.set('tracked', tracked);
      } catch {}
    }
    const bundle = await gameBundle(ids);
    const games = ids.map((id) => ({ universeId: Number(id), ...tracked[id], ...bundle(id) }));
    games.sort((a, b) => (b.history.at(-1)?.[1] || 0) - (a.history.at(-1)?.[1] || 0));
    return { games, lastPoll: await store.get('lastPoll', null) };
  },

  async pollNow() {
    await poll();
    return handlers.getTracked();
  },

  // ---- Communities ----
  async groupSearch({ keyword, cursor }) {
    const r = await getJSON(`https://groups.roblox.com/v1/groups/search?keyword=${encodeURIComponent(keyword)}&prioritizeExactMatch=true&limit=25${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ''}`);
    const list = (r.data || []).map((g) => ({
      id: g.id, name: g.name, description: g.description || '', members: g.memberCount || 0,
      verified: !!g.hasVerifiedBadge, isPublic: !!g.publicEntryAllowed, previousName: g.previousName || '',
    }));
    const icons = await iconMap('group', list.map((g) => g.id));
    for (const g of list) g.icon = icons[g.id] || '';
    return { list, next: r.nextPageCursor || '', total: r.totalResults || list.length };
  },

  async groupStatsMany({ ids }) {
    const res = await pool(ids, 4, (id) => groupStats(id));
    return Object.fromEntries(ids.map((id, i) => [id, res[i]]));
  },

  async groupCard({ groupId }) {
    const [g, icons, stats] = await Promise.all([
      getJSON(`https://groups.roblox.com/v1/groups/${groupId}`),
      iconMap('group', [groupId]),
      groupStats(groupId).catch(() => ({ games: [], playing: 0, visits: 0 })),
    ]);
    return {
      id: g.id, name: g.name, description: g.description || '', members: g.memberCount || 0,
      verified: !!g.hasVerifiedBadge, isPublic: !!g.publicEntryAllowed,
      owner: g.owner ? { id: g.owner.userId, name: g.owner.username, displayName: g.owner.displayName } : null,
      icon: icons[groupId] || '', ...stats,
    };
  },

  async myCommunities({ userId }) {
    const [roles, primary] = await Promise.all([
      getJSON(`https://groups.roblox.com/v2/users/${userId}/groups/roles`),
      getJSON(`https://groups.roblox.com/v1/users/${userId}/groups/primary/role`).catch(() => null),
    ]);
    const list = (roles.data || []).map((r) => ({
      id: r.group.id, name: r.group.name, members: r.group.memberCount || 0, verified: !!r.group.hasVerifiedBadge,
      role: r.role?.name || 'Member', rank: r.role?.rank || 0, owned: (r.role?.rank || 0) === 255,
      primary: primary?.group?.id === r.group.id,
    }));
    const icons = await iconMap('group', list.map((g) => g.id));
    for (const g of list) g.icon = icons[g.id] || '';
    await store.set('myUserId', userId);
    return { userId, list };
  },
};

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  const fn = handlers[msg?.type];
  if (!fn) return false;
  fn(msg).then(sendResponse, (e) => sendResponse({ error: e?.message || String(e) }));
  return true; // async response
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === POLL_ALARM) poll().catch(() => {});
  if (alarm.name === ME_ALARM) sampleMe();
});

chrome.notifications.onClicked.addListener(async (id) => {
  const links = await store.get('notifLinks', {});
  if (links[id]) chrome.tabs.create({ url: `https://www.roblox.com/games/${links[id]}` });
  chrome.notifications.clear(id);
});

// ---- Updates -----------------------------------------------------------------------
// Chrome Web Store installs: apply a new version the moment Chrome downloads it,
// instead of waiting for the browser to restart, and ask Chrome to check every 3 hours.
// Unpacked installs (testers): read version.json from the GitHub repo and show a banner.
const UPDATE_FEED = 'https://raw.githubusercontent.com/rhinoplague/roscout-releases/main/version.json';
const UPDATE_ALARM = 'roscout-update';
const isStoreInstall = () => !!chrome.runtime.getManifest().update_url;

function newer(a, b) {
  const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(x.length, y.length); i++) {
    if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
  }
  return false;
}

async function checkForUpdate() {
  const current = chrome.runtime.getManifest().version;
  if (isStoreInstall()) {
    const [status, details] = await new Promise((r) => chrome.runtime.requestUpdateCheck((st, d) => r([st, d])));
    const info = { store: true, current, status, latest: details?.version || current, checked: Date.now() };
    await store.set('updateInfo', info);
    return info;
  }
    const feed = await (await fetch(`${UPDATE_FEED}?t=${Date.now()}`, { cache: 'no-store' })).json();
  const info = {
    store: false, current, configured: true, latest: feed.version, notes: feed.notes || [],
    download: feed.download || '', published: feed.published || '', available: newer(feed.version, current), checked: Date.now(),
  };
  await store.set('updateInfo', info);
  return info;
}

chrome.runtime.onUpdateAvailable.addListener(() => chrome.runtime.reload());

handlers.checkUpdate = async () => checkForUpdate();
handlers.getUpdateInfo = async () => ({ ...(await store.get('updateInfo', {})), current: chrome.runtime.getManifest().version, store: isStoreInstall() });

async function ensureUpdateAlarm() {
  if (!(await chrome.alarms.get(UPDATE_ALARM))) chrome.alarms.create(UPDATE_ALARM, { periodInMinutes: 180, delayInMinutes: 1 });
}
chrome.alarms.onAlarm.addListener((a) => { if (a.name === UPDATE_ALARM) checkForUpdate().catch(() => {}); });

chrome.runtime.onInstalled.addListener(() => { ensureAlarm(); ensureMeAlarm(); ensureUpdateAlarm(); });
chrome.runtime.onStartup.addListener(() => { ensureAlarm(); ensureMeAlarm(); ensureUpdateAlarm(); });
ensureMeAlarm();
ensureUpdateAlarm();
