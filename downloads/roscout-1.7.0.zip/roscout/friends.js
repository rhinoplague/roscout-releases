// RoScout friends hub — replaces the homepage friends row with every friend,
// grouped by the experience they're in, plus who's building in Studio.
// Also samples friends' presence every few minutes on any roblox.com tab to
// power session times and the "friends are playing" trends in the dashboard.
// All requests go straight from this page to roblox.com APIs with your normal
// Roblox session; nothing is sent anywhere else.
(() => {
  const { esc, fmt, fmtDur, dayKey } = globalThis.RS;

  const HOME_RE = /^(\/[a-z]{2}(-[a-z]{2})?)?\/home\/?$/i;
  const PRESENCE_EVERY = 30 * 1000;
  const FRIENDS_EVERY = 5 * 60 * 1000;
  const SAMPLE_EVERY = 2 * 60 * 1000;     // trend/session sampling interval
  const SAMPLE_GAP_MAX = 10 * 60 * 1000;  // longer gaps aren't credited
  const TREND_DAYS = 60;
  const SERVER_COLORS = ['#3ddc84', '#5aa9ff', '#f5c242', '#ff7ab6', '#b48cff', '#ff9a4d', '#4fe0d6'];
  const TYPE = { OFFLINE: 0, ONLINE: 1, GAME: 2, STUDIO: 3, INVISIBLE: 4 };

  const local = chrome.storage.local;
  let root = null;
  let me = null;
  let friends = [];             // [{ id, name, displayName }]
  let presence = new Map();     // id -> presence
  let sessions = {};            // id -> { k, since, exact }
  let pinned = new Set();
  const headshots = new Map();  // userId -> url
  const icons = new Map();      // placeId -> url
  const playing = new Map();    // universeId -> playing count
  const creators = new Map();   // universeId -> { id, name, type }
  let filter = 'all';
  let query = '';
  let showOffline = false;
  let lastFriends = 0;
  let status = 'loading';
  let errorMsg = '';

  // ---- API ------------------------------------------------------------------
  let csrf = document.querySelector('meta[name="csrf-token"]')?.dataset.token || '';

  async function api(url, body) {
    const opts = { credentials: 'include', headers: {} };
    if (body) {
      opts.method = 'POST';
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
      if (csrf) opts.headers['X-CSRF-TOKEN'] = csrf;
    }
    let res = await fetch(url, opts);
    if (res.status === 403 && body) {
      const t = res.headers.get('x-csrf-token');
      if (t) { csrf = t; opts.headers['X-CSRF-TOKEN'] = t; res = await fetch(url, opts); }
    }
    if (!res.ok) throw new Error(`Roblox API ${res.status}`);
    return res.json();
  }

  const chunks = (arr, n) => Array.from({ length: Math.ceil(arr.length / n) }, (_, i) => arr.slice(i * n, i * n + n));

  function getMeSync() {
    const id = Number(document.querySelector('meta[name="user-data"]')?.dataset.userid);
    return Number.isFinite(id) && id > 0 ? id : null;
  }

  async function getMe() {
    const id = getMeSync();
    if (id) return id;
    const r = await api('https://users.roblox.com/v1/users/authenticated');
    return r.id;
  }

  async function fetchFriendList(userId) {
    let list = [];
    try {
      const r = await api(`https://friends.roblox.com/v1/users/${userId}/friends`);
      list = (r.data || []).map((f) => ({ id: f.id, name: f.name || '', displayName: f.displayName || '' }));
    } catch {}
    if (!list.length) {
      let cursor = '';
      for (let page = 0; page < 40; page++) {
        const r = await api(`https://friends.roblox.com/v1/users/${userId}/friends/find?limit=50${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ''}`);
        const items = r.PageItems || r.data || [];
        list.push(...items.map((f) => ({ id: f.id, name: f.name || '', displayName: f.displayName || '' })));
        cursor = r.NextCursor || r.nextPageCursor || '';
        if (!cursor) break;
      }
    }
    const missing = list.filter((f) => !f.name).map((f) => f.id);
    if (missing.length) {
      const names = new Map();
      for (const c of chunks(missing, 100)) {
        try {
          const r = await api('https://users.roblox.com/v1/users', { userIds: c, excludeBannedUsers: false });
          for (const u of r.data || []) names.set(u.id, u);
        } catch {}
      }
      for (const f of list) {
        const u = names.get(f.id);
        if (u) { f.name = u.name; f.displayName = u.displayName; }
      }
    }
    // cache for the background sampler and the dashboard
    const nameMap = {};
    for (const f of list) nameMap[f.id] = [f.name, f.displayName];
    await local.set({ friendCache: { t: Date.now(), ids: list.map((f) => f.id), names: nameMap } });
    return list;
  }

  async function loadFriends() {
    friends = await fetchFriendList(me);
    lastFriends = Date.now();
    await loadHeadshots(friends.map((f) => f.id));
  }

  async function loadHeadshots(ids) {
    const need = ids.filter((id) => !headshots.has(id));
    for (const c of chunks(need, 100)) {
      try {
        const r = await api(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${c.join(',')}&size=48x48&format=Png&isCircular=false`);
        for (const t of r.data || []) if (t.imageUrl) headshots.set(t.targetId, t.imageUrl);
      } catch {}
    }
  }

  async function fetchPresence(ids) {
    const out = [];
    for (const c of chunks(ids, 50)) {
      const r = await api('https://presence.roblox.com/v1/presence/users', { userIds: c });
      out.push(...(r.userPresences || []));
    }
    return out;
  }

  async function loadPresence() {
    const list = await fetchPresence(friends.map((f) => f.id));
    presence = new Map(list.map((p) => [p.userId, p]));
    await recordSample(list);

    const places = [...new Set(list.map((p) => p.rootPlaceId || p.placeId).filter(Boolean))].filter((id) => !icons.has(id));
    for (const c of chunks(places, 100)) {
      try {
        const r = await api(`https://thumbnails.roblox.com/v1/places/gameicons?placeIds=${c.join(',')}&size=50x50&format=Png&isCircular=false&returnPolicy=PlaceHolder`);
        for (const t of r.data || []) if (t.imageUrl) icons.set(t.targetId, t.imageUrl);
      } catch {}
    }
    const unis = [...new Set(list.filter((p) => p.userPresenceType === TYPE.GAME || p.userPresenceType === TYPE.STUDIO).map((p) => p.universeId).filter(Boolean))];
    for (const c of chunks(unis, 50)) {
      try {
        const r = await api(`https://games.roblox.com/v1/games?universeIds=${c.join(',')}`);
        for (const g of r.data || []) {
          playing.set(g.id, g.playing);
          if (g.creator?.id) creators.set(g.id, { id: g.creator.id, name: g.creator.name, type: g.creator.type });
        }
      } catch {}
    }
  }

  // ---- Sampling: sessions + friends-are-playing trends -----------------------
  // fsess = { userId: { k: "type:place", since, exact } }
  // ft:YYYY-MM-DD = { placeId: { n: name, m: friendMinutes, f: [userIds] } }
  async function recordSample(list, force = false) {
    const now = Date.now();
    const got = await local.get(['ftLast', 'fsess', 'ftDays']);
    const prev = got.ftLast || 0;
    if (!force && now - prev < SAMPLE_EVERY - 5000) { sessions = got.fsess || sessions; return; }
    const recent = prev && now - prev < SAMPLE_GAP_MAX;
    const credit = recent ? now - prev : SAMPLE_EVERY;
    const dk = `ft:${dayKey(now)}`;
    const bucket = (await local.get(dk))[dk] || {};
    const old = got.fsess || {};
    const next = {};
    for (const p of list) {
      const t = p.userPresenceType;
      if (t !== TYPE.GAME && t !== TYPE.STUDIO) continue;
      const place = p.rootPlaceId || p.placeId || null;
      const k = `${t}:${place || p.lastLocation || '?'}`;
      next[p.userId] = old[p.userId]?.k === k ? old[p.userId] : { k, since: now, exact: !!recent };
      if (t === TYPE.GAME && place) {
        const e = bucket[place] || (bucket[place] = { n: '', m: 0, f: [] });
        if (p.lastLocation) e.n = p.lastLocation;
        e.m = Math.round((e.m + credit / 60000) * 10) / 10;
        if (!e.f.includes(p.userId)) e.f.push(p.userId);
      }
    }
    const days = new Set(got.ftDays || []);
    days.add(dk);
    const sorted = [...days].sort();
    const drop = sorted.slice(0, Math.max(0, sorted.length - TREND_DAYS));
    if (drop.length) await local.remove(drop);
    await local.set({ ftLast: now, fsess: next, [dk]: bucket, ftDays: sorted.slice(-TREND_DAYS) });
    sessions = next;
  }

  // Runs on every roblox.com page (not just home) so trends keep building.
  async function backgroundSample() {
    if (!getMeSync()) return;
    const { ftLast = 0, friendCache } = await local.get(['ftLast', 'friendCache']);
    if (Date.now() - ftLast < SAMPLE_EVERY) return;
    await local.set({ ftLast: Date.now() - SAMPLE_EVERY + 20000 }); // soft lock vs. other tabs
    try {
      let ids = friendCache?.ids;
      if (!ids || Date.now() - friendCache.t > 6 * 36e5) ids = (await fetchFriendList(getMeSync())).map((f) => f.id);
      if (!ids.length) return;
      const list = await fetchPresence(ids);
      await local.set({ ftLast: ftLast }); // restore real "previous sample" time for crediting
      await recordSample(list, true);
    } catch {
      await local.set({ ftLast });
    }
  }

  // ---- Pins -----------------------------------------------------------------
  async function loadPins() {
    const { pinnedFriends = [] } = await local.get('pinnedFriends');
    pinned = new Set(pinnedFriends);
  }
  async function togglePin(id) {
    if (pinned.has(id)) pinned.delete(id); else pinned.add(id);
    await local.set({ pinnedFriends: [...pinned] });
    render();
  }

  async function refresh(full = false) {
    try {
      if (full || !friends.length || Date.now() - lastFriends > FRIENDS_EVERY) await loadFriends();
      await loadPresence();
      status = 'ok';
    } catch (e) {
      if (status !== 'ok') { status = 'error'; errorMsg = e.message; }
    }
    render();
  }

  // ---- Grouping -------------------------------------------------------------
  const byPinThenName = (a, b) =>
    (pinned.has(b.id) - pinned.has(a.id)) || (a.displayName || a.name).localeCompare(b.displayName || b.name);

  function buckets() {
    const q = query.trim().toLowerCase();
    const match = (f) => !q || f.name.toLowerCase().includes(q) || f.displayName.toLowerCase().includes(q) ||
      (presence.get(f.id)?.lastLocation || '').toLowerCase().includes(q);
    const games = new Map(), studio = new Map(), online = [], offline = [], pins = [];
    for (const f of friends) {
      if (!match(f)) continue;
      const p = presence.get(f.id) || { userPresenceType: TYPE.OFFLINE };
      const m = { ...f, p };
      if (pinned.has(f.id)) pins.push(m);
      const t = p.userPresenceType;
      if (t === TYPE.GAME || t === TYPE.STUDIO) {
        const place = p.rootPlaceId || p.placeId || null;
        const key = place || `loc:${p.lastLocation || '?'}`;
        const map = t === TYPE.GAME ? games : studio;
        if (!map.has(key)) map.set(key, { key, place, universeId: p.universeId, name: p.lastLocation || '', members: [] });
        const grp = map.get(key);
        if (!grp.name && p.lastLocation) grp.name = p.lastLocation;
        grp.members.push(m);
      } else if (t === TYPE.ONLINE) online.push(m);
      else offline.push(m);
    }
    const sortGroups = (mp) => [...mp.values()]
      .map((g) => { g.members.sort(byPinThenName); g.pins = g.members.filter((x) => pinned.has(x.id)).length; return g; })
      .sort((a, b) => b.pins - a.pins || b.members.length - a.members.length || a.name.localeCompare(b.name));
    online.sort(byPinThenName); offline.sort(byPinThenName);
    const rank = (m) => ({ 2: 0, 3: 1, 1: 2 }[m.p.userPresenceType] ?? 3);
    pins.sort((a, b) => rank(a) - rank(b) || byPinThenName(a, b));
    return { games: sortGroups(games), studio: sortGroups(studio), online, offline, pins };
  }

  const avatar = (id) => headshots.get(id) || '';

  // ---- Render ---------------------------------------------------------------
  function joinUrl(placeId, gameId) {
    return `roblox://experiences/start?placeId=${placeId}${gameId ? `&gameInstanceId=${gameId}` : ''}`;
  }

  function sessionText(id) {
    const s = sessions[id];
    if (!s) return '';
    const ms = Date.now() - s.since;
    if (!s.exact && ms < 2 * 60e3) return '';
    return `${fmtDur(ms)}${s.exact ? '' : '+'}`;
  }

  function serverTags(members) {
    const counts = new Map();
    for (const m of members) if (m.p.gameId) counts.set(m.p.gameId, (counts.get(m.p.gameId) || 0) + 1);
    const shared = [...counts].filter(([, n]) => n > 1).map(([id]) => id);
    const tags = new Map();
    shared.forEach((id, i) => tags.set(id, { label: String.fromCharCode(65 + (i % 26)), color: SERVER_COLORS[i % SERVER_COLORS.length] }));
    return tags;
  }

  const star = (id) =>
    `<button class="rsf-star ${pinned.has(id) ? 'rsf-on' : ''}" data-pin="${id}" title="${pinned.has(id) ? 'Unpin' : 'Pin to top'}" aria-label="${pinned.has(id) ? 'Unpin friend' : 'Pin friend'}">★</button>`;

  function joinBtn(p) {
    const place = p.placeId || p.rootPlaceId;
    if (p.userPresenceType !== TYPE.GAME || !place) return '';
    return `<a class="rsf-join" href="${esc(joinUrl(place, p.gameId))}" title="${p.gameId ? 'Join their server' : 'Play this experience'}">${p.gameId ? 'Join' : 'Play'}</a>`;
  }

  function personRow(m, { kind, tag }) {
    const sess = sessionText(m.id);
    return `
      <div class="rsf-person">
        <a class="rsf-ava rsf-${kind}" href="/users/${m.id}/profile" title="Open profile">
          ${avatar(m.id) ? `<img src="${esc(avatar(m.id))}" alt="" loading="lazy">` : ''}
        </a>
        <a class="rsf-names" href="/users/${m.id}/profile">
          <span class="rsf-dn">${esc(m.displayName || m.name)}</span>
          <span class="rsf-un">@${esc(m.name)}${sess ? ` · <b class="rsf-sess" title="Time in this ${kind === 'studio' ? 'project' : 'game'}${sess.endsWith('+') ? ' (at least — RoScout started watching after they joined)' : ''}">${sess}</b>` : ''}</span>
        </a>
        ${tag ? `<span class="rsf-srv" style="--c:${tag.color}" title="Same server as other friends">Server ${tag.label}</span>` : ''}
        ${star(m.id)}
        ${kind === 'game' ? joinBtn(m.p) : ''}
      </div>`;
  }

  function groupCard(g, kind) {
    const icon = g.place ? icons.get(g.place) : '';
    const tags = kind === 'game' ? serverTags(g.members) : new Map();
    const biggest = [...tags.keys()].sort((a, b) =>
      g.members.filter((m) => m.p.gameId === b).length - g.members.filter((m) => m.p.gameId === a).length)[0];
    const hidden = !g.place && !g.name;
    const title = hidden ? (kind === 'game' ? 'Hidden experience' : 'Private project') : esc(g.name || 'Unknown experience');
    const count = playing.get(g.universeId);
    const cr = creators.get(g.universeId);
    const byLine = cr ? `<a class="rsf-by" href="${cr.type === 'Group' ? `/communities/${cr.id}` : `/users/${cr.id}/profile`}" title="${cr.type === 'Group' ? 'Open group' : 'Open profile'}">by <b>${esc(cr.name)}</b>${cr.type === 'Group' ? '' : ' <i>solo dev</i>'}</a>` : '';
    return `
      <article class="rsf-card rsf-card-${kind}">
        <header class="rsf-card-head">
          <div class="rsf-icon">${icon ? `<img src="${esc(icon)}" alt="" loading="lazy">` : '<span>?</span>'}</div>
          <div class="rsf-card-title">
            ${g.place ? `<a href="/games/${g.place}" title="Open experience">${title}</a>` : `<span>${title}</span>`}
            ${byLine}
            <span class="rsf-card-sub">
              ${kind === 'studio' ? '<b class="rsf-studio-tag">Studio</b> ' : ''}${g.members.length} friend${g.members.length === 1 ? '' : 's'}${count != null ? ` · ${fmt(count)} playing` : ''}
            </span>
          </div>
          ${kind === 'game' && g.place && biggest
            ? `<a class="rsf-join rsf-join-all" href="${esc(joinUrl(g.members.find((m) => m.p.gameId === biggest).p.placeId || g.place, biggest))}" title="Join the server with the most friends">Join group</a>`
            : ''}
        </header>
        <div class="rsf-people">${g.members.map((m) => personRow(m, { kind, tag: tags.get(m.p.gameId) })).join('')}</div>
      </article>`;
  }

  function pinCard(m) {
    const t = m.p.userPresenceType;
    const kind = { 2: 'game', 3: 'studio', 1: 'online' }[t] || 'offline';
    const where = t === TYPE.GAME ? (m.p.lastLocation || 'In a game')
      : t === TYPE.STUDIO ? `Studio · ${m.p.lastLocation || 'private project'}`
      : t === TYPE.ONLINE ? 'Online' : 'Offline';
    const sess = (t === TYPE.GAME || t === TYPE.STUDIO) ? sessionText(m.id) : '';
    return `
      <div class="rsf-pin rsf-pin-${kind}">
        <a class="rsf-ava rsf-${kind}" href="/users/${m.id}/profile">${avatar(m.id) ? `<img src="${esc(avatar(m.id))}" alt="" loading="lazy">` : ''}</a>
        <a class="rsf-names" href="/users/${m.id}/profile">
          <span class="rsf-dn">${esc(m.displayName || m.name)}</span>
          <span class="rsf-where">${esc(where)}${sess ? ` · ${sess}` : ''}</span>
        </a>
        ${star(m.id)}
        ${joinBtn(m.p)}
      </div>`;
  }

  function chip(id, label, n) {
    return `<button class="rsf-chip ${filter === id ? 'rsf-on' : ''}" data-filter="${id}">${label}<span>${n}</span></button>`;
  }

  function render() {
    if (!root) return;
    const focused = document.activeElement?.classList?.contains('rsf-search');
    const caret = focused ? document.activeElement.selectionStart : null;

    if (status === 'loading' && !friends.length) {
      root.innerHTML = `${head(null)}<div class="rsf-loading"><span></span><span></span><span></span></div>`;
      return;
    }
    if (status === 'error' && !friends.length) {
      root.innerHTML = `${head(null)}<p class="rsf-error">Couldn't load friends: ${esc(errorMsg)}</p>`;
      return;
    }

    const b = buckets();
    const nGame = b.games.reduce((a, g) => a + g.members.length, 0);
    const nStudio = b.studio.reduce((a, g) => a + g.members.length, 0);
    const counts = { game: nGame, studio: nStudio, online: b.online.length, offline: b.offline.length, pinned: b.pins.length };
    const show = (id) => filter === 'all' || filter === id;
    let html = head(counts);

    if ((filter === 'all' || filter === 'pinned') && b.pins.length) {
      html += section('Pinned', b.pins.length, `<div class="rsf-pins">${b.pins.map(pinCard).join('')}</div>`, 'pinned');
    } else if (filter === 'pinned') {
      html += `<p class="rsf-empty">Hover any friend and click ★ to pin them here.</p>`;
    }
    if (show('game') && b.games.length) {
      html += section('In game', nGame, `<div class="rsf-grid">${b.games.map((g) => groupCard(g, 'game')).join('')}</div>`);
    }
    if (show('studio') && b.studio.length) {
      html += section('Building in Studio', nStudio, `<div class="rsf-grid">${b.studio.map((g) => groupCard(g, 'studio')).join('')}</div>`, 'studio');
    }
    if (show('online') && b.online.length) {
      html += section('Online', b.online.length, `<div class="rsf-chips">${b.online.map((m) => mini(m, 'online')).join('')}</div>`, 'online');
    }
    if (show('offline') && b.offline.length) {
      const open = showOffline || filter === 'offline';
      html += section('Offline', b.offline.length,
        open ? `<div class="rsf-chips">${b.offline.map((m) => mini(m, 'offline')).join('')}</div>`
             : `<button class="rsf-more" data-act="offline">Show ${b.offline.length} offline friends</button>`, 'offline');
    }
    if (!nGame && !nStudio && !b.online.length && !b.offline.length) {
      html += `<p class="rsf-empty">${query ? 'No friends match that search.' : 'No friends to show.'}</p>`;
    } else if (filter === 'game' && !b.games.length) {
      html += `<p class="rsf-empty">Nobody's in a game right now.</p>`;
    } else if (filter === 'studio' && !b.studio.length) {
      html += `<p class="rsf-empty">Nobody's in Studio right now.</p>`;
    }
    root.innerHTML = html;

    if (focused) {
      const s = root.querySelector('.rsf-search');
      s.focus();
      if (caret != null) s.setSelectionRange(caret, caret);
    }
  }

  function head(counts) {
    const total = friends.length;
    return `
      <header class="rsf-head">
        <div class="rsf-title">
          <span class="rs-logo" aria-hidden="true"><i></i><i></i><i></i></span>
          Friends ${total ? `<span class="rsf-total">${total}</span>` : ''}
        </div>
        ${counts ? `<div class="rsf-filters">
          ${chip('all', 'All', total)}
          ${counts.pinned ? chip('pinned', '★ Pinned', counts.pinned) : ''}
          ${chip('game', 'In game', counts.game)}
          ${chip('studio', 'Studio', counts.studio)}
          ${chip('online', 'Online', counts.online)}
          ${chip('offline', 'Offline', counts.offline)}
        </div>` : ''}
        <div class="rsf-tools">
          <input class="rsf-search" type="search" placeholder="Search friends or games" value="${esc(query)}" aria-label="Search friends">
          <button class="rsf-icon-btn" data-act="refresh" title="Refresh">↻</button>
        </div>
      </header>`;
  }

  function section(title, n, body, cls = '') {
    return `<section class="rsf-section ${cls ? `rsf-section-${cls}` : ''}"><h3>${title} <span>${n}</span></h3>${body}</section>`;
  }

  function mini(m, kind) {
    return `
      <div class="rsf-mini">
        <a href="/users/${m.id}/profile" title="@${esc(m.name)}">
          <span class="rsf-ava rsf-${kind}">${avatar(m.id) ? `<img src="${esc(avatar(m.id))}" alt="" loading="lazy">` : ''}</span>
          <span class="rsf-dn">${esc(m.displayName || m.name)}</span>
        </a>
        ${star(m.id)}
      </div>`;
  }

  // ---- Mount ----------------------------------------------------------------
  function findNative() {
    return document.querySelector('.friend-carousel-container') ||
           document.querySelector('[data-testid="friends-carousel"]') ||
           document.querySelector('.friends-carousel-container') ||
           document.querySelector('#HomeContainer .people-list-container')?.closest('.section, .container-list') || null;
  }

  function findFallback() {
    return document.querySelector('#HomeContainer') ||
           document.querySelector('.home-container') ||
           document.querySelector('#content');
  }

  function waitFor(fn, timeout = 6000) {
    return new Promise((resolve) => {
      const found = fn();
      if (found) return resolve(found);
      const obs = new MutationObserver(() => { const el = fn(); if (el) { obs.disconnect(); resolve(el); } });
      obs.observe(document.documentElement, { childList: true, subtree: true });
      setTimeout(() => { obs.disconnect(); resolve(null); }, timeout);
    });
  }

  async function mount() {
    if (!root) {
      root = document.createElement('section');
      root.className = 'rsf-root';
      root.addEventListener('click', onClick);
      root.addEventListener('input', (e) => {
        if (e.target.classList.contains('rsf-search')) { query = e.target.value; render(); }
      });
    }
    const native = await waitFor(findNative, 4000);
    if (native) {
      native.insertAdjacentElement('beforebegin', root);
      native.classList.add('rsf-hidden-native');
    } else {
      const fb = findFallback();
      if (!fb) return false;
      fb.prepend(root);
    }
    return true;
  }

  function onClick(e) {
    const el = e.target.closest('button');
    if (!el) return;
    if (el.dataset.pin) { e.preventDefault(); togglePin(Number(el.dataset.pin)); return; }
    if (el.dataset.filter) { filter = el.dataset.filter; render(); return; }
    if (el.dataset.act === 'offline') { showOffline = true; render(); return; }
    if (el.dataset.act === 'refresh') { el.classList.add('rs-spin'); refresh(true); }
  }

  async function startHub() {
    try { me = await getMe(); } catch { return; }
    if (!me) return;
    await loadPins();
    if (!(await mount())) return;
    render();
    await refresh(true);
    setInterval(() => { if (!document.hidden && root?.isConnected) refresh(); }, PRESENCE_EVERY);
    document.addEventListener('visibilitychange', () => { if (!document.hidden && root?.isConnected) refresh(); });
    // keep session times ticking between refreshes
    setInterval(() => { if (!document.hidden && root?.isConnected && !document.activeElement?.classList?.contains('rsf-search')) render(); }, 60 * 1000);
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.pinnedFriends && root) {
      pinned = new Set(changes.pinnedFriends.newValue || []);
      render();
    }
  });

  let hubStarted = false;
  function check() {
    if (HOME_RE.test(location.pathname)) {
      if (!hubStarted) { hubStarted = true; startHub(); }
      else if (root && !root.isConnected) mount();
    }
  }
  check();
  if (!hubStarted) backgroundSample().catch(() => {});
  setInterval(check, 1500);
  setInterval(() => { if (!hubStarted) backgroundSample().catch(() => {}); }, 60 * 1000);
})();
