// RoScout appearance — your own background image behind roblox.com.
// Settings: chrome.storage.local
//   rsBg    = { on, opacity (0-1), blur (px), dim (0-1), fit: 'cover'|'contain'|'tile', pos }
//   rsBgImg = data: URL (Roblox's page only allows data: images from outside its own CDN)
(() => {
  let layer = null;
  let baseColor = null;

  function ensureLayer() {
    if (layer?.isConnected) return layer;
    layer = document.getElementById('rs-bg-layer') || document.createElement('div');
    layer.id = 'rs-bg-layer';
    layer.setAttribute('aria-hidden', 'true');
    document.documentElement.appendChild(layer);
    return layer;
  }

  function pageColor() {
    if (baseColor) return baseColor;
    const root = document.documentElement;
    const was = root.classList.contains('rs-bg-on');
    root.classList.remove('rs-bg-on');
    const body = getComputedStyle(document.body).backgroundColor;
    const html = getComputedStyle(root).backgroundColor;
    if (was) root.classList.add('rs-bg-on');
    const solid = [body, html].find((c) => c && !/rgba\(.*,\s*0\)|transparent/.test(c));
    baseColor = solid || '#121215';
    return baseColor;
  }

  function apply(cfg, img) {
    const root = document.documentElement;
    if (!cfg?.on || !img) {
      root.classList.remove('rs-bg-on');
      layer?.remove(); layer = null;
      return;
    }
    const base = pageColor();
    const el = ensureLayer();
    const fit = cfg.fit || 'cover';
    el.style.setProperty('--rs-bg-base', base);
    el.style.setProperty('--rs-bg-img', `url("${img}")`);
    el.style.setProperty('--rs-bg-opacity', String(cfg.opacity ?? 0.6));
    el.style.setProperty('--rs-bg-blur', `${cfg.blur ?? 0}px`);
    el.style.setProperty('--rs-bg-dim', String(cfg.dim ?? 0.3));
    el.style.setProperty('--rs-bg-size', fit === 'tile' ? 'auto' : fit);
    el.style.setProperty('--rs-bg-repeat', fit === 'tile' ? 'repeat' : 'no-repeat');
    el.style.setProperty('--rs-bg-pos', cfg.pos || 'center');
    root.classList.add('rs-bg-on');
  }

  async function load() {
    try {
      const { rsBg, rsBgImg } = await chrome.storage.local.get(['rsBg', 'rsBgImg']);
      apply(rsBg, rsBgImg);
    } catch {}
  }

  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === 'local' && (ch.rsBg || ch.rsBgImg)) load();
  });

  if (document.body) load();
  else document.addEventListener('DOMContentLoaded', load, { once: true });
  // Roblox sometimes re-renders the page shell; keep the layer attached.
  setInterval(() => { if (document.documentElement.classList.contains('rs-bg-on') && !layer?.isConnected) load(); }, 2000);
})();
