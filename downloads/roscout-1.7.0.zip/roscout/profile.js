// RoScout profile skin — a themed creator card on roblox.com profile pages.
// • Every profile: banner with the creator's games (own + group projects) and live stats.
// • Your own profile: pick a theme. Paste the short code (e.g. [rs:lava]) into your
//   About and anyone else running RoScout sees your profile in that theme too.
(() => {
  const { esc, fmt, fmtFull, pct, ago, send, getSettings } = globalThis.RS;

  const PROFILE_RE = /^\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?users\/(\d+)\/profile/i;
  const CODE_RE = /\[rs:([a-z0-9-]+)\]/i;
  // Themes are a single accent color, matching RoScout's own UI.
  const THEMES = {
    green:  { label: 'Green',  a: '#3ddc84' },
    blue:   { label: 'Blue',   a: '#3b8cff' },
    purple: { label: 'Purple', a: '#a77bff' },
    pink:   { label: 'Pink',   a: '#ff5fa2' },
    orange: { label: 'Orange', a: '#ff9a3d' },
    red:    { label: 'Red',    a: '#ff5a5a' },
    teal:   { label: 'Teal',   a: '#2fd6c8' },
    mono:   { label: 'Mono',   a: '#e8e8ec' },
  };
  const DEFAULT_THEME = 'green';
  const SHOW_GAMES = 8;

  let root = null;
  let userId = null;
  let me = null;
  let data = null;
  let myTheme = DEFAULT_THEME;
  let pickerOpen = false;
  let showAll = false;
  let tab = 'games';
  let copied = false;
  let loadToken = 0;

  const myId = () => {
    const id = Number(document.querySelector('meta[name="user-data"]')?.dataset.userid);
    return Number.isFinite(id) && id > 0 ? id : null;
  };

  function themeFor() {
    const code = data?.user?.description?.match(CODE_RE)?.[1]?.toLowerCase();
    const fromCode = code && THEMES[code] ? code : null;
    if (userId === me) return { key: myTheme, source: 'you', codeKey: fromCode };
    return { key: fromCode || DEFAULT_THEME, source: fromCode ? 'code' : 'default', codeKey: fromCode };
  }

  // ---- render ------------------------------------------------------------------
  const cap = (s) => String(s || '').replace(/^./, (c) => c.toUpperCase());
  const likeCls = (l) => (l >= 0.85 ? 'rsp-good' : l >= 0.7 ? 'rsp-ok' : 'rsp-bad');

  function gameRow(g) {
    return `
      <a class="rsp-row" href="/games/${g.placeId}">
        <span class="rsp-icon">${g.icon ? `<img src="${esc(g.icon)}" alt="" loading="lazy">` : ''}</span>
        <span class="rsp-row-main">
          <span class="rsp-row-title">${esc(g.name)}</span>
          <span class="rsp-row-sub">${fmt(g.visits)} visits${g.likes != null && g.votes >= 3 ? ` · <span class="${likeCls(g.likes)}">${pct(g.likes, 0)} liked</span>` : ''}${g.group ? ` · ${esc(g.group)}` : ''}</span>
        </span>
        ${g.playing > 0 ? `<span class="rsp-live">${fmtFull(g.playing)} playing</span>` : ''}
        ${g.group ? `<span class="rsp-pill">${esc(cap(g.role))}</span>` : ''}
        <span class="rsp-chev" aria-hidden="true">›</span>
      </a>`;
  }

  function groupRow(g) {
    const games = data.teamGames.filter((x) => x.group === g.name);
    const visits = games.reduce((s, x) => s + x.visits, 0);
    return `
      <a class="rsp-row" href="/communities/${g.id}">
        <span class="rsp-icon rsp-icon-group" aria-hidden="true">${esc((g.name.match(/[A-Za-z0-9]/) || ['?'])[0].toUpperCase())}</span>
        <span class="rsp-row-main">
          <span class="rsp-row-title">${esc(g.name)}</span>
          <span class="rsp-row-sub">${games.length ? `${games.length} game${games.length === 1 ? '' : 's'} · ${fmt(visits)} visits` : `${fmtFull(g.members)} members`}</span>
        </span>
        <span class="rsp-pill">${esc(cap(g.role))}</span>
        <span class="rsp-chev" aria-hidden="true">›</span>
      </a>`;
  }

  function picker(th) {
    const code = `[rs:${myTheme}]`;
    const inAbout = th.codeKey === myTheme;
    return `
      <div class="rsp-picker" role="dialog" aria-label="Profile accent color">
        <div class="rsp-swatches">
          ${Object.entries(THEMES).map(([k, t]) => `
            <button class="rsp-sw ${k === myTheme ? 'rsp-on' : ''}" data-theme="${k}" style="--c:${t.a}" aria-pressed="${k === myTheme}" title="${esc(t.label)}">
              <i></i><span>${esc(t.label)}</span></button>`).join('')}
        </div>
        <div class="rsp-code">
          <div class="rsp-code-text">
            <b>Show it to other RoScout users</b>
            <span>${inAbout
              ? 'Your About already has this code, so other RoScout users see this color.'
              : th.codeKey ? `Your About has <code>[rs:${esc(th.codeKey)}]</code>. Replace it with this code to match.`
              : 'Paste this code anywhere in your About. People without RoScout just see the text.'}</span>
          </div>
          <code class="rsp-codebox">${esc(code)}</code>
          <button class="rsp-btn" data-act="copy">${copied ? 'Copied' : 'Copy code'}</button>
        </div>
      </div>`;
  }

  function render() {
    if (!root) return;
    if (!data) {
      root.innerHTML = `<div class="rsp-loading"><span></span><span></span><span></span></div>`;
      return;
    }
    const th = themeFor();
    const t = THEMES[th.key] || THEMES[DEFAULT_THEME];
    const { user, ownGames, teamGames, groups } = data;
    const games = [...ownGames, ...teamGames].sort((a, b) => b.playing - a.playing || b.visits - a.visits);
    const totalVisits = games.reduce((s, g) => s + g.visits, 0);
    const playing = games.reduce((s, g) => s + g.playing, 0);
    const favorites = games.reduce((s, g) => s + (g.favorites || 0), 0);
    const isMe = userId === me;
    const list = tab === 'games' ? games : groups;
    const shown = showAll ? list : list.slice(0, SHOW_GAMES);
    const top = groups[0];

    root.style.setProperty('--rsp-a', t.a);

    root.innerHTML = `
      <header class="rsp-head">
        <div class="rsp-ava">${data.headshot ? `<img src="${esc(data.headshot)}" alt="">` : ''}</div>
        <div class="rsp-who">
          <div class="rsp-name">${esc(user.displayName || user.name)}${user.verified ? ' <span class="rsp-verified" title="Verified">✔</span>' : ''}</div>
          <div class="rsp-handle">@${esc(user.name)}${top ? ` · ${esc(cap(top.role))} at <a href="/communities/${top.id}">${esc(top.name)}</a>` : ''} · joined ${esc(new Date(user.created).toLocaleDateString(undefined, { month: 'short', year: 'numeric' }))}</div>
        </div>
        <div class="rsp-tools">
          ${isMe ? `<button class="rsp-btn" data-act="theme" aria-expanded="${pickerOpen}">Accent</button>` : ''}
          <button class="rsp-btn rsp-round" data-act="refresh" title="Refresh stats" aria-label="Refresh stats">↻</button>
        </div>
      </header>
      ${isMe && pickerOpen ? picker(th) : ''}
      <div class="rsp-stats">
        <div><b>${fmtFull(ownGames.length)}</b><span>Games</span></div>
        <div><b>${fmt(totalVisits)}</b><span>Total visits</span></div>
        <div><b class="${playing ? 'rsp-on-now' : ''}">${fmtFull(playing)}</b><span>Playing now</span></div>
        <div><b>${fmt(favorites)}</b><span>Favorites</span></div>
      </div>
      <div class="rsp-seg" role="tablist">
        <button role="tab" class="${tab === 'games' ? 'rsp-on' : ''}" aria-selected="${tab === 'games'}" data-tab="games">Games <span>${games.length}</span></button>
        <button role="tab" class="${tab === 'work' ? 'rsp-on' : ''}" aria-selected="${tab === 'work'}" data-tab="work">Where they work <span>${groups.length}</span></button>
      </div>
      <div class="rsp-list">
        ${shown.length ? shown.map(tab === 'games' ? gameRow : groupRow).join('')
          : `<p class="rsp-empty">${tab === 'games' ? (isMe ? "You haven't published a public game yet. Your games show up here with live stats." : 'No public games yet.') : 'Not an owner or admin of any communities.'}</p>`}
      </div>
      ${list.length > SHOW_GAMES ? `<button class="rsp-more" data-act="all">${showAll ? 'Show less' : `Show all ${list.length}`}</button>` : ''}
      <footer class="rsp-foot">
        <span class="rs-logo" aria-hidden="true"><i></i><i></i><i></i></span>
        RoScout${th.source === 'code' ? ` · ${esc(t.label)} accent set by @${esc(user.name)}` : ''} · updated ${esc(ago(data.t))}
      </footer>`;
  }

  // ---- data + mount ---------------------------------------------------------------
  async function load(fresh = false) {
    const token = ++loadToken;
    try {
      const d = await send({ type: 'profileData', userId, fresh });
      if (token !== loadToken) return;
      data = d;
    } catch (e) {
      if (token !== loadToken) return;
      if (!data) { root.innerHTML = `<p class="rsp-empty">RoScout couldn't load this profile: ${esc(e.message)}</p>`; return; }
    }
    render();
  }

  function findAnchor() {
    return document.querySelector('.profile-header') ||
           document.querySelector('[data-testid="profile-header"]') ||
           document.querySelector('#profile-header-container') ||
           document.querySelector('[class*="profile-header"]');
  }

  function waitFor(fn, timeout = 5000) {
    return new Promise((resolve) => {
      const f = fn(); if (f) return resolve(f);
      const obs = new MutationObserver(() => { const el = fn(); if (el) { obs.disconnect(); resolve(el); } });
      obs.observe(document.documentElement, { childList: true, subtree: true });
      setTimeout(() => { obs.disconnect(); resolve(null); }, timeout);
    });
  }

  async function mount() {
    if (!root) {
      root = document.createElement('section');
      root.className = 'rsp-root';
      root.addEventListener('click', onClick);
    }
    const anchor = await waitFor(findAnchor);
    if (anchor) anchor.insertAdjacentElement('afterend', root);
    else (document.querySelector('#content') || document.querySelector('main') || document.body).prepend(root);
  }

  async function onClick(e) {
    const b = e.target.closest('button');
    if (!b) return;
    if (b.dataset.tab) { tab = b.dataset.tab; showAll = false; render(); return; }
    if (b.dataset.theme) {
      myTheme = b.dataset.theme; copied = false;
      await chrome.storage.sync.set({ profileTheme: myTheme });
      render(); return;
    }
    switch (b.dataset.act) {
      case 'theme': pickerOpen = !pickerOpen; copied = false; render(); break;
      case 'all': showAll = !showAll; render(); break;
      case 'refresh': b.classList.add('rs-spin'); load(true); break;
      case 'copy': {
        const code = `[rs:${myTheme}]`;
        try { await navigator.clipboard.writeText(code); copied = true; }
        catch {
          const box = root.querySelector('.rsp-codebox');
          const r = document.createRange(); r.selectNodeContents(box);
          const s = getSelection(); s.removeAllRanges(); s.addRange(r);
        }
        render();
        break;
      }
    }
  }

  async function check() {
    const id = Number(location.pathname.match(PROFILE_RE)?.[1]) || null;
    if (id !== userId) {
      userId = id; data = null; pickerOpen = false; showAll = false; tab = 'games';
      root?.remove();
      if (!id) return;
      const s = await getSettings();
      if (s.profileCard === false) { userId = null; return; }
      await mount();
      render();
      load();
    } else if (id && root && !root.isConnected) {
      await mount();
    }
  }

  (async () => {
    me = myId();
    try { myTheme = (await chrome.storage.sync.get('profileTheme')).profileTheme || DEFAULT_THEME; } catch {}
    if (!THEMES[myTheme]) myTheme = DEFAULT_THEME;
    check();
    setInterval(check, 1000);
  })();
})();
