// RoScout background: friend requests you sent.
// Roblox has no list of the requests you've sent, so RoScout notes each one as you send it
// (netwatch.js sees the request go out on roblox.com) and then checks every 20 minutes
// whether it was accepted.
//
// sentReqs = { userId: { t, status: 'pending'|'accepted'|'gone'|'mutual', done, name, displayName, checked } }

const FREQ_ALARM = 'roscout-freq';
const FREQ_KEEP_DONE = 60 * 864e5;

async function myId() {
  return (await chrome.storage.local.get('myUserId')).myUserId || null;
}

async function ensureFreqAlarm() {
  const reqs = await store.get('sentReqs', {});
  const pending = Object.values(reqs).some((r) => r.status === 'pending');
  const a = await chrome.alarms.get(FREQ_ALARM);
  if (pending && !a) chrome.alarms.create(FREQ_ALARM, { periodInMinutes: 20, delayInMinutes: 5 });
  if (!pending && a) chrome.alarms.clear(FREQ_ALARM);
}

async function friendStatuses(me, ids) {
  const out = {};
  for (const c of chunk(ids, 50)) {
    const r = await fetch(`https://friends.roblox.com/v1/users/${me}/friends/statuses?userIds=${c.join(',')}`, { credentials: 'include' });
    if (r.status === 401 || r.status === 403) throw new Error('Sign in to Roblox in Chrome so RoScout can check your requests');
    if (!r.ok) throw new Error(`Roblox answered ${r.status}`);
    for (const x of (await r.json()).data || []) out[x.id] = x.status;
  }
  return out;
}

async function refreshRequests({ notifyChanges = true } = {}) {
  const me = await myId();
  const reqs = await store.get('sentReqs', {});
  const pending = Object.keys(reqs).filter((id) => reqs[id].status === 'pending');
  const now = Date.now();
  if (me && pending.length) {
    const st = await friendStatuses(me, pending.map(Number));
    for (const id of pending) {
      const s = st[id];
      if (!s) continue;
      const r = reqs[id];
      r.checked = now;
      if (s === 'Friends') {
        r.status = 'accepted'; r.done = now;
        if (notifyChanges) {
          await notify(`freq:${id}:${now}`, '✅ Friend request accepted',
            `${r.displayName || r.name || 'Someone'} accepted your friend request.`, null);
          const links = await store.get('notifLinks', {});
          links[`freq:${id}:${now}`] = { profile: Number(id) };
          await store.set('notifLinks', links);
        }
      } else if (s === 'NotFriends') { r.status = 'gone'; r.done = now; }
      else if (s === 'RequestReceived') { r.status = 'mutual'; }
    }
  }
  for (const id of Object.keys(reqs)) if (reqs[id].done && now - reqs[id].done > FREQ_KEEP_DONE) delete reqs[id];
  await store.set('sentReqs', reqs);
  await ensureFreqAlarm();
  return reqs;
}

chrome.alarms.onAlarm.addListener((a) => { if (a.name === FREQ_ALARM) refreshRequests().catch(() => {}); });

handlers.friendRequestSent = async ({ userId }) => {
  const id = Number(userId);
  if (!id) return { ok: false };
  const reqs = await store.get('sentReqs', {});
  reqs[id] = { ...(reqs[id] || {}), t: Date.now(), status: 'pending', done: null };
  try {
    const u = await getJSON(`https://users.roblox.com/v1/users/${id}`);
    reqs[id].name = u.name; reqs[id].displayName = u.displayName;
  } catch {}
  await store.set('sentReqs', reqs);
  await ensureFreqAlarm();
  return { ok: true };
};

handlers.sentRequests = async ({ refresh = true } = {}) => {
  let reqs = await store.get('sentReqs', {});
  let error = '';
  if (refresh) {
    try { reqs = await refreshRequests({ notifyChanges: false }); } catch (e) { error = e.message; }
  }
  const ids = Object.keys(reqs).map(Number);
  const heads = ids.length ? await thumbs('user', ids.slice(0, 100)) : {};
  const list = ids.map((id) => ({ userId: id, ...reqs[id], headshot: heads[id] || '' }))
    .sort((a, b) => (a.status === 'pending' ? 0 : 1) - (b.status === 'pending' ? 0 : 1) || b.t - a.t);
  return { list, error, signedIn: !!(await myId()) };
};

handlers.forgetRequest = async ({ userId }) => {
  const reqs = await store.get('sentReqs', {});
  delete reqs[userId];
  await store.set('sentReqs', reqs);
  await ensureFreqAlarm();
  return { ok: true };
};
