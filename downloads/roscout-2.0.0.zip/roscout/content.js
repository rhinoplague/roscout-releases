// RoScout content script — injects the stats panel on Roblox game pages.
(() => {
  const {
    esc, fmt, fmtFull, pct, ago, recentRate, ratioClass, sparkline, send,
    getSettings, avgConcurrent, estimateRevenue, usd, robux,
    revenueSeries, revenueSummary, niceMax,
    updateImpact, impactText, heatmapHTML, dayKey,
    monetization, withMon, monText, icon,
  } = globalThis.RS;
  let settings = null;
  getSettings().then((s) => { settings = s; if (data) render(); });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync' && changes.settings) getSettings().then((s) => { settings = s; if (data) render(); });
  });
  const PLACE_RE = /\/games\/(\d+)/;
  const RANGES = { Live: 2 * 36e5, '1D': 864e5, '1W': 7 * 864e5, All: Infinity };
  const RANGE_LABEL = { Live: 'live', '1D': 'past day', '1W': 'past week', All: 'all time' };
  const LIVE_EVERY = 15e3;
  const fmtWhen = (t) => new Date(t).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });

  let placeId = null;
  let panel = null;
  let data = null;
  let range = '1D';
  let view = 'players';               // 'players' | 'heatmap'
  let pchart = null, pMarkers = [], artAll = false;
  const live = { uid: null, pts: [], timer: null };
  let revMode = 'daily';
  let chartBars = [];
  let charts = [];
  let showAllPasses = false;
  let showAllBadges = false;
  // revenue settings adjusted for this game's game passes
  const mon = () => monetization(data?.passes ? data.passes.filter((p) => p.forSale).map((p) => p.price) : null, settings);
  const eff = () => withMon(settings, mon());
  let collapsed = false;
  let loadToken = 0;

  // Starts as a slim summary strip so Roblox's own page isn't pushed down; expands on click.
  try { const v = localStorage.getItem('roscout:collapsed'); collapsed = v === null ? true : v === '1'; } catch { collapsed = true; }

  const currentPlaceId = () => location.pathname.match(PLACE_RE)?.[1] || null;

  function findAnchor() {
    return document.querySelector('#game-detail-page .game-main-content') ||
           document.querySelector('.game-main-content');
  }

  function waitForAnchor(timeout = 6000) {
    return new Promise((resolve) => {
      const found = findAnchor();
      if (found) return resolve(found);
      const obs = new MutationObserver(() => {
        const a = findAnchor();
        if (a) { obs.disconnect(); resolve(a); }
      });
      obs.observe(document.documentElement, { childList: true, subtree: true });
      setTimeout(() => { obs.disconnect(); resolve(null); }, timeout);
    });
  }

  async function mount() {
    if (!panel) {
      panel = document.createElement('section');
      panel.className = 'rs-panel';
      panel.addEventListener('click', onClick);
      panel.addEventListener('mousemove', onChartHover);
      panel.addEventListener('mouseleave', hideTip);
    }
    const anchor = await waitForAnchor();
    if (anchor) {
      panel.classList.remove('rs-floating');
      anchor.insertAdjacentElement('afterend', panel);
    } else {
      panel.classList.add('rs-floating');
      document.body.appendChild(panel);
    }
    panel.classList.toggle('rs-collapsed', collapsed);
  }

  function header(extra = '', sum = '') {
    return `
      <header class="rs-head">
        <div class="rs-brand"><span class="rs-logo" aria-hidden="true"><i></i><i></i><i></i></span>RoScout</div>
        ${sum ? `<button class="rs-sum" data-act="collapse" title="${collapsed ? 'Show all stats' : 'Collapse'}">${sum}</button>` : '<span class="rs-sum-gap"></span>'}
        <div class="rs-actions">
          ${extra}
          <button class="rs-btn rs-icon" data-act="refresh" title="Refresh stats" aria-label="Refresh stats">${icon('refresh', 15)}</button>
          <button class="rs-btn rs-icon rs-collapse" data-act="collapse" title="${collapsed ? 'Expand' : 'Collapse'}" aria-label="${collapsed ? 'Expand' : 'Collapse'}">${icon('down', 15)}</button>
        </div>
      </header>`;
  }

  function renderLoading() {
    panel.innerHTML = `${header()}<div class="rs-body"><div class="rs-loading"><span></span><span></span><span></span></div></div>`;
  }

  function renderError(msg) {
    panel.innerHTML = `${header()}<div class="rs-body"><p class="rs-error">Couldn't load stats: ${esc(msg)}</p></div>`;
  }

  // ---- Creator + place bar ------------------------------------------------------
  let placesOpen = false;
  let copiedKey = '';

  function currentPlace() {
    const id = Number(data.placeId);
    const root = Number(data.game.rootPlaceId);
    const found = (data.places || []).find((p) => Number(p.id) === id);
    return {
      id, root,
      name: found?.name || (id === root ? data.game.name : `Place ${id}`),
      isStart: id === root,
      listed: !!found,
    };
  }

  function hero() {
    const c = data.creator;
    const g = data.game;
    const cur = currentPlace();
    const places = (data.places || []).slice().sort((a, b) =>
      (Number(b.id) === cur.root) - (Number(a.id) === cur.root) || String(a.name).localeCompare(String(b.name)));
    const count = Math.max(places.length, 1);
    const creatorMeta = !c ? '' : c.type === 'Group'
      ? ['Group', c.members != null ? `${fmt(c.members)} members` : '', c.owner ? `owned by ${esc(c.owner)}` : ''].filter(Boolean).join(' · ')
      : ['Solo dev', c.handle ? `@${esc(c.handle)}` : ''].filter(Boolean).join(' · ');
    const copyBtn = (key, label, value) =>
      `<button class="rs-id" data-copy="${key}" data-value="${esc(value)}" title="Copy ${label}">${copiedKey === key ? 'Copied' : `${icon('copy', 12)}${label} <code>${esc(value)}</code>`}</button>`;

    return `
      <div class="rs-hero">
        <div class="rs-hero-icon">${data.icon ? `<img src="${esc(data.icon)}" alt="">` : icon('gamepad', 28)}</div>
        <div class="rs-hero-main">
          <div class="rs-hero-name" title="${esc(g.name)}">${esc(g.name)}</div>
          ${c ? `<a class="rs-by" href="${esc(c.url || '#')}" title="Open ${c.type === 'Group' ? 'group' : 'profile'}">
              <span class="rs-by-icon ${c.type === 'Group' ? 'rs-sq' : 'rs-round'}">${c.icon ? `<img src="${esc(c.icon)}" alt="">` : icon(c.type === 'Group' ? 'building' : 'user', 12)}</span>
              <span>by <b>${esc(c.name)}</b>${c.verified ? ' <span class="rs-verified" title="Verified">✔</span>' : ''}</span>
              <em>${creatorMeta}</em>
            </a>` : '<span class="rs-by rs-muted-text">Creator unknown</span>'}
          <div class="rs-hero-row">
            <div class="rs-place">
              <button class="rs-place-btn" data-act="places" aria-expanded="${placesOpen}" aria-haspopup="true">
                ${icon('layers', 14)}
                <b>${esc(cur.name)}</b>
                <span class="rs-tag ${cur.isStart ? 'rs-tag-start' : 'rs-tag-sub'}">${cur.isStart ? 'Start place' : 'Sub-place'}</span>
                <span class="rs-place-count">${count} place${count === 1 ? '' : 's'}</span>
                ${icon('down', 14)}
              </button>
              ${placesOpen ? `
                <div class="rs-places" role="menu">
                  ${places.length ? places.map((p) => {
                    const here = Number(p.id) === cur.id, start = Number(p.id) === cur.root;
                    return `<a class="rs-place-row ${here ? 'rs-here' : ''}" role="menuitem" href="/games/${p.id}">
                      <span class="rs-place-name">${esc(p.name)}</span>
                      ${start ? '<span class="rs-tag rs-tag-start">Start</span>' : ''}
                      ${here ? '<span class="rs-tag rs-tag-here">You\'re here</span>' : ''}
                      <code>${esc(p.id)}</code>
                    </a>`;
                  }).join('') : '<p class="rs-places-empty">Roblox didn\'t return a place list for this game.</p>'}
                  ${!cur.listed && places.length ? `<p class="rs-places-empty">This page's place (${esc(cur.id)}) isn't in the public list. It may be private or unlisted.</p>` : ''}
                </div>` : ''}
            </div>
            ${copyBtn('place', 'Place', cur.id)}
            ${copyBtn('universe', 'Universe', data.universeId)}
          </div>
        </div>
      </div>
      <p class="rs-scope">Players, visits, likes and revenue cover the whole game${count > 1 ? ` (all ${count} places)` : ''}. Servers are for this place.</p>`;
  }

  // ---- Icon & thumbnail history ---------------------------------------------------
  function artCard() {
    const ch = (data.artChanges || []).slice().reverse();
    if (!ch.length && !data.tracked) return '';
    const hist = data.history || [];
    const rows = ch.slice(0, artAll ? 40 : 4).map((c) => {
      const imp = updateImpact(hist, c.t);
      const cls = !imp || imp.pending ? 'rs-dim' : imp.pct >= 0.05 ? 'rs-good' : imp.pct <= -0.05 ? 'rs-bad' : '';
      const what = c.kind === 'icon' ? 'New icon'
        : c.added || c.removed ? `New thumbnails${c.added ? ` · ${c.added} added` : ''}${c.removed ? ` · ${c.removed} removed` : ''}` : 'Thumbnails reordered';
      return `<div class="rs-art-row rs-art-${c.kind}">
        <div class="rs-art-pair"><img src="${esc(c.before)}" alt="Before"><span>${icon('chevron', 14)}</span><img src="${esc(c.after)}" alt="After"></div>
        <div class="rs-art-meta"><b>${what}</b><span>${esc(fmtWhen(c.t))} · ${esc(ago(c.t))}</span>
          ${imp ? `<span class="rs-art-imp ${cls}">${esc(impactText(imp))}</span>` : '<span class="rs-dim">Not enough player data around it</span>'}</div>
      </div>`;
    }).join('');
    return `<section class="rs-card rs-art">
      <div class="rs-card-head">${icon('image')}<span>Icon &amp; thumbnail history</span>${ch.length ? `<em>${ch.length} change${ch.length === 1 ? '' : 's'}</em>` : ''}</div>
      ${rows || `<p class="rs-hint">RoScout saves a copy of this game's icon and thumbnails and checks them every 15 minutes. When they change you'll see before and after here, plus what happened to players in the next 24 hours.</p>`}
      ${ch.length > 4 ? `<button class="rs-more" data-act="artall">${artAll ? 'Show fewer' : `Show all ${ch.length}`}</button>` : ''}
    </section>`;
  }

  // ---- Game passes ------------------------------------------------------------
  function passesCard() {
    const passes = data.passes;
    if (!passes) return `<section class="rs-card"><div class="rs-card-head">${icon('ticket')}<span>Game passes</span></div><p class="rs-hint">Couldn't load game passes for this game.</p></section>`;
    const m = mon();
    const sale = passes.filter((p) => p.forSale && p.price > 0).sort((a, b) => a.price - b.price);
    const off = passes.filter((p) => !(p.forSale && p.price > 0));
    const list = [...sale, ...off];
    const shown = showAllPasses ? list : list.slice(0, 6);
    return `
      <section class="rs-card">
        <div class="rs-card-head">${icon('ticket')}<span>Game passes</span><em>${sale.length} for sale</em>
          ${m.used ? `<span class="rs-chip-mult" title="${esc(monText(m))}">Estimate ×${m.mult.toFixed(2)}</span>` : ''}</div>
        ${sale.length ? `
          <div class="rs-mini-stats">
            <div><b>R$ ${fmtFull(sale[0].price)}–${fmtFull(sale.at(-1).price)}</b><span>Price range</span></div>
            <div><b>R$ ${fmtFull(m.median)}</b><span>Median</span></div>
            <div><b>R$ ${fmt(m.total)}</b><span>Buy every pass</span></div>
          </div>` : `<p class="rs-hint">No game passes for sale. This game earns from developer products, paid access or Premium payouts, so the estimate is lowered (×${m.mult.toFixed(2)}).</p>`}
        ${list.length ? `<div class="rs-list">${shown.map((p) => `
          <a class="rs-li ${p.forSale && p.price > 0 ? '' : 'rs-off'}" href="/game-pass/${p.id}" title="${esc(p.name)}">
            <span class="rs-li-icon">${p.icon ? `<img src="${esc(p.icon)}" alt="" loading="lazy">` : icon('ticket', 14)}</span>
            <span class="rs-li-name">${esc(p.name)}</span>
            <span class="rs-li-val">${p.forSale && p.price > 0 ? `R$ ${fmtFull(p.price)}` : 'Off sale'}</span>
          </a>`).join('')}</div>` : ''}
        ${list.length > 6 ? `<button class="rs-more" data-act="passes">${showAllPasses ? 'Show less' : `Show all ${list.length}`}</button>` : ''}
      </section>`;
  }

  // ---- Badges / progression -----------------------------------------------------
  function badgesCard() {
    const badges = data.badges;
    if (!badges) return `<section class="rs-card"><div class="rs-card-head">${icon('award')}<span>Player progression</span></div><p class="rs-hint">Couldn't load badges for this game.</p></section>`;
    if (!badges.length) return `<section class="rs-card"><div class="rs-card-head">${icon('award')}<span>Player progression</span></div><p class="rs-hint">This game has no badges, so there's no progression data to show.</p></section>`;
    const byWin = badges.filter((b) => b.winRate != null).sort((a, b) => b.winRate - a.winRate || b.awarded - a.awarded);
    const entry = badges.slice().sort((a, b) => b.awarded - a.awarded)[0];
    const top = byWin[0]?.winRate || 1;
    const shown = showAllBadges ? byWin : byWin.slice(0, 6);
    const dayTotal = badges.reduce((s2, b) => s2 + (b.pastDay || 0), 0);
    return `
      <section class="rs-card">
        <div class="rs-card-head">${icon('award')}<span>Player progression</span><em>${badges.length} badge${badges.length === 1 ? '' : 's'}</em></div>
        <div class="rs-mini-stats">
          <div><b>≈ ${fmtFull(entry.pastDay)}</b><span title="Past-day awards of the most-earned badge (usually the join badge)">New players, 24h</span></div>
          <div><b>${fmt(entry.awarded)}</b><span>Earned first badge</span></div>
          <div><b>${fmt(dayTotal)}</b><span>Badges earned, 24h</span></div>
        </div>
        <div class="rs-funnel">${shown.map((b) => `
          <a class="rs-fn" href="/badges/${b.id}" title="${esc(b.name)} · ${fmtFull(b.awarded)} earned · ${fmtFull(b.pastDay)} in the last day">
            <span class="rs-li-icon">${b.icon ? `<img src="${esc(b.icon)}" alt="" loading="lazy">` : icon('award', 14)}</span>
            <span class="rs-fn-main">
              <span class="rs-fn-top"><span class="rs-li-name">${esc(b.name)}</span><b>${b.winRate < 1 ? b.winRate.toFixed(1) : Math.round(b.winRate)}%</b></span>
              <span class="rs-fn-bar"><i style="width:${Math.max(1.5, (b.winRate / top) * 100).toFixed(1)}%"></i></span>
            </span>
          </a>`).join('')}</div>
        <p class="rs-card-note">Bars show Roblox's win rate: the share of players who earned each badge. Steep drops show where players quit.</p>
        ${byWin.length > 6 ? `<button class="rs-more" data-act="badges">${showAllBadges ? 'Show less' : `Show all ${byWin.length}`}</button>` : ''}
      </section>`;
  }

  function tile(label, value, sub = '', cls = '', ico = '') {
    return `<div class="rs-tile ${cls}"><div class="rs-label">${ico ? icon(ico, 13) : ''}${label}</div><div class="rs-value">${value}</div>${sub ? `<div class="rs-sub">${sub}</div>` : ''}</div>`;
  }

  // ---- Revenue chart -------------------------------------------------------
  function revenueCard(g) {
    const settings = eff();
    const m = mon();
    const { history = [], days = {} } = data;
    const conc = avgConcurrent(history, g.playing);
    const summary = revenueSummary(days, settings, conc.avg);
    const series = revenueSeries(days, settings, revMode);
    chartBars = series;
    const hasData = series.some((b) => !b.empty);
    const top = niceMax(Math.max(0, ...series.map((b) => b.robux || 0)));
    const showLabel = (i) => revMode === 'monthly' || i === 0 || i === series.length - 1 ||
      (series.length > 10 ? i % Math.ceil(series.length / 6) === 0 && i < series.length - 2 : true);

    const upd = data.updates || [];
    for (const b of series) {
      b.updates = upd.filter((t) => (revMode === 'daily' ? dayKey(t) : dayKey(t).slice(0, 7)) === b.key);
    }
    const bars = series.map((b, i) => {
      const h = b.empty ? 0 : Math.max(2, (b.robux / top) * 100);
      const dot = b.updates.length ? `<u class="rs-rc-upd" style="bottom:calc(${h.toFixed(1)}% + 4px)"></u>` : '';
      const cls = ['rs-rc-bar', b.empty && 'rs-empty', b.partial && 'rs-partial', b.today && 'rs-cur'].filter(Boolean).join(' ');
      return `<div class="${cls}" data-i="${i}">${dot}<i style="height:${h.toFixed(1)}%"></i></div>`;
    }).join('');
    const xs = series.map((b, i) =>
      `<span>${showLabel(i) ? esc(b.today && revMode === 'daily' ? 'Today' : b.short) : ''}</span>`).join('');

    const avgLabel = revMode === 'daily' ? 'avg per day, last 7 days' : 'avg per day';
    const body = hasData ? `
      <div class="rs-pc-head rs-rc-head" data-rvhead data-v="${esc(robux(summary.robuxDay))}" data-u="≈ ${esc(usd(summary.usdDay))}" data-w="${esc(avgLabel)}">
        <b class="rs-pc-val" data-rv>${robux(summary.robuxDay)}</b><span class="rs-pc-chg" data-ru>≈ ${usd(summary.usdDay)}</span><span class="rs-pc-when" data-rw>${avgLabel}</span>
      </div>
      <div class="rs-rc" data-chart>
        <div class="rs-rc-plot">
          <div class="rs-rc-grid">
            <span><em>${robux(top)}</em></span><span><em>${robux(top / 2)}</em></span><span><em>0</em></span>
          </div>
          <div class="rs-rc-bars">${bars}</div>
        </div>
        <div class="rs-rc-x">${xs}</div>
        <div class="rs-rc-tip" hidden></div>
      </div>
      <p class="rs-rev-note">Hover a bar for that ${revMode === 'daily' ? 'day' : 'month'}.
        Faded bars have partial data${revMode === 'monthly' ? ' (month projected from the days recorded)' : ''}.
        ${upd.length ? 'Dots mark game updates.' : ''}
        Based on ${settings.rph.toFixed(2)} R$ per player-hour (platform base ${(settings.rph / (m.mult || 1)).toFixed(1)} × game passes ${m.mult.toFixed(2)}) · DevEx $${settings.devex}/R$ · adjust in the toolbar popup.</p>`
      : `<div class="rs-rc-empty">
          <div><b>${robux(summary.robuxDay)}</b>/day <span>≈ ${usd(summary.usdDay)}</span></div>
          <p>From the ${fmt(conc.avg)} players online right now. ${data.tracked
            ? 'Your day-by-day chart fills in as RoScout records this game every 15 minutes.'
            : 'Hit <b>☆ Track</b> to record this game every 15 minutes and build a day-by-day revenue chart.'}</p>
        </div>`;

    return `
      <div class="rs-rev">
        <div class="rs-rev-head">
          <span>Estimated revenue</span>
          <span class="rs-badge" title="Roblox doesn't publish game revenue — this is a model, not real earnings">estimate</span>
          <span class="rs-rev-sum">avg <b>${robux(summary.robuxDay)}</b>/day ≈ <b>${usd(summary.usdDay)}</b>
            · ≈ ${usd(summary.usdDay * 30)}/mo</span>
          <div class="rs-tabs">
            <button class="rs-tab ${revMode === 'daily' ? 'rs-on' : ''}" data-rev="daily">Daily</button>
            <button class="rs-tab ${revMode === 'monthly' ? 'rs-on' : ''}" data-rev="monthly">Monthly</button>
          </div>
        </div>
        ${body}
      </div>`;
  }

  function updLines(b) {
    if (!b.updates?.length) return '';
    if (revMode === 'monthly') return `<span class="rs-tip-upd">🛠️ ${b.updates.length} update${b.updates.length > 1 ? 's' : ''} this month</span>`;
    return b.updates.map((t) => {
      const imp = impactText(updateImpact(data.history, t));
      return `<span class="rs-tip-upd">🛠️ Updated ${esc(new Date(t).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }))}${imp ? ` · ${esc(imp)}` : ''}</span>`;
    }).join('');
  }

  function tipHTML(b) {
    if (b.empty) return `<b>${esc(b.long)}</b><span class="rs-muted">No data recorded</span>${updLines(b)}`;
    const lo = b.robux * 0.5, hi = b.robux * 2;
    if (revMode === 'monthly') {
      return `<b>${esc(b.long)}</b>
        <div class="rs-tip-big">${robux(b.robux)} <span>≈ ${usd(b.usd)}</span></div>
        <span class="rs-muted">${robux(b.avgDaily)}/day avg · ${b.dataDays} of ${b.daysInMonth} days recorded</span>
        <span class="rs-muted">likely ${usd(lo * settings.devex)} – ${usd(hi * settings.devex)}</span>${updLines(b)}`;
    }
    return `<b>${esc(b.long)}${b.today ? ' · today' : ''}</b>
      <div class="rs-tip-big">${robux(b.robux)} <span>≈ ${usd(b.usd)}</span></div>
      <span class="rs-muted">${fmt(b.avg)} avg players · ${b.hours >= 23.5 ? 'full day' : `${b.hours.toFixed(1)}h of data`}${b.today ? ' (projected)' : ''}</span>
      <span class="rs-muted">likely ${usd(lo * settings.devex)} – ${usd(hi * settings.devex)}</span>${updLines(b)}`;
  }

  function onChartHover(e) {
    const cell = e.target.closest?.('.rs-hm-cell');
    if (cell) {
      const out = cell.closest('.rs-hm')?.querySelector('.rs-hm-readout');
      if (out) out.textContent = cell.dataset.tip;
    }
    const bar = e.target.closest?.('.rs-rc-bar');
    const chart = e.target.closest?.('[data-chart]');
    if (!bar || !chart) return hideTip();
    const b = chartBars[Number(bar.dataset.i)];
    if (!b) return hideTip();
    const tip = chart.querySelector('.rs-rc-tip');
    chart.querySelectorAll('.rs-rc-bar.rs-hover').forEach((el) => el !== bar && el.classList.remove('rs-hover'));
    bar.classList.add('rs-hover');
    const head = panel.querySelector('[data-rvhead]');
    if (head) {
      head.querySelector('[data-rv]').textContent = b.empty ? '—' : robux(b.robux);
      head.querySelector('[data-ru]').textContent = b.empty ? 'no data' : `≈ ${usd(b.usd)}`;
      head.querySelector('[data-rw]').textContent = `${b.long}${b.today ? ' · today so far' : ''}`;
    }
    if (tip.dataset.i !== bar.dataset.i) { tip.innerHTML = tipHTML(b); tip.dataset.i = bar.dataset.i; }
    tip.hidden = false;
    const cr = chart.getBoundingClientRect(), br = bar.getBoundingClientRect();
    const left = Math.min(Math.max(br.left - cr.left + br.width / 2 - tip.offsetWidth / 2, 0), cr.width - tip.offsetWidth);
    tip.style.left = `${left}px`;
    const fill = bar.querySelector('i').getBoundingClientRect();
    const barTop = (bar.classList.contains('rs-empty') ? br.top + br.height * 0.6 : fill.top) - cr.top;
    tip.style.top = `${Math.max(0, barTop - tip.offsetHeight - 8)}px`;
  }

  function hideTip() {
    const head = panel?.querySelector('[data-rvhead]');
    if (head) {
      head.querySelector('[data-rv]').textContent = head.dataset.v;
      head.querySelector('[data-ru]').textContent = head.dataset.u;
      head.querySelector('[data-rw]').textContent = head.dataset.w;
    }
    panel?.querySelectorAll('.rs-rc-tip').forEach((t) => { t.hidden = true; t.dataset.i = ''; });
    panel?.querySelectorAll('.rs-rc-bar.rs-hover').forEach((el) => el.classList.remove('rs-hover'));
  }

  function destroyCharts() { charts.forEach((c) => c.destroy()); charts = []; }

  function render() {
    destroyCharts();
    const { game: g, votes: v, servers: s, history = [], tracked } = data;
    const up = v?.upVotes ?? 0, down = v?.downVotes ?? 0, total = up + down;
    const ratio = total ? up / total : NaN;
    const ageDays = (Date.now() - Date.parse(g.created)) / 864e5;
    const lifetimePerDay = ageDays > 0 ? g.visits / ageDays : NaN;
    const recent = recentRate(history);
    const peak = history.reduce((m, p) => Math.max(m, p[1]), g.playing || 0);
    const favPer1k = g.visits ? (g.favoritedCount / g.visits) * 1000 : NaN;
    const updates = data.updates || [];
    const spanH = history.length > 1 ? (history.at(-1)[0] - history[0][0]) / 36e5 : 0;

    const trackBtn = `<button class="rs-btn rs-track ${tracked ? 'rs-on' : ''}" data-act="track" title="${tracked ? 'Stop tracking' : 'Record stats every 15 minutes'}">${icon('star', 13)}${tracked ? 'Tracking' : 'Track'}</button>
      <button class="rs-btn rs-rival ${data.rival ? 'rs-on' : ''}" data-act="rival" title="${data.rival ? 'Stop watching as a rival' : 'Watch as a rival: alerts when it updates, changes its icon, adds a game pass or spikes'}">${icon('swords', 13)}${data.rival ? 'Rival' : 'Watch rival'}</button>`;

    const serverTile = s
      ? tile('Servers here', s.more ? `~${fmt(s.estimate)}` : fmtFull(s.count),
          `${pct(s.fill, 0)} avg fill${s.avgPing != null ? ` · ${s.avgPing}ms` : ''}`, '', 'server')
      : tile('Servers here', '—', 'unavailable', '', 'server');
    const recentTile = recent
      ? tile('Visits / day', fmt(recent.perDay), `measured over ${recent.hours < 20 ? `${recent.hours.toFixed(1)}h` : `${Math.round(recent.hours)}h`}`, '', 'trend')
      : tile('Visits / day', fmt(lifetimePerDay), 'lifetime avg · track for live rate', '', 'trend');
    const lastImp = updates.length ? impactText(updateImpact(history, updates.at(-1))) : '';

    let chartBody;
    if (view === 'heatmap') chartBody = heatmapHTML(data.hm);
    else chartBody = history.length >= 2 || range === 'Live'
      ? `<div class="rs-pc">
          <div class="rs-pc-head"><b class="rs-pc-val" data-pv></b><span class="rs-pc-chg" data-pc></span><span class="rs-pc-when" data-pw></span></div>
          <div class="rs-pchart" data-pchart></div>
        </div>`
      : `<p class="rs-hint">${tracked ? 'History is building. A new point is recorded every 15 minutes.' : `Hit <b>Track</b> to record players every 15 minutes and unlock the history chart.`}</p>`;

    const recentUpd = updates.slice(-4).reverse();
    const updList = recentUpd.length && view !== 'heatmap' ? `
      <div class="rs-upds">
        <span class="rs-upds-title">Recent updates</span>
        ${recentUpd.map((t) => {
          const imp = updateImpact(history, t);
          const cls = !imp || imp.pending ? '' : imp.pct >= 0.05 ? 'rs-good' : imp.pct <= -0.05 ? 'rs-bad' : '';
          return `<span class="rs-upd"><span>${esc(fmtWhen(t))}</span>${imp ? `<b class="${cls}">${esc(impactText(imp))}</b>` : '<em>not enough data around it</em>'}</span>`;
        }).join('')}
      </div>` : '';

    const rev = settings ? revenueSummary(data.days || {}, eff(), avgConcurrent(history, g.playing).avg) : null;
    const sum = `
      <span class="rs-sum-item">${g.playing ? '<i class="rs-sum-live"></i>' : ''}<b>${fmtFull(g.playing)}</b> playing</span>
      <span class="rs-sum-item"><b class="${ratioClass(ratio)}">${pct(ratio)}</b> liked</span>
      ${rev ? `<span class="rs-sum-item"><b class="rs-sum-money">${robux(rev.robuxDay)}</b>/day <em>≈ ${usd(rev.usdDay)}</em></span>` : ''}
      <span class="rs-sum-item rs-sum-more">${collapsed ? 'All stats' : 'Hide'}${icon('down', 13)}</span>`;
    panel.innerHTML = `
      ${header(trackBtn, sum)}
      <div class="rs-body">
        ${hero()}
        <div class="rs-grid">
          ${tile('Playing now', fmtFull(g.playing), history.length > 1 ? `peak seen ${fmt(peak)}` : '', 'rs-live', 'users')}
          <div class="rs-tile">
            <div class="rs-label">${icon('thumb', 13)}Like ratio</div>
            <div class="rs-value ${ratioClass(ratio)}">${pct(ratio)}</div>
            <div class="rs-bar"><span class="${ratioClass(ratio)}" style="width:${Number.isFinite(ratio) ? (ratio * 100).toFixed(1) : 0}%"></span></div>
            <div class="rs-sub">${fmt(up)} likes · ${fmt(down)} dislikes</div>
          </div>
          ${recentTile}
          ${tile('Total visits', fmt(g.visits), `${fmt(lifetimePerDay)}/day lifetime`, '', 'eye')}
          ${tile('Favorites', fmt(g.favoritedCount), `${Number.isFinite(favPer1k) ? favPer1k.toFixed(1) : '—'} per 1k visits`, '', 'heart')}
          ${serverTile}
          ${tile('Last updated', ago(g.updated), lastImp || new Date(g.updated).toLocaleDateString(), '', 'clock')}
          ${tile('Created', ago(g.created), `${g.maxPlayers} max per server${g.genre && g.genre !== 'All' ? ` · ${esc(g.genre)}` : ''}`, '', 'cake')}
        </div>
        ${settings ? revenueCard(g) : ''}
        <section class="rs-card">
          <div class="rs-card-head">${icon('users')}<span>Players over time</span>${spanH ? `<em>${spanH < 48 ? `${spanH.toFixed(0)}h` : `${(spanH / 24).toFixed(0)}d`} of data</em>` : ''}
          </div>
          ${chartBody}
          <div class="rs-pc-foot">
            ${view === 'players' ? `<div class="rs-seg">${Object.keys(RANGES).map((r) => `<button class="rs-seg-b ${r === range ? 'rs-on' : ''}" data-range="${r}">${r === 'Live' ? '<i class="rs-live-dot"></i>' : ''}${r}</button>`).join('')}</div>` : '<span></span>'}
            <div class="rs-dd">
              <button class="rs-dd-b" data-act="viewmenu">${view === 'players' ? 'Players' : 'Week heatmap'}${icon('down', 13)}</button>
              <div class="rs-dd-menu" hidden>
                <button class="${view === 'players' ? 'rs-on' : ''}" data-view="players">Players</button>
                <button class="${view === 'heatmap' ? 'rs-on' : ''}" data-view="heatmap">Week heatmap</button>
              </div>
            </div>
          </div>
          ${updList}
        </section>
        ${artCard()}
        <div class="rs-two">
          ${passesCard()}
          ${badgesCard()}
        </div>
      </div>`;
    mountPlayersChart();
  }

  // ---- Players chart (Roblox-charts style) -----------------------------------
  function playerPoints() {
    const now = Date.now();
    const span = RANGES[range];
    const cutoff = span === Infinity ? 0 : now - span;
    const pts = (data.history || []).filter((p) => p[0] >= cutoff).map((p) => [p[0], p[1]]);
    if (live.uid === data.universeId) for (const p of live.pts) if (p[0] >= cutoff) pts.push(p);
    pts.sort((a, b) => a[0] - b[0]);
    // end the line at "now" with the freshest count we have
    const cur = data.game?.playing;
    if (Number.isFinite(cur) && (!pts.length || now - pts.at(-1)[0] > 60e3)) pts.push([now, cur]);
    return pts;
  }

  function setPlayersHead(p, first) {
    const pv = panel.querySelector('[data-pv]'), pc = panel.querySelector('[data-pc]'), pw = panel.querySelector('[data-pw]');
    if (!pv || !p) return;
    pv.textContent = fmtFull(Math.round(p.v));
    const base = first?.[1];
    if (Number.isFinite(base) && base > 0) {
      const d = p.v - base, r = d / base;
      pc.className = `rs-pc-chg ${d > 0 ? 'rs-up' : d < 0 ? 'rs-down' : ''}`;
      pc.textContent = `${d > 0 ? '▲' : d < 0 ? '▼' : '•'} ${fmt(Math.abs(Math.round(d)))} (${(Math.abs(r) * 100).toFixed(1)}%)`;
    } else pc.textContent = '';
    pw.textContent = p.hover
      ? new Date(p.t).toLocaleString([], { weekday: 'short', hour: 'numeric', minute: '2-digit' })
      : range === 'Live' ? 'Live' : `Now · ${RANGE_LABEL[range]}`;
    pw.classList.toggle('rs-pc-live', !p.hover && range === 'Live');
  }

  function mountPlayersChart() {
    pchart = null;
    const host = panel.querySelector('[data-pchart]');
    if (!host || !globalThis.RSChart) return;
    const hist = data.history || [];
    const points = playerPoints();
    const markers = pMarkers = [
      ...(data.updates || []).map((t) => {
        const imp = impactText(updateImpact(hist, t));
        return { t, label: `Game update · ${fmtWhen(t)}${imp ? ` · ${imp}` : ''}` };
      }),
      ...(data.artChanges || []).map((c) => {
        const imp = impactText(updateImpact(hist, c.t));
        return { t: c.t, kind: 'art', imgs: [c.before, c.after], wide: c.kind === 'thumbs',
          label: `${c.kind === 'icon' ? 'New icon' : 'New thumbnails'} · ${fmtWhen(c.t)}${imp ? ` · ${imp}` : ''}` };
      }),
    ];
    const now = Date.now();
    const span = RANGES[range];
    pchart = globalThis.RSChart.line(host, {
      series: [{ name: 'Players', color: '#2b8cff', points, markers }],
      look: 'pro', live: range === 'Live', height: 230, gapMs: range === 'Live' ? 20 * 60e3 : 75 * 60e3,
      yFmt: (v) => fmt(v), tipFmt: (v) => (v >= 1e5 ? fmt(v) : fmtFull(Math.round(v))),
      t0: span === Infinity ? undefined : now - span, t1: now, empty: 'No data in this range yet',
      onHover: (h) => setPlayersHead(h ? { ...h, hover: true } : { t: now, v: points.at(-1)?.[1] ?? 0 }, points[0]),
    });
    charts.push(pchart);
    if (points.length) setPlayersHead({ t: now, v: points.at(-1)[1] }, points[0]);
    if (range === 'Live') startLive(); else stopLive();
  }

  function stopLive() { clearInterval(live.timer); live.timer = null; }
  function startLive() {
    if (live.uid !== data.universeId) { live.uid = data.universeId; live.pts = []; }
    if (live.timer) return;
    const tick = async () => {
      if (!panel?.isConnected || range !== 'Live' || view !== 'players' || collapsed || !data) return stopLive();
      try {
        const r = await send({ type: 'livePlaying', universeId: data.universeId });
        if (!Number.isFinite(r?.playing) || live.uid !== data.universeId) return;
        live.pts.push([Date.now(), r.playing]);
        if (live.pts.length > 600) live.pts.shift();
        data.game.playing = r.playing;
        if (pchart && panel.querySelector('[data-pchart]')) {
          const points = playerPoints(), now = Date.now();
          pchart.update({
            series: [{ name: 'Players', color: '#2b8cff', points, markers: pMarkers }], t0: now - RANGES.Live, t1: now,
            onHover: (h) => setPlayersHead(h ? { ...h, hover: true } : { t: now, v: points.at(-1)?.[1] ?? 0 }, points[0]),
          });
          setPlayersHead({ t: now, v: points.at(-1)[1] }, points[0]);
        }
      } catch {}
    };
    live.timer = setInterval(tick, LIVE_EVERY);
    tick();
  }

  async function load() {
    const token = ++loadToken;
    if (!data) renderLoading();
    try {
      const res = await send({ type: 'getStats', placeId });
      if (token !== loadToken) return;
      data = res;
      render();
    } catch (e) {
      if (token !== loadToken) return;
      if (data) render(); else renderError(e.message);
    }
  }

  async function onClick(e) {
    const btn = e.target.closest('button');
    if (!btn) return;
    if (btn.dataset.range) { range = btn.dataset.range; render(); return; }
    if (btn.dataset.view) { view = btn.dataset.view; if (view !== 'players') stopLive(); render(); return; }
    if (btn.dataset.act === 'viewmenu') {
      const m = btn.parentElement.querySelector('.rs-dd-menu');
      m.hidden = !m.hidden;
      if (!m.hidden) setTimeout(() => document.addEventListener('click', function off(ev) {
        if (!btn.parentElement.contains(ev.target)) { m.hidden = true; document.removeEventListener('click', off, true); }
      }, true));
      return;
    }
    if (btn.dataset.rev) { revMode = btn.dataset.rev; render(); return; }
    if (btn.dataset.copy) {
      const value = btn.dataset.value;
      try { await navigator.clipboard.writeText(value); copiedKey = btn.dataset.copy; }
      catch { copiedKey = ''; const c = btn.querySelector('code'); if (c) { const r = document.createRange(); r.selectNodeContents(c); getSelection().removeAllRanges(); getSelection().addRange(r); } return; }
      render();
      setTimeout(() => { if (copiedKey === btn.dataset.copy) { copiedKey = ''; if (data) render(); } }, 1400);
      return;
    }
    switch (btn.dataset.act) {
      case 'places':
        placesOpen = !placesOpen;
        render();
        break;
      case 'passes': showAllPasses = !showAllPasses; render(); break;
      case 'badges': showAllBadges = !showAllBadges; render(); break;
      case 'collapse':
        collapsed = !collapsed;
        try { localStorage.setItem('roscout:collapsed', collapsed ? '1' : '0'); } catch {}
        panel.classList.toggle('rs-collapsed', collapsed);
        data ? render() : renderLoading();
        break;
      case 'refresh':
        btn.classList.add('rs-spin');
        await load();
        break;
      case 'artall': artAll = !artAll; render(); break;
      case 'rival':
        if (!data) return;
        try {
          const cr = data.creator ? { id: data.creator.id, name: data.creator.name, type: data.creator.type } : null;
          const r = await send({ type: 'toggleRival', placeId: data.game.rootPlaceId || placeId, universeId: data.universeId, name: data.game.name, creator: cr });
          data.rival = r.rival; data.tracked = true;
          render();
        } catch {}
        break;
      case 'track':
        if (!data) return;
        try {
          const cr = data.creator ? { id: data.creator.id, name: data.creator.name, type: data.creator.type } : null;
          const { tracked } = await send({ type: 'toggleTrack', placeId: data.game.rootPlaceId || placeId, universeId: data.universeId, name: data.game.name, creator: cr });
          data.tracked = tracked;
          render();
        } catch {}
        break;
    }
  }

  async function check() {
    const id = currentPlaceId();
    if (id !== placeId) {
      placeId = id;
      data = null;
      placesOpen = false;
      showAllPasses = false;
      showAllBadges = false;
      panel?.remove();
      if (!id) return;
      await mount();
      load();
    } else if (id && panel && !panel.isConnected) {
      // Roblox re-rendered the page and dropped our panel — put it back.
      await mount();
    }
  }

  check();
  setInterval(check, 1000);
})();
