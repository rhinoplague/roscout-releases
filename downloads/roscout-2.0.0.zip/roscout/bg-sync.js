// RoScout background: settings that follow you (chrome.storage.sync).
// Synced: your tracked games and rivals, pinned friends, background settings (not the image,
// which is too big for Chrome sync), watched rising-feed keywords. "settings" (revenue + alerts)
// already lives in chrome.storage.sync.
// History, charts and saved artwork stay on each computer; use Backup in the Export tab to move those.

const SYNC_TRACKED = 'rsSyncTracked';
const SYNC_MISC = 'rsSyncMisc';
const SYNC_WATCH = ['tracked', 'pinnedFriends', 'rsBg', 'riseKeywords'];
let applyingUntil = 0;
let pushTimer = null;
let lastSig = '';

async function buildSync() {
  const { tracked = {}, pinnedFriends = [], rsBg = null, riseKeywords = [] } = await chrome.storage.local.get(SYNC_WATCH);
  let list = Object.entries(tracked).slice(0, 150).map(([id, e]) => [Number(id), e.placeId || 0, e.rival ? 1 : 0, String(e.name || '').slice(0, 40)]);
  if (JSON.stringify(list).length > 7500) list = list.map((x) => [x[0], x[1], x[2], '']); // stay under Chrome's 8 KB per item
  const bg = rsBg ? { on: !!rsBg.on, opacity: rsBg.opacity, blur: rsBg.blur, dim: rsBg.dim, fit: rsBg.fit, pos: rsBg.pos } : null;
  return { list, misc: { pins: pinnedFriends.slice(0, 200), bg, kw: riseKeywords.slice(0, 8) } };
}

async function pushSync() {
  const b = await buildSync();
  const sig = JSON.stringify(b);
  if (sig === lastSig) return;
  const t = Date.now();
  try {
    await chrome.storage.sync.set({ [SYNC_TRACKED]: { t, list: b.list }, [SYNC_MISC]: { t, ...b.misc } });
    lastSig = sig;
    await chrome.storage.local.set({ syncT: t, syncInfo: { pushed: t } });
  } catch (e) {
    await chrome.storage.local.set({ syncInfo: { error: e.message, at: t } });
  }
}

async function pullSync() {
  const got = await chrome.storage.sync.get([SYNC_TRACKED, SYNC_MISC]);
  const tb = got[SYNC_TRACKED], mb = got[SYNC_MISC];
  if (!tb && !mb) { await pushSync(); return { pushed: true }; }
  const local = await chrome.storage.local.get([...SYNC_WATCH, 'syncT']);
  const remoteT = Math.max(tb?.t || 0, mb?.t || 0);
  if (local.syncT && remoteT <= local.syncT) return { upToDate: true };
  const first = !local.syncT; // first sync on this computer: combine both sides instead of replacing
  const writes = { syncT: remoteT, syncInfo: { pulled: Date.now() } };
  if (tb) {
    const tracked = local.tracked || {};
    const remote = new Map(tb.list.map((x) => [String(x[0]), x]));
    for (const [id, x] of remote) {
      if (!tracked[id]) tracked[id] = { placeId: x[1], name: x[3] || 'Loading…', creator: null, addedAt: Date.now() };
      tracked[id].rival = first ? !!(tracked[id].rival || x[2]) : !!x[2];
    }
    if (!first) for (const id of Object.keys(tracked)) if (!remote.has(id)) delete tracked[id];
    writes.tracked = tracked;
  }
  if (mb) {
    writes.pinnedFriends = first ? [...new Set([...(local.pinnedFriends || []), ...(mb.pins || [])])] : (mb.pins || []);
    if (mb.bg) writes.rsBg = { ...(local.rsBg || {}), ...mb.bg };
    writes.riseKeywords = first ? [...new Set([...(local.riseKeywords || []), ...(mb.kw || [])])].slice(-8) : (mb.kw || []);
  }
  applyingUntil = Date.now() + 3000;
  await chrome.storage.local.set(writes);
  if (first) setTimeout(() => pushSync().catch(() => {}), 4000);
  ensureAlarm();
  return { applied: true };
}

chrome.storage.onChanged.addListener((ch, area) => {
  if (area === 'local' && SYNC_WATCH.some((k) => ch[k])) {
    if (Date.now() < applyingUntil) return;
    clearTimeout(pushTimer);
    pushTimer = setTimeout(() => pushSync().catch(() => {}), 4000);
  }
  if (area === 'sync' && (ch[SYNC_TRACKED] || ch[SYNC_MISC])) pullSync().catch(() => {});
});

chrome.runtime.onStartup.addListener(() => { pullSync().catch(() => {}); });
chrome.runtime.onInstalled.addListener(() => { pullSync().catch(() => {}); });

handlers.syncStatus = async () => {
  const { syncInfo = null, syncT = null } = await chrome.storage.local.get(['syncInfo', 'syncT']);
  let bytes = null;
  try { bytes = await chrome.storage.sync.getBytesInUse(null); } catch {}
  const b = await buildSync();
  return { info: syncInfo, syncT, bytes, counts: { games: b.list.length, rivals: b.list.filter((x) => x[2]).length, pins: b.misc.pins.length, keywords: b.misc.kw.length } };
};

handlers.syncNow = async () => {
  const r = await pullSync();
  lastSig = '';
  await pushSync();
  return { ...r, ...(await handlers.syncStatus()) };
};

// Backup: everything RoScout keeps on this computer, minus caches it can rebuild.
const CACHE_PREFIX = /^(prof:|cr:|pl:|gp:|bd:|gs:|gi:|uni:|notifLinks$|updateInfo$|mpLast$|mpNow$)/;
handlers.backup = async () => {
  const all = await chrome.storage.local.get(null);
  const data = {};
  for (const [k, v] of Object.entries(all)) if (!CACHE_PREFIX.test(k)) data[k] = v;
  let settings = null;
  try { settings = (await chrome.storage.sync.get('settings')).settings || null; } catch {}
  return { roscoutBackup: 1, version: chrome.runtime.getManifest().version, made: Date.now(), data, settings };
};

handlers.restore = async ({ backup }) => {
  if (!backup || backup.roscoutBackup !== 1 || typeof backup.data !== 'object') throw new Error("That file isn't a RoScout backup");
  applyingUntil = Date.now() + 5000;
  await chrome.storage.local.set(backup.data);
  if (backup.settings) { try { await chrome.storage.sync.set({ settings: backup.settings }); } catch {} }
  await chrome.storage.local.remove('syncT');
  setTimeout(() => { lastSig = ''; pushSync().catch(() => {}); }, 5500);
  ensureAlarm();
  return { ok: true, keys: Object.keys(backup.data).length };
};
