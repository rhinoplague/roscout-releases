// RoScout window pages added in 2.0: Rising games, Rivals, Friend requests, and Sync & backup.
// dashboard.js calls RSPages[tab].render(main) and hands over a small context as globalThis.RSDash.
(() => {
  const { esc, fmt, fmtFull, pct, ago, usd, robux, send, icon, sparkline, revenueSummary, withMon, monetization, avgConcurrent, PALETTE } = globalThis.RS;
  const ctx = () => globalThis.RSDash;
  const on = (name) => ctx()?.tab === name;
  const main = document.getElementById('main');
  const gameUrl = (placeId) => `https://www.roblox.com/games/${encodeURIComponent(placeId)}`;
  const avatarUrl = (id) => `https://www.roblox.com/users/${id}/profile`;
  const LIST_NAMES = { 'up-and-coming': 'Up-and-coming', 'top-trending': 'Trending', 'top-playing-now': 'Top playing', 'top-earning': 'Top earning' };
  const growthHTML = (g) => g == null ? '<span class="dim">—</span>'
    : `<span class="${g >= 0 ? 'up' : 'down'}">${g >= 0 ? '▲' : '▼'} ${Math.abs(g) >= 10 ? `${Math.round(Math.abs(g))}×` : pct(Math.abs(g), 0)}</span>`;
  const spanText = (ms) => (ms < 36e5 ? `${Math.max(1, Math.round(ms / 60e3))} min` : `${(ms / 36e5).toFixed(ms < 10 * 36e5 ? 1 : 0)}h`);

  // ===================================================================================
  // Rising games
  // ===================================================================================
  const RZ = { data: null, loading: false, error: '', window: '6h', min: 100, genre: '', q: '', kw: '', busy: new Set(), focus: null, limit: 40 };
  let rzTimer = null;

  async function loadRising(refresh = false) {
    RZ.loading = true; RZ.error = '';
    if (on('rising')) renderRising();
    try {
      RZ.data = await send({ type: 'riseFeed', window: RZ.window, q: RZ.q, genre: RZ.genre, min: RZ.min, refresh });
    } catch (e) { RZ.error = e.message; }
    RZ.loading = false;
    if (on('rising')) renderRising();
  }

  function risingRow(g, i) {
    const lists = g.lists.filter((l) => LIST_NAMES[l]).slice(0, 2).map((l) => `<span class="rz-tag rz-${l}">${LIST_NAMES[l]}</span>`).join('');
    const kws = g.keywords.slice(0, 1).map((k) => `<span class="rz-tag rz-kw">${icon('search', 11)}${esc(k)}</span>`).join('');
    return `<div class="rz-row">
      <span class="rz-rank">${i + 1}</span>
      <a class="rz-game" href="${gameUrl(g.placeId)}" target="_blank" rel="noopener">
        <span class="rz-icon">${g.icon ? `<img src="${esc(g.icon)}" alt="" loading="lazy">` : ''}</span>
        <span class="rz-text"><b>${esc(g.name)}</b><span>${g.creator ? `by ${esc(g.creator)}` : ''}${g.genre ? `${g.creator ? ' · ' : ''}${esc(g.genre)}` : ''}</span><span class="rz-tags">${lists}${kws}</span></span>
      </a>
      <span class="rz-spark">${g.spark.length >= 2 ? sparkline(g.spark, 140, 34, g.growth != null && g.growth < 0 ? '#ff6464' : '#2b8cff') : ''}</span>
      <span class="rz-num"><b>${fmtFull(g.playing)}</b><em>playing</em></span>
      <span class="rz-num rz-growth">${growthHTML(g.growth)}<em>${g.gain != null ? `${g.gain >= 0 ? '+' : '−'}${fmt(Math.abs(g.gain))} in ${RZ.window}` : 'growth soon'}</em></span>
      <span class="rz-acts">
        <button class="rz-btn ${g.tracked ? 'on' : ''}" data-rz-track="${g.universeId}" data-rz-place="${g.placeId}" title="${g.tracked ? 'Tracking' : 'Track: record every 15 minutes'}" ${g.tracked ? 'disabled' : ''}>${icon('star', 14)}</button>
        <button class="rz-btn rz-rival ${g.rival ? 'on' : ''}" data-rz-rival="${g.universeId}" data-rz-place="${g.placeId}" title="${g.rival ? 'Watching as a rival' : 'Watch as a rival'}">${icon('swords', 14)}</button>
      </span>
    </div>`;
  }

  function renderRising() {
    const d = RZ.data;
    if (!d && !RZ.error) {
      main.innerHTML = `<section class="card"><div class="card-head"><h2>Rising games</h2></div><div class="rz-loading">${icon('sparkle', 18)}<span>Reading Roblox's discovery lists… this takes a few seconds the first time.</span></div></section>`;
      if (!RZ.loading) loadRising();
      return;
    }
    const kwChips = (d?.keywords || []).map((k) => `<span class="rz-chip">${icon('search', 12)}${esc(k)}<button data-rz-unkw="${esc(k)}" title="Stop watching this keyword" aria-label="Remove ${esc(k)}">${icon('x', 12)}</button></span>`).join('');
    const ready = d?.ready;
    const sinceMs = d ? d.scanned - d.since : 0;
    const status = d ? `${fmtFull(d.total)} games checked · updated ${ago(d.scanned)}${ready ? '' : ` · growth over ${RZ.window} shows once RoScout has ${RZ.window} of scans (${spanText(sinceMs)} so far), until then this is Roblox's own trending order`}` : '';
    main.innerHTML = `
      <section class="card rz-card">
        <div class="card-head">
          <h2>Rising games</h2>
          <div class="seg" title="Growth over">${['1h', '6h', '24h'].map((w) => `<button data-rz-win="${w}" class="${RZ.window === w ? 'on' : ''}">${w}</button>`).join('')}</div>
          <div class="seg" title="Minimum players">${[[100, '100+'], [1000, '1K+'], [10000, '10K+']].map(([v, l]) => `<button data-rz-min="${v}" class="${RZ.min === v ? 'on' : ''}">${l}</button>`).join('')}</div>
          <select id="rz-genre" aria-label="Genre"><option value="">All genres</option>${(d?.genres || []).map((g) => `<option ${g === RZ.genre ? 'selected' : ''}>${esc(g)}</option>`).join('')}</select>
          <button class="btn sm" data-rz-refresh ${RZ.loading ? 'disabled' : ''}>${icon('refresh', 14)}${RZ.loading ? 'Checking…' : 'Check now'}</button>
        </div>
        <div class="rz-search">
          <span class="rz-sbox">${icon('search', 15)}<input id="rz-q" type="search" placeholder="Filter by name, creator or keyword" value="${esc(RZ.q)}" autocomplete="off"></span>
          <button class="btn sm" data-rz-kw ${RZ.q.trim() ? '' : 'disabled'} title="Also search Roblox for this every 30 minutes, so smaller games with it show up too">${icon('bell', 14)}Watch keyword</button>
          ${kwChips ? `<span class="rz-chips">${kwChips}</span>` : ''}
        </div>
        <p class="note">${esc(status)}</p>
        ${RZ.error ? `<div class="empty">Couldn't load the rising feed: ${esc(RZ.error)}</div>` : ''}
        ${d && !d.games.length ? `<div class="empty">No games match. Try a lower minimum or another genre.</div>` : ''}
        <div class="rz-list">${(d?.games || []).slice(0, RZ.limit).map(risingRow).join('')}</div>
        ${(d?.games || []).length > RZ.limit ? `<button class="btn rz-more" data-rz-more>Show more</button>` : ''}
        <label class="rz-bg"><input type="checkbox" id="rz-scan" ${d?.scanning !== false ? 'checked' : ''}> Keep checking every 30 minutes in the background, so growth is ready when you open this</label>
      </section>`;
    if (RZ.focus) {
      const el = document.getElementById('rz-q');
      if (el) { el.focus(); el.setSelectionRange(RZ.focus, RZ.focus); }
      RZ.focus = null;
    }
  }

  main.addEventListener('click', async (e) => {
    if (!on('rising')) return;
    const b = e.target.closest('button');
    if (!b) return;
    if ('rzMore' in b.dataset) { RZ.limit += 40; renderRising(); return; }
    if (b.dataset.rzWin) { RZ.window = b.dataset.rzWin; loadRising(); }
    else if (b.dataset.rzMin) { RZ.min = Number(b.dataset.rzMin); loadRising(); }
    else if ('rzRefresh' in b.dataset) loadRising(true);
    else if ('rzKw' in b.dataset) {
      const kw = RZ.q.trim();
      if (!kw) return;
      b.disabled = true;
      await send({ type: 'riseKeyword', keyword: kw }).catch(() => {});
      loadRising();
    } else if (b.dataset.rzUnkw) {
      await send({ type: 'riseKeyword', keyword: b.dataset.rzUnkw, remove: true }).catch(() => {});
      loadRising();
    } else if (b.dataset.rzTrack) {
      b.disabled = true;
      try { await send({ type: 'trackPlace', placeId: Number(b.dataset.rzPlace) }); const g = RZ.data.games.find((x) => x.universeId === Number(b.dataset.rzTrack)); if (g) g.tracked = true; ctx().reloadGames(); } catch {}
      renderRising();
    } else if (b.dataset.rzRival) {
      b.disabled = true;
      try {
        const id = Number(b.dataset.rzRival);
        const r = await send({ type: 'toggleRival', universeId: id, placeId: Number(b.dataset.rzPlace) });
        const g = RZ.data.games.find((x) => x.universeId === id);
        if (g) { g.rival = r.rival; g.tracked = true; }
        ctx().reloadGames(); RV.data = null;
      } catch {}
      renderRising();
    }
  });
  main.addEventListener('input', (e) => {
    if (!on('rising') || e.target.id !== 'rz-q') return;
    RZ.q = e.target.value;
    document.querySelector('[data-rz-kw]')?.toggleAttribute('disabled', !RZ.q.trim());
    clearTimeout(rzTimer);
    rzTimer = setTimeout(() => { RZ.focus = e.target.selectionStart || RZ.q.length; loadRising(); }, 350);
  });
  main.addEventListener('change', async (e) => {
    if (!on('rising')) return;
    if (e.target.id === 'rz-genre') { RZ.genre = e.target.value; loadRising(); }
    if (e.target.id === 'rz-scan') { await send({ type: 'riseScanSetting', on: e.target.checked }).catch(() => {}); if (RZ.data) RZ.data.scanning = e.target.checked; }
  });

  // ===================================================================================
  // Rivals
  // ===================================================================================
  const RV = { data: null, loading: false, error: '', chart: null, range: '7d', logFilter: 'all' };
  const RV_RANGE = { '24h': 864e5, '7d': 7 * 864e5, '30d': 30 * 864e5 };
  const KIND = {
    update: { label: 'Update', ico: 'refresh' }, icon: { label: 'New icon', ico: 'image' }, thumbs: { label: 'Thumbnails', ico: 'image' },
    pass: { label: 'Game pass', ico: 'ticket' }, spike: { label: 'Spike', ico: 'flame' },
  };

  async function loadRivals() {
    RV.loading = true;
    try { RV.data = await send({ type: 'rivals' }); RV.error = ''; } catch (e) { RV.error = e.message; }
    RV.loading = false;
    if (on('rivals')) renderRivals();
  }

  function change24(h) {
    const now = Date.now();
    const cur = h.at(-1);
    if (!cur) return null;
    let past = null;
    for (const s of h) if (s[0] <= now - 864e5 + 30 * 60e3) past = s;
    if (!past || now - 864e5 - past[0] > 90 * 60e3 || !past[1]) return null;
    return (cur[1] - past[1]) / past[1];
  }

  function rivalCard(g, color) {
    const h = g.history || [];
    const last = h.at(-1);
    const settings = ctx().settings();
    const rev = revenueSummary(g.days || {}, withMon(settings, monetization(g.passPrices, settings)), avgConcurrent(h, last?.[1] || 0).avg);
    const c24 = change24(h);
    const day = h.filter((p) => p[0] >= Date.now() - 864e5).map((p) => [p[0], p[1]]);
    const lastUpd = (g.updates || []).at(-1);
    const lastArt = (g.artChanges || []).at(-1);
    return `<article class="rv-card" style="--c:${color}">
      <div class="rv-top">
        <span class="rv-icon">${g.icon ? `<img src="${esc(g.icon)}" alt="">` : ''}</span>
        <a class="rv-name" href="${gameUrl(g.placeId)}" target="_blank" rel="noopener"><b>${esc(g.name)}</b><span>${g.creator?.name ? `by ${esc(g.creator.name)}` : ''}</span></a>
        <button class="rv-x" data-rv-drop="${g.universeId}" title="Stop watching as a rival">${icon('x', 14)}</button>
      </div>
      <div class="rv-now"><b>${fmtFull(last?.[1])}</b><span>playing</span>${c24 != null ? `<span class="${c24 >= 0 ? 'up' : 'down'}">${c24 >= 0 ? '▲' : '▼'} ${pct(Math.abs(c24), 1)} 24h</span>` : ''}</div>
      ${day.length >= 2 ? sparkline(day, 260, 44, color) : '<div class="rv-nodata">Chart fills in over the next few polls</div>'}
      <div class="rv-facts">
        <span>${icon('coins', 13)}<b>${robux(rev.robuxDay)}</b>/day <em>≈ ${usd(rev.usdDay)}</em></span>
        <span>${icon('ticket', 13)}<b>${g.passCount ?? '—'}</b> passes</span>
        <span>${icon('refresh', 13)}updated <b>${lastUpd ? ago(lastUpd) : '—'}</b></span>
        <span>${icon('image', 13)}art <b>${lastArt ? ago(lastArt.t) : 'no changes yet'}</b></span>
      </div>
    </article>`;
  }

  function logRow(x) {
    const k = KIND[x.kind] || { label: x.kind, ico: 'bell' };
    const art = (x.kind === 'icon' || x.kind === 'thumbs') && x.img;
    return `<div class="rv-log-row rv-k-${esc(x.kind)}">
      <span class="rv-log-ico">${icon(k.ico, 15)}</span>
      <div class="rv-log-main"><span><a href="${gameUrl(x.placeId)}" target="_blank" rel="noopener">${esc(x.name)}</a> · ${esc(x.text)}</span><em>${esc(new Date(x.t).toLocaleString([], { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }))} · ${esc(ago(x.t))}</em></div>
      ${art ? `<span class="rv-log-art ${x.kind === 'thumbs' ? 'wide' : ''}">${x.before ? `<img src="${esc(x.before)}" alt="Before"><i>→</i>` : ''}<img src="${esc(x.img)}" alt="After"></span>`
        : x.img ? `<span class="rv-log-art"><img src="${esc(x.img)}" alt=""></span>` : ''}
    </div>`;
  }

  function renderRivals() {
    RV.chart?.destroy(); RV.chart = null;
    if (!RV.data) {
      main.innerHTML = '<div class="empty">Loading rivals…</div>';
      if (!RV.loading) loadRivals();
      return;
    }
    if (RV.error) { main.innerHTML = `<div class="empty">Couldn't load rivals: ${esc(RV.error)}</div>`; return; }
    const { games, log } = RV.data;
    if (!games.length) {
      main.innerHTML = `<section class="card rv-empty">
        <div class="rv-empty-ico">${icon('swords', 26)}</div>
        <h2>Watch your rivals</h2>
        <p>Pick games you're up against and RoScout will tell you when they publish an update, change their icon or thumbnails, add a game pass, or spike in players. Everything they do lands in a timeline here.</p>
        <p class="dim">Press <b>Watch rival</b> in the RoScout panel on any game page, or the ⚔ button next to a game in <a href="#rising">Rising games</a>.</p>
      </section>`;
      return;
    }
    const filtered = RV.logFilter === 'all' ? log : log.filter((x) => (RV.logFilter === 'art' ? x.kind === 'icon' || x.kind === 'thumbs' : x.kind === RV.logFilter));
    main.innerHTML = `
      <section class="card">
        <div class="card-head"><h2>Rivals</h2><span class="dim">${games.length} watched · checked every 15 minutes</span></div>
        <div class="rv-grid">${games.map((g, i) => rivalCard(g, PALETTE[i % PALETTE.length])).join('')}</div>
      </section>
      <section class="card">
        <div class="card-head"><h2>Players</h2>
          <div class="seg">${Object.keys(RV_RANGE).map((r) => `<button data-rv-range="${r}" class="${RV.range === r ? 'on' : ''}">${r}</button>`).join('')}</div>
        </div>
        <div id="rv-chart" class="cmp-chart"></div>
        <p class="note">Diamonds mark updates and circles mark icon or thumbnail changes. Hover one for details.</p>
      </section>
      <section class="card">
        <div class="card-head"><h2>Activity</h2>
          <div class="seg">${[['all', 'All'], ['update', 'Updates'], ['art', 'Art'], ['pass', 'Game passes'], ['spike', 'Spikes']].map(([k, l]) => `<button data-rv-log="${k}" class="${RV.logFilter === k ? 'on' : ''}">${l}</button>`).join('')}</div>
        </div>
        ${filtered.length ? `<div class="rv-log">${filtered.slice(0, 80).map(logRow).join('')}</div>`
          : `<div class="empty">Nothing yet. New activity from your rivals shows up here as RoScout spots it.</div>`}
      </section>`;
    mountRivalChart(games);
  }

  function mountRivalChart(games) {
    const host = document.getElementById('rv-chart');
    if (!host || !globalThis.RSChart) return;
    const now = Date.now(), from = now - RV_RANGE[RV.range];
    const series = games.map((g, i) => ({
      name: g.name, color: PALETTE[i % PALETTE.length],
      points: (g.history || []).filter((s) => s[0] >= from).map((s) => [s[0], s[1]]),
      markers: [
        ...(g.updates || []).filter((t) => t >= from).map((t) => ({ t, label: `${g.name} updated` })),
        ...(g.artChanges || []).filter((c) => c.t >= from).map((c) => ({ t: c.t, kind: 'art', label: `${g.name}: ${c.kind === 'icon' ? 'new icon' : 'new thumbnails'}` })),
      ],
    }));
    RV.chart = globalThis.RSChart.line(host, {
      series, look: 'pro', axes: true, height: 300, t0: from, t1: now, area: series.length <= 2,
      yFmt: (v) => fmt(v), tipFmt: (v) => fmtFull(Math.round(v)), empty: 'Not enough data in this range yet.',
    });
  }

  main.addEventListener('click', async (e) => {
    if (!on('rivals')) return;
    const b = e.target.closest('button');
    if (!b) return;
    if (b.dataset.rvRange) { RV.range = b.dataset.rvRange; renderRivals(); }
    else if (b.dataset.rvLog) { RV.logFilter = b.dataset.rvLog; renderRivals(); }
    else if (b.dataset.rvDrop) {
      b.disabled = true;
      await send({ type: 'toggleRival', universeId: Number(b.dataset.rvDrop) }).catch(() => {});
      RV.data = null; ctx().reloadGames(); renderRivals();
    }
  });

  // ===================================================================================
  // Friend requests you sent
  // ===================================================================================
  const FR = { data: null, loading: false, filter: 'all' };
  const FR_STATUS = {
    pending: ['Pending', 'pending'], accepted: ['Accepted', 'accepted'], gone: ['Not accepted', 'gone'], mutual: ['They sent you one too', 'mutual'],
  };

  async function loadRequests() {
    FR.loading = true;
    if (on('requests')) renderRequests();
    try { FR.data = await send({ type: 'sentRequests' }); } catch (e) { FR.data = { list: [], error: e.message }; }
    FR.loading = false;
    if (on('requests')) renderRequests();
  }

  function renderRequests() {
    if (!FR.data) {
      main.innerHTML = '<div class="empty">Loading friend requests…</div>';
      if (!FR.loading) loadRequests();
      return;
    }
    const { list, error, signedIn } = FR.data;
    const count = (s) => list.filter((r) => r.status === s).length;
    const shown = FR.filter === 'all' ? list : list.filter((r) => r.status === FR.filter);
    const rows = shown.map((r) => {
      const [label, cls] = FR_STATUS[r.status] || [r.status, ''];
      const when = r.status === 'accepted' && r.done ? `accepted ${ago(r.done)}` : r.status === 'gone' && r.done ? `noticed ${ago(r.done)}` : '';
      return `<div class="fr-row">
        <a class="fr-who" href="${avatarUrl(r.userId)}" target="_blank" rel="noopener">
          <span class="fr-ava">${r.headshot ? `<img src="${esc(r.headshot)}" alt="">` : ''}</span>
          <span class="fr-names"><b>${esc(r.displayName || r.name || `User ${r.userId}`)}</b><span>${r.name ? `@${esc(r.name)}` : ''}</span></span>
        </a>
        <span class="fr-sent">Sent ${esc(ago(r.t))}${when ? ` · ${esc(when)}` : ''}</span>
        <span class="fr-pill fr-${cls}">${r.status === 'accepted' ? icon('check', 12) : ''}${label}</span>
        <button class="fr-x" data-fr-forget="${r.userId}" title="Remove from this list">${icon('x', 14)}</button>
      </div>`;
    }).join('');
    main.innerHTML = `
      <section class="card">
        <div class="card-head"><h2>Friend requests you sent</h2>
          <div class="seg">${[['all', `All ${list.length}`], ['pending', `Pending ${count('pending')}`], ['accepted', `Accepted ${count('accepted')}`], ['gone', `Not accepted ${count('gone')}`]].map(([k, l]) => `<button data-fr-filter="${k}" class="${FR.filter === k ? 'on' : ''}">${l}</button>`).join('')}</div>
          <button class="btn sm" data-fr-refresh ${FR.loading ? 'disabled' : ''}>${icon('refresh', 14)}${FR.loading ? 'Checking…' : 'Check now'}</button>
        </div>
        <p class="note">Roblox doesn't keep a list of requests you've sent, so RoScout notes each one when you send it on roblox.com and checks every 20 minutes whether it was accepted. You get a notification when someone accepts. "Not accepted" means they declined it or it was cancelled.</p>
        ${error ? `<p class="fr-err">${esc(error)}</p>` : ''}
        ${!signedIn ? '<p class="fr-err">Open roblox.com once while signed in so RoScout knows which account is yours.</p>' : ''}
        ${rows ? `<div class="fr-list">${rows}</div>` : `<div class="empty">${list.length ? 'Nothing here with this filter.' : '<b>No requests tracked yet.</b><br>Send a friend request on roblox.com and it shows up here.'}</div>`}
      </section>`;
  }

  main.addEventListener('click', async (e) => {
    if (!on('requests')) return;
    const b = e.target.closest('button');
    if (!b) return;
    if (b.dataset.frFilter) { FR.filter = b.dataset.frFilter; renderRequests(); }
    else if ('frRefresh' in b.dataset) loadRequests();
    else if (b.dataset.frForget) {
      await send({ type: 'forgetRequest', userId: Number(b.dataset.frForget) }).catch(() => {});
      FR.data.list = FR.data.list.filter((r) => r.userId !== Number(b.dataset.frForget));
      renderRequests();
    }
  });

  // ===================================================================================
  // Sync & backup (shown at the bottom of the Export page)
  // ===================================================================================
  const SY = { status: null, msg: '', pending: null, busy: false };

  async function loadSync() {
    try { SY.status = await send({ type: 'syncStatus' }); } catch (e) { SY.msg = e.message; }
    if (on('export')) ctx().rerender();
  }

  function syncHTML() {
    if (!SY.status) { loadSync(); return '<section class="card"><div class="card-head"><h2>Sync &amp; backup</h2></div><p class="dim">Loading…</p></section>'; }
    const { info, counts } = SY.status;
    const last = info?.pushed || info?.pulled;
    const state = info?.error ? `<span class="down">Couldn't sync: ${esc(info.error)}</span>` : last ? `Last synced ${esc(ago(last))}` : 'Not synced yet';
    return `<section class="card sy">
      <div class="card-head"><h2>Sync &amp; backup</h2><button class="btn sm" data-sy-now ${SY.busy ? 'disabled' : ''}>${icon('sync', 14)}Sync now</button></div>
      <div class="sy-grid">
        <div class="ex">
          <h3>${icon('sync', 15)}Follows your Chrome account</h3>
          <p>${state}. Synced: ${counts.games} tracked game${counts.games === 1 ? '' : 's'} (${counts.rivals} rival${counts.rivals === 1 ? '' : 's'}), ${counts.pins} pinned friend${counts.pins === 1 ? '' : 's'}, ${counts.keywords} watched keyword${counts.keywords === 1 ? '' : 's'}, your background settings, revenue and alert settings.</p>
          <p class="dim">Needs Chrome sync turned on. Chrome only links RoScout between installs that use the same folder path, so after a reinstall keep RoScout in the same folder. The background image, charts history and saved artwork stay on each computer: use a backup to move those.</p>
        </div>
        <div class="ex">
          <h3>${icon('download', 15)}Backup</h3>
          <p>One file with everything RoScout keeps on this computer: tracked games and their history, rivals, saved icons and thumbnails, friend requests, playtime, your background image and settings.</p>
          <button class="btn" data-sy-backup ${SY.busy ? 'disabled' : ''}>${icon('download', 15)}Download backup</button>
        </div>
        <div class="ex">
          <h3>${icon('upload', 15)}Restore</h3>
          <p>Load a backup file on this or another computer. It adds to and overwrites what's here; nothing else is deleted.</p>
          ${SY.pending
            ? `<p><b>${esc(SY.pending.name)}</b> · from RoScout ${esc(SY.pending.backup.version || '?')}, made ${esc(new Date(SY.pending.backup.made).toLocaleString())}</p>
               <div class="sy-btns"><button class="btn primary" data-sy-restore>Restore it</button><button class="btn" data-sy-cancel>Cancel</button></div>`
            : `<label class="btn sy-file">${icon('upload', 15)}Choose backup file<input type="file" id="sy-file" accept=".json,application/json" hidden></label>`}
        </div>
      </div>
      ${SY.msg ? `<p class="sy-msg">${esc(SY.msg)}</p>` : ''}
    </section>`;
  }

  main.addEventListener('click', async (e) => {
    if (!on('export')) return;
    const b = e.target.closest('button');
    if (!b) return;
    if ('syNow' in b.dataset) {
      SY.busy = true; SY.msg = ''; ctx().rerender();
      try { SY.status = await send({ type: 'syncNow' }); SY.msg = 'Synced.'; } catch (err) { SY.msg = `Sync failed: ${err.message}`; }
      SY.busy = false; ctx().rerender();
    } else if ('syBackup' in b.dataset) {
      SY.busy = true; ctx().rerender();
      try {
        const data = await send({ type: 'backup' });
        const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `roscout-backup-${new Date().toISOString().slice(0, 10)}.json`;
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(a.href), 4000);
        SY.msg = `Backup saved (${(blob.size / 1048576).toFixed(1)} MB).`;
      } catch (err) { SY.msg = `Backup failed: ${err.message}`; }
      SY.busy = false; ctx().rerender();
    } else if ('syCancel' in b.dataset) { SY.pending = null; ctx().rerender(); }
    else if ('syRestore' in b.dataset) {
      SY.busy = true;
      try {
        const r = await send({ type: 'restore', backup: SY.pending.backup });
        SY.msg = `Restored ${r.keys} items. Reopen RoScout pages to see everything.`;
        SY.pending = null;
        await ctx().reloadGames();
        SY.status = null;
      } catch (err) { SY.msg = `Restore failed: ${err.message}`; }
      SY.busy = false; ctx().rerender();
    }
  });
  main.addEventListener('change', async (e) => {
    if (!on('export') || e.target.id !== 'sy-file' || !e.target.files?.[0]) return;
    const f = e.target.files[0];
    try {
      const backup = JSON.parse(await f.text());
      if (backup?.roscoutBackup !== 1) throw new Error("that file isn't a RoScout backup");
      SY.pending = { name: f.name, backup }; SY.msg = '';
    } catch (err) { SY.msg = `Can't use that file: ${err.message}`; }
    ctx().rerender();
  });

  globalThis.RSPages = {
    rising: { render: (entered) => { if (entered && RZ.data && Date.now() - RZ.data.scanned > 5 * 60e3) loadRising(); renderRising(); } },
    rivals: { render: (entered) => { if (entered) RV.data = null; renderRivals(); }, leave: () => { RV.chart?.destroy(); RV.chart = null; } },
    requests: { render: (entered) => { if (entered) FR.data = null; renderRequests(); } },
    syncHTML,
  };
})();
