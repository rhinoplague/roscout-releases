// Shared helpers for the content panel and the popup.
// Snapshot format: [time, playing, visits, favorites, upVotes, downVotes]
(() => {
  const compact = new Intl.NumberFormat('en', { notation: 'compact', maximumFractionDigits: 1 });
  const full = new Intl.NumberFormat('en');

  const esc = (s) =>
    String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const fmt = (n) => (Number.isFinite(n) ? compact.format(n) : '—');
  const fmtFull = (n) => (Number.isFinite(n) ? full.format(Math.round(n)) : '—');
  const pct = (x, digits = 1) => (Number.isFinite(x) ? `${(x * 100).toFixed(digits)}%` : '—');

  function ago(input) {
    const t = typeof input === 'number' ? input : Date.parse(input);
    if (!Number.isFinite(t)) return '—';
    const s = Math.max(0, (Date.now() - t) / 1000);
    const steps = [
      [60, 'second'], [60, 'minute'], [24, 'hour'], [30.44, 'day'], [12, 'month'], [Infinity, 'year'],
    ];
    let v = s;
    for (const [size, unit] of steps) {
      if (v < size) {
        const n = Math.floor(v);
        if (unit === 'second') return 'just now';
        return `${n} ${unit}${n === 1 ? '' : 's'} ago`;
      }
      v /= size;
    }
    return '—';
  }

  // Visits/day from snapshots: compares the latest snapshot to the one closest
  // to 24h earlier (needs at least 1h of history).
  function recentRate(history) {
    if (!history || history.length < 2) return null;
    const latest = history[history.length - 1];
    const target = latest[0] - 864e5;
    let best = null;
    for (const s of history) {
      if (latest[0] - s[0] < 36e5) break;
      if (!best || Math.abs(s[0] - target) < Math.abs(best[0] - target)) best = s;
    }
    if (!best) return null;
    const ms = latest[0] - best[0];
    return { perDay: ((latest[2] - best[2]) / ms) * 864e5, hours: ms / 36e5 };
  }

  function ratioClass(r) {
    if (!Number.isFinite(r)) return '';
    return r >= 0.85 ? 'rs-good' : r >= 0.7 ? 'rs-ok' : 'rs-bad';
  }

  // points: [[t, value], ...] -> inline SVG sparkline
  // Small trend line in the Roblox-charts style: smooth line, soft fill, dot on the latest value.
  let sparkId = 0;
  function sparkline(points, w = 300, h = 60, color = '#2b8cff') {
    if (!points || points.length < 2) return '';
    let t0 = Infinity, t1 = -Infinity, v0 = Infinity, v1 = -Infinity;
    for (const [t, v] of points) {
      if (t < t0) t0 = t; if (t > t1) t1 = t;
      if (v < v0) v0 = v; if (v > v1) v1 = v;
    }
    const pad = 4;
    const x = (t) => pad / 2 + ((t - t0) / (t1 - t0 || 1)) * (w - pad * 1.5);
    const y = (v) => h - 3 - ((v - v0) / (v1 - v0 || 1)) * (h - 8);
    const pts = points.map(([t, v]) => [x(t), y(v)]);
    // Catmull-Rom → cubic Bézier for a smooth line
    let d = `M${pts[0][0].toFixed(1)},${pts[0][1].toFixed(1)}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
      const c1 = [p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6];
      const c2 = [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6];
      d += ` C${c1[0].toFixed(1)},${Math.min(h, c1[1]).toFixed(1)} ${c2[0].toFixed(1)},${Math.min(h, c2[1]).toFixed(1)} ${p2[0].toFixed(1)},${p2[1].toFixed(1)}`;
    }
    const id = `rsspk${++sparkId}`;
    const [lx, ly] = pts.at(-1);
    return `<svg class="rs-spark" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true">
      <defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="${color}" stop-opacity=".32"/><stop offset="100%" stop-color="${color}" stop-opacity="0"/></linearGradient></defs>
      <path d="${d} L${lx.toFixed(1)},${h} L${pts[0][0].toFixed(1)},${h} Z" fill="url(#${id})" stroke="none"/>
      <path class="rs-spark-line" d="${d}" stroke="${color}" fill="none" vector-effect="non-scaling-stroke"/>
      <circle cx="${lx.toFixed(1)}" cy="${ly.toFixed(1)}" r="2.6" fill="${color}" stroke="#15171c" stroke-width="1.2" vector-effect="non-scaling-stroke"/>
    </svg>`;
  }

  // ---- Revenue estimate ----------------------------------------------------
  // Default R$/player-hour comes from Roblox's Q2 2026 results: $363M DevEx fees
  // ÷ 29B engagement hours ≈ $0.0125/hr ≈ 3.3 R$/hr at the $0.0038 DevEx rate.
  const DEFAULT_SETTINGS = { rph: 3.3, devex: 0.0038, alertSpikes: true, spikeX: 2, alertUpdates: true, profileCard: true, usePasses: true, tileStats: true, tileRevenue: true, mostPlayed: true, alertRivals: true };
  const DEVEX_RATES = [
    { value: 0.0038, label: '$0.0038 — standard rate' },
    { value: 0.0054, label: '$0.0054 — 18+ verified US spend' },
    { value: 0.0035, label: '$0.0035 — Robux earned before Sep 2025' },
  ];

  async function getSettings() {
    try {
      const { settings } = await chrome.storage.sync.get('settings');
      return { ...DEFAULT_SETTINGS, ...(settings || {}) };
    } catch {
      return { ...DEFAULT_SETTINGS };
    }
  }

  // Time-weighted average concurrent players over the last 24h of snapshots.
  // Falls back to the current count when there's less than 6h of history.
  function avgConcurrent(history, current) {
    const now = Date.now();
    const pts = (history || []).filter((p) => p[0] >= now - 864e5);
    if (pts.length >= 2 && pts.at(-1)[0] - pts[0][0] >= 6 * 36e5) {
      let area = 0;
      for (let i = 1; i < pts.length; i++) area += ((pts[i][1] + pts[i - 1][1]) / 2) * (pts[i][0] - pts[i - 1][0]);
      return { avg: area / (pts.at(-1)[0] - pts[0][0]), measured: true };
    }
    return { avg: current || 0, measured: false };
  }

  function estimateRevenue(avgPlayers, { rph, devex }) {
    const hoursPerDay = avgPlayers * 24;
    const robuxDay = hoursPerDay * rph;
    return {
      hoursPerDay,
      robuxDay,
      usdDay: robuxDay * devex,
      robuxMonth: robuxDay * 30,
      usdMonth: robuxDay * 30 * devex,
      lowDay: robuxDay * 0.5,   // genre/monetization spread: ½× to 2× platform avg
      highDay: robuxDay * 2,
    };
  }

  // ---- Revenue series from daily player-hour aggregates ---------------------
  const dayKey = (t) => {
    const d = new Date(t);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };
  const parseDay = (k) => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
  const MIN_COVER_H = 0.5;

  function dayValue(days, k, { rph, devex }) {
    const e = days?.[k];
    if (!e || e[1] < MIN_COVER_H) return null;
    const avg = e[0] / e[1];
    const robux = avg * 24 * rph;
    return { avg, robux, usd: robux * devex, hours: e[1] };
  }

  function revenueSeries(days, settings, mode = 'daily') {
    days = days || {};
    const now = new Date();
    const todayKey = dayKey(now.getTime());
    const keys = Object.keys(days).filter((k) => days[k][1] >= MIN_COVER_H).sort();

    if (mode === 'daily') {
      const today0 = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      let start = new Date(today0); start.setDate(start.getDate() - 29);
      if (keys.length && parseDay(keys[0]) > start) start = parseDay(keys[0]);
      const minStart = new Date(today0); minStart.setDate(minStart.getDate() - 6);
      if (start > minStart) start = minStart;
      const out = [];
      for (const d = new Date(start); d <= today0; d.setDate(d.getDate() + 1)) {
        const k = dayKey(d.getTime());
        const v = dayValue(days, k, settings);
        out.push({
          key: k,
          short: d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
          long: d.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' }),
          today: k === todayKey,
          empty: !v,
          partial: !!v && v.hours < 20 && k !== todayKey,
          ...(v || {}),
        });
      }
      return out;
    }

    // monthly: projected month totals from the average of days with data
    const byMonth = {};
    for (const k of keys) {
      const v = dayValue(days, k, settings);
      if (v) (byMonth[k.slice(0, 7)] ||= []).push(v.robux);
    }
    const cur = new Date(now.getFullYear(), now.getMonth(), 1);
    let start = new Date(cur); start.setMonth(start.getMonth() - 11);
    if (keys.length) {
      const first = parseDay(keys[0]);
      const fm = new Date(first.getFullYear(), first.getMonth(), 1);
      if (fm > start) start = fm;
    }
    const min = new Date(cur); min.setMonth(min.getMonth() - 2);
    if (start > min) start = min;
    const out = [];
    for (const d = new Date(start); d <= cur; d.setMonth(d.getMonth() + 1)) {
      const m = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const vals = byMonth[m] || [];
      const dim = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
      const avgDaily = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
      const robux = avgDaily * dim;
      out.push({
        key: m,
        short: d.toLocaleDateString(undefined, { month: 'short' }),
        long: d.toLocaleDateString(undefined, { month: 'long', year: 'numeric' }),
        today: d.getTime() === cur.getTime(),
        empty: !vals.length,
        partial: vals.length > 0 && vals.length < dim,
        dataDays: vals.length,
        daysInMonth: dim,
        avgDaily,
        robux,
        usd: robux * settings.devex,
      });
    }
    return out;
  }

  // Average Robux/day over the last 7 days that have ≥ 6h of data;
  // falls back to the current-players estimate when there's none.
  function revenueSummary(days, settings, fallbackPlayers) {
    const vals = [];
    for (let i = 0; i < 7; i++) {
      const v = dayValue(days, dayKey(Date.now() - i * 864e5), settings);
      if (v && v.hours >= 6) vals.push(v.robux);
    }
    const robuxDay = vals.length
      ? vals.reduce((a, b) => a + b, 0) / vals.length
      : fallbackPlayers * 24 * settings.rph;
    return { robuxDay, usdDay: robuxDay * settings.devex, measuredDays: vals.length };
  }

  function niceMax(v) {
    if (!(v > 0)) return 1;
    const p = 10 ** Math.floor(Math.log10(v));
    for (const m of [1, 1.2, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10]) if (m * p >= v) return m * p;
    return 10 * p;
  }

  // ---- Update impact ----------------------------------------------------------
  // Compares average players in the 24h after an update to the 24h before.
  // Needs ≥12h of data on each side; returns { pct, pending } or null.
  function updateImpact(history, t) {
    if (!history?.length) return null;
    const side = (a, b) => {
      const pts = history.filter((s) => s[0] >= a && s[0] < b);
      if (pts.length < 2 || pts.at(-1)[0] - pts[0][0] < 12 * 36e5) return null;
      return pts.reduce((x, s) => x + s[1], 0) / pts.length;
    };
    const before = side(t - 864e5, t);
    if (before == null) return null;
    const after = side(t, t + 864e5);
    if (after == null) return Date.now() - t < 864e5 ? { pending: true } : null;
    return { pct: before ? (after - before) / before : 0, before, after };
  }

  const impactText = (imp) =>
    !imp ? '' : imp.pending ? 'measuring impact…' : `${imp.pct >= 0 ? '+' : ''}${(imp.pct * 100).toFixed(0)}% players next 24h`;

  // ---- Heatmap (hour of week) ------------------------------------------------
  const DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const hourLabel = (h) => `${((h + 11) % 12) + 1}${h < 12 ? 'a' : 'p'}`;
  const hourLong = (h) => `${((h + 11) % 12) + 1} ${h < 12 ? 'AM' : 'PM'}`;

  function heatmapStats(hm) {
    if (!hm) return null;
    const cells = hm.map((b, i) => ({ i, day: Math.floor(i / 24), hour: i % 24, avg: b[1] ? b[0] / b[1] : null, n: b[1] }));
    const filled = cells.filter((c) => c.avg != null);
    if (filled.length < 12) return { cells, filled: filled.length, ready: false };
    const peak = filled.reduce((a, c) => (c.avg > a.avg ? c : a));
    const low = filled.reduce((a, c) => (c.avg < a.avg ? c : a));
    // best day = highest daily average among days with ≥ 12 filled hours
    const days = DOW.map((_, d) => {
      const ds = filled.filter((c) => c.day === d);
      return { d, avg: ds.length >= 12 ? ds.reduce((x, c) => x + c.avg, 0) / ds.length : null };
    }).filter((x) => x.avg != null);
    const bestDay = days.length ? days.reduce((a, x) => (x.avg > a.avg ? x : a)) : null;
    return { cells, filled: filled.length, ready: true, peak, low, bestDay, max: peak.avg };
  }

  // Monday-first grid. Returns HTML (uses .rs-hm* classes from content.css / dashboard.css).
  function heatmapHTML(hm) {
    const st = heatmapStats(hm);
    if (!st || !st.filled) return '<p class="rs-hint">No hourly data yet — track this game and the week map fills in as RoScout records it.</p>';
    const order = [1, 2, 3, 4, 5, 6, 0];
    const max = st.ready ? st.max : Math.max(...st.cells.filter((c) => c.avg != null).map((c) => c.avg));
    const rows = order.map((d) => {
      const cells = Array.from({ length: 24 }, (_, h) => {
        const c = st.cells[d * 24 + h];
        if (c.avg == null) return `<i class="rs-hm-cell rs-hm-none" data-tip="${DOW[d]} ${hourLong(h)} · no data"></i>`;
        const a = 0.08 + 0.92 * (c.avg / (max || 1));
        const peak = st.ready && c.i === st.peak.i ? ' rs-hm-peak' : '';
        return `<i class="rs-hm-cell${peak}" style="--a:${a.toFixed(2)}" data-tip="${DOW[d]} ${hourLong(h)} · ${compact.format(c.avg)} avg players"></i>`;
      }).join('');
      return `<span class="rs-hm-day">${DOW[d]}</span>${cells}`;
    }).join('');
    const hours = Array.from({ length: 24 }, (_, h) => `<span>${h % 3 === 0 ? hourLabel(h) : ''}</span>`).join('');
    let insight = '';
    if (st.ready) {
      const lead = (st.peak.hour + 22) % 24; // ~2h before peak
      insight = `<div class="rs-hm-insight">
        <div><b>Peak</b> ${DOW[st.peak.day]} ${hourLong(st.peak.hour)} · ${compact.format(st.peak.avg)} players</div>
        <div><b>Quietest</b> ${DOW[st.low.day]} ${hourLong(st.low.hour)} · ${compact.format(st.low.avg)}</div>
        ${st.bestDay ? `<div><b>Best day</b> ${DOW[st.bestDay.d]}</div>` : ''}
        <div class="rs-hm-tip">💡 Ship updates around <b>${DOW[st.peak.day]} ${hourLong(lead)}</b> so they're live before the peak.</div>
      </div>`;
    } else {
      insight = `<p class="rs-hint">Still learning — ${st.filled} of 168 hours recorded. Insights appear after ~12 hours of data.</p>`;
    }
    return `<div class="rs-hm"><div class="rs-hm-grid">${rows}<span></span>${hours}</div><div class="rs-hm-readout">Hover a cell to see average players at that hour.</div>${insight}</div>`;
  }

  // ---- Misc ------------------------------------------------------------------
  function fmtDur(ms) {
    const m = Math.max(0, Math.round(ms / 60000));
    if (m < 60) return `${m}m`;
    const h = Math.floor(m / 60);
    return h < 24 ? `${h}h ${m % 60}m` : `${Math.floor(h / 24)}d ${h % 24}h`;
  }

  const PALETTE = ['#3ddc84', '#5aa9ff', '#f5c242', '#ff7ab6', '#b48cff', '#ff9a4d', '#4fe0d6', '#e8e8e8'];

  function toCSV(rows) {
    return rows.map((r) => r.map((v) => {
      const s = v == null ? '' : String(v);
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    }).join(',')).join('\r\n');
  }

  function downloadCSV(filename, rows) {
    const blob = new Blob(['﻿' + toCSV(rows)], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  }

  const usd = (n) => (!Number.isFinite(n) ? '—' : n < 10 ? `$${n.toFixed(2)}` : n < 1000 ? `$${Math.round(n)}` : `$${compact.format(n)}`);
  const robux = (n) => (Number.isFinite(n) ? `R$ ${compact.format(n)}` : '—');

  // ---- Monetization model (game passes) --------------------------------------
  // The base rate (R$ per player-hour) is the platform average. Games with a
  // bigger / pricier pass catalog tend to earn more per player-hour, games with
  // none earn less. Reference point (×1.00): ~6 passes, median R$ 150.
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  function monetization(prices, settings) {
    if (settings && settings.usePasses === false) return { mult: 1, used: false, off: true };
    if (!Array.isArray(prices)) return { mult: 1, used: false };
    const p = prices.filter((x) => x > 0).sort((a, b) => a - b);
    const n = p.length;
    if (!n) return { mult: 0.6, used: true, n: 0, note: 'No game passes for sale' };
    const median = n % 2 ? p[(n - 1) / 2] : (p[n / 2 - 1] + p[n / 2]) / 2;
    const countF = clamp(1 + 0.25 * Math.log2((1 + n) / 7), 0.6, 1.6);
    const priceF = clamp(Math.pow(median / 150, 0.2), 0.85, 1.2);
    const highF = p[n - 1] >= 1000 ? 1.08 : 1;
    const mult = Math.round(clamp(countF * priceF * highF, 0.55, 2) * 100) / 100;
    return { mult, used: true, n, median, min: p[0], max: p[n - 1], total: p.reduce((a, b) => a + b, 0) };
  }
  const withMon = (settings, mon) => ({ ...settings, rph: settings.rph * (mon?.mult ?? 1) });
  function monText(mon) {
    if (!mon || !mon.used) return mon?.off ? 'Game passes ignored (turned off in settings)' : 'Game passes not loaded yet';
    if (!mon.n) return `×${mon.mult.toFixed(2)} · no game passes for sale`;
    return `×${mon.mult.toFixed(2)} · ${mon.n} pass${mon.n === 1 ? '' : 'es'}, median R$ ${fmtFull(mon.median)}, top R$ ${fmtFull(mon.max)}`;
  }

  // ---- Icons (24×24 stroke icons, drawn for RoScout) --------------------------
  const ICON_PATHS = {
    users: '<path d="M16 20v-1.5a3.5 3.5 0 0 0-3.5-3.5h-5A3.5 3.5 0 0 0 4 18.5V20"/><circle cx="10" cy="8" r="3.5"/><path d="M20 20v-1.5a3.5 3.5 0 0 0-2.5-3.35M15.5 4.6a3.5 3.5 0 0 1 0 6.8"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M5 20a7 7 0 0 1 14 0"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    heart: '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>',
    thumb: '<path d="M7 11v9H4v-9h3zM7 11l4-8a2 2 0 0 1 2 2v4h5.5a2 2 0 0 1 2 2.3l-1.2 7A2 2 0 0 1 17.3 20H7"/>',
    server: '<rect x="3" y="4" width="18" height="7" rx="2"/><rect x="3" y="13" width="18" height="7" rx="2"/><path d="M7 7.5h.01M7 16.5h.01"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    cake: '<path d="M4 20h16v-7a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v7z"/><path d="M4 15c2 1.5 4 1.5 6 0s4-1.5 6 0 4 1.5 4 0M12 11V7M12 4v.01"/>',
    trend: '<path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/>',
    ticket: '<path d="M3 8a2 2 0 0 0 2-2h14a2 2 0 0 0 2 2v2a2 2 0 0 0 0 4v2a2 2 0 0 0-2 2H5a2 2 0 0 0-2-2v-2a2 2 0 0 0 0-4V8z"/><path d="M14 6v12" stroke-dasharray="2 2"/>',
    award: '<circle cx="12" cy="9" r="6"/><path d="M8.5 14L7 22l5-3 5 3-1.5-8"/>',
    coins: '<circle cx="9" cy="9" r="6"/><path d="M15.5 9.2A6 6 0 1 1 9.2 15.5"/><path d="M9 6.5v5M7 9h4"/>',
    layers: '<path d="M12 3l9 5-9 5-9-5 9-5z"/><path d="M3 13l9 5 9-5"/>',
    building: '<rect x="4" y="3" width="16" height="18" rx="1.5"/><path d="M9 7h1M14 7h1M9 11h1M14 11h1M9 15h1M14 15h1M10 21v-3h4v3"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
    chevron: '<path d="M9 6l6 6-6 6"/>',
    down: '<path d="M6 9l6 6 6-6"/>',
    refresh: '<path d="M20 11a8 8 0 0 0-14.3-4.9L4 8M4 4v4h4M4 13a8 8 0 0 0 14.3 4.9L20 16M20 20v-4h-4"/>',
    star: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9L12 3z"/>',
    sparkle: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M6 18l2.5-2.5M15.5 8.5L18 6"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
    external: '<path d="M14 4h6v6M20 4l-9 9"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
    lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
    crown: '<path d="M3 8l4 4 5-7 5 7 4-4-2 11H5L3 8z"/>',
    gamepad: '<rect x="2" y="7" width="20" height="11" rx="5"/><path d="M7 11v3M5.5 12.5h3M16 12h.01M18 14h.01"/>',
    swords: '<path d="M14.5 17.5L3 6V3h3l11.5 11.5M13 19l6-6M16 16l4 4M19 21l2-2"/><path d="M9.5 6.5L13 3h3v3l-3.5 3.5M5 14l4 4M7 21l-2-2-2 2"/>',
    image: '<rect x="3" y="4" width="18" height="16" rx="2.5"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-9 9"/>',
    flame: '<path d="M12 21c4 0 7-2.8 7-7 0-3.5-2.2-5.6-4-7.5-.4 2-1.4 3.3-3 4C12 7 10.5 4.5 8 3c.3 3-1.5 5-3 7-1 1.3-1 2.6-1 4 0 4.2 3 7 7 7z"/>',
    bell: '<path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4l2-2z"/><path d="M10 20a2 2 0 0 0 4 0"/>',
    userplus: '<circle cx="10" cy="8" r="4"/><path d="M3 20a7 7 0 0 1 12.5-4.3M19 14v6M16 17h6"/>',
    sync: '<path d="M20 12a8 8 0 0 1-13.7 5.6L4 15.5M4 20v-4.5h4.5M4 12a8 8 0 0 1 13.7-5.6L20 8.5M20 4v4.5h-4.5"/>',
    download: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
    upload: '<path d="M12 20V9M7 14l5-5 5 5M5 4h14"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
  };
  const icon = (name, size = 16, cls = 'rs-ico') =>
    `<svg class="${cls}" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON_PATHS[name] || ''}</svg>`;

  function send(msg) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(msg, (res) => {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (res?.error) return reject(new Error(res.error));
        resolve(res);
      });
    });
  }

  globalThis.RS = {
    esc, fmt, fmtFull, pct, ago, recentRate, ratioClass, sparkline, send,
    DEFAULT_SETTINGS, DEVEX_RATES, getSettings, avgConcurrent, estimateRevenue, usd, robux,
    revenueSeries, revenueSummary, niceMax, monetization, withMon, monText, icon, clamp,
    updateImpact, impactText, heatmapStats, heatmapHTML, DOW, hourLong,
    fmtDur, PALETTE, toCSV, downloadCSV, dayKey,
  };
})();
