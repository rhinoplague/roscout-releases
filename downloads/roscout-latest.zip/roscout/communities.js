// RoScout communities — a cleaner community search with live stats per group,
// and a studio card on community pages (games, players right now, visits).
(() => {
  const { esc, fmt, fmtFull, pct, ago, send, icon } = globalThis.RS;

  const SEARCH_RE = /^\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?search\/(?:communities|groups)\/?$/i;
  const GROUP_RE = /^\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?(?:communities|groups)\/(\d+)/i;

  // Remember who's logged in so the dashboard can build "My communities".
  try {
    const me = Number(document.querySelector('meta[name="user-data"]')?.dataset.userid);
    if (me > 0) chrome.storage.local.set({ myUserId: me });
  } catch {}

  const waitFor = (fn, timeout = 6000) => new Promise((resolve) => {
    const f = fn(); if (f) return resolve(f);
    const obs = new MutationObserver(() => { const el = fn(); if (el) { obs.disconnect(); resolve(el); } });
    obs.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(() => { obs.disconnect(); resolve(null); }, timeout);
  });

  const statsHTML = (st) => !st ? '<span class="rsg-skel"></span>' : `
    <span class="rsg-stat" title="Players in this community's games right now">${st.playing ? '<i class="rsg-live"></i>' : ''}<b>${fmtFull(st.playing)}</b> playing</span>
    <span class="rsg-stat"><b>${fmt(st.visits)}</b> visits</span>
    <span class="rsg-stat"><b>${st.games.length}</b> game${st.games.length === 1 ? '' : 's'}</span>`;

  const topGameHTML = (st) => {
    const g = st?.games?.[0];
    if (!g) return '';
    return `<a class="rsg-top" href="/games/${g.placeId}" title="Top game: ${esc(g.name)}">
      <span class="rsg-top-icon">${g.icon ? `<img src="${esc(g.icon)}" alt="" loading="lazy">` : ''}</span>
      <span class="rsg-top-text"><span>${esc(g.name)}</span><em>${g.playing ? `${fmtFull(g.playing)} playing` : `${fmt(g.visits)} visits`}</em></span>
    </a>`;
  };

  // =====================================================================
  // Search
  // =====================================================================
  const S = { root: null, keyword: '', list: [], stats: {}, next: '', total: 0, loading: false, error: '',
    sort: 'relevance', verified: false, hasGames: false, publicOnly: false, nativeHidden: true, token: 0 };

  function sortedList() {
    let l = S.list.slice();
    if (S.verified) l = l.filter((g) => g.verified);
    if (S.publicOnly) l = l.filter((g) => g.isPublic);
    if (S.hasGames) l = l.filter((g) => S.stats[g.id]?.games?.length);
    const st = (g) => S.stats[g.id] || { playing: -1, visits: -1 };
    if (S.sort === 'members') l.sort((a, b) => b.members - a.members);
    if (S.sort === 'playing') l.sort((a, b) => st(b).playing - st(a).playing);
    if (S.sort === 'visits') l.sort((a, b) => st(b).visits - st(a).visits);
    return l;
  }

  function searchRow(g) {
    const st = S.stats[g.id];
    return `
      <article class="rsg-row">
        <a class="rsg-icon" href="/communities/${g.id}">${g.icon ? `<img src="${esc(g.icon)}" alt="" loading="lazy">` : icon('building', 24)}</a>
        <div class="rsg-main">
          <div class="rsg-title">
            <a href="/communities/${g.id}">${esc(g.name)}</a>
            ${g.verified ? `<span class="rsg-verified" title="Verified">✔</span>` : ''}
            <span class="rsg-pill ${g.isPublic ? '' : 'rsg-pill-lock'}">${icon(g.isPublic ? 'globe' : 'lock', 11)}${g.isPublic ? 'Public' : 'Private'}</span>
          </div>
          ${g.previousName && g.previousName !== g.name ? `<div class="rsg-prev">formerly ${esc(g.previousName)}</div>` : ''}
          ${g.description ? `<p class="rsg-desc">${esc(g.description)}</p>` : ''}
          <div class="rsg-stats">
            <span class="rsg-stat"><b>${fmt(g.members)}</b> members</span>
            ${statsHTML(st)}
          </div>
        </div>
        ${topGameHTML(st)}
      </article>`;
  }

  function renderSearch() {
    const r = S.root;
    if (!r) return;
    const focused = document.activeElement?.closest?.('.rsg-root');
    const list = sortedList();
    const chip = (key, val, label) => `<button class="rsg-chip ${S[key] === val ? 'rsg-on' : ''}" data-set="${key}" data-val="${val}">${label}</button>`;
    const tog = (key, label) => `<button class="rsg-chip ${S[key] ? 'rsg-on' : ''}" data-toggle="${key}" aria-pressed="${S[key]}">${label}</button>`;
    r.innerHTML = `
      <header class="rsg-head">
        <div class="rsg-brand"><span class="rs-logo" aria-hidden="true"><i></i><i></i><i></i></span>Communities
          <em>${S.total ? `${fmtFull(S.total)} results for “${esc(S.keyword)}”` : esc(S.keyword)}</em></div>
        <button class="rsg-chip rsg-native" data-act="native">${S.nativeHidden ? "Show Roblox's list" : "Hide Roblox's list"}</button>
      </header>
      <div class="rsg-controls">
        <div class="rsg-group"><span>Sort</span>
          ${chip('sort', 'relevance', 'Relevance')}${chip('sort', 'playing', 'Playing now')}${chip('sort', 'visits', 'Visits')}${chip('sort', 'members', 'Members')}
        </div>
        <div class="rsg-group"><span>Show</span>${tog('verified', 'Verified')}${tog('hasGames', 'Has games')}${tog('publicOnly', 'Public')}</div>
      </div>
      ${S.error ? `<p class="rsg-empty">RoScout couldn't search communities: ${esc(S.error)}</p>` : ''}
      <div class="rsg-list">${list.map(searchRow).join('') || (S.loading ? '' : '<p class="rsg-empty">No communities match these filters.</p>')}</div>
      ${S.loading ? '<div class="rsg-loading"><span></span><span></span><span></span></div>' : ''}
      ${S.next && !S.loading ? '<button class="rsg-more" data-act="more">Load more</button>' : ''}`;
    if (focused) r.querySelector('[data-act]')?.blur();
  }

  async function loadSearch(more = false) {
    const token = more ? S.token : ++S.token;
    S.loading = true; S.error = '';
    renderSearch();
    try {
      const res = await send({ type: 'groupSearch', keyword: S.keyword, cursor: more ? S.next : '' });
      if (token !== S.token) return;
      S.list = more ? S.list.concat(res.list) : res.list;
      S.next = res.next; S.total = res.total;
      S.loading = false;
      renderSearch();
      // fill in game stats a few groups at a time
      const ids = res.list.map((g) => g.id);
      for (let i = 0; i < ids.length; i += 5) {
        const part = await send({ type: 'groupStatsMany', ids: ids.slice(i, i + 5) });
        if (token !== S.token) return;
        Object.assign(S.stats, part);
        renderSearch();
      }
    } catch (e) {
      if (token !== S.token) return;
      S.loading = false; S.error = e.message; renderSearch();
    }
  }

  function setNative(hidden) {
    S.nativeHidden = hidden;
    const parent = S.root?.parentElement;
    if (!parent) return;
    let after = false;
    for (const el of parent.children) {
      if (el === S.root) { after = true; continue; }
      if (after) el.classList.toggle('rsg-hide-native', hidden);
    }
  }

  async function mountSearch() {
    S.keyword = new URLSearchParams(location.search).get('keyword') || '';
    if (!S.keyword) return;
    const input = await waitFor(() => document.querySelector('input[type="search"], input[placeholder*="ommunit" i], #search-input'), 5000);
    S.root = document.createElement('section');
    S.root.className = 'rsg-root';
    S.root.addEventListener('click', onSearchClick);
    // put RoScout's results right after the search box's block
    let anchor = input;
    while (anchor && anchor.parentElement && anchor.parentElement.children.length < 2) anchor = anchor.parentElement;
    if (anchor?.parentElement && anchor.parentElement !== document.body) anchor.insertAdjacentElement('afterend', S.root);
    else (document.querySelector('#content') || document.querySelector('main') || document.body).prepend(S.root);
    setNative(true);
    loadSearch();
  }

  function onSearchClick(e) {
    const b = e.target.closest('button');
    if (!b) return;
    if (b.dataset.set) { S[b.dataset.set] = b.dataset.val; renderSearch(); return; }
    if (b.dataset.toggle) { S[b.dataset.toggle] = !S[b.dataset.toggle]; renderSearch(); return; }
    if (b.dataset.act === 'more') loadSearch(true);
    if (b.dataset.act === 'native') { setNative(!S.nativeHidden); renderSearch(); }
  }

  // =====================================================================
  // Community page: studio card
  // =====================================================================
  const C = { root: null, id: null, data: null, showAll: false, tracked: new Set(), busy: new Set() };

  function renderCard() {
    const r = C.root;
    if (!r) return;
    const d = C.data;
    if (!d) { r.innerHTML = '<div class="rsg-loading"><span></span><span></span><span></span></div>'; return; }
    if (d.error) { r.innerHTML = `<p class="rsg-empty">RoScout couldn't load this community: ${esc(d.error)}</p>`; return; }
    const games = C.showAll ? d.games : d.games.slice(0, 8);
    const favs = d.games.reduce((a, g) => a + (g.favorites || 0), 0);
    r.innerHTML = `
      <header class="rsg-card-head">
        <div class="rsg-brand"><span class="rs-logo" aria-hidden="true"><i></i><i></i><i></i></span>Studio overview</div>
        <a class="rsg-chip" href="#roscout-communities">${icon('building', 13)}My communities</a>
      </header>
      <div class="rsg-kpis">
        <div><span>${icon('users', 13)}Playing now</span><b>${d.playing ? '<i class="rsg-live"></i>' : ''}${fmtFull(d.playing)}</b></div>
        <div><span>${icon('eye', 13)}Total visits</span><b>${fmt(d.visits)}</b></div>
        <div><span>${icon('gamepad', 13)}Public games</span><b>${d.games.length}</b></div>
        <div><span>${icon('heart', 13)}Favorites</span><b>${fmt(favs)}</b></div>
      </div>
      <div class="rsg-owner">${d.owner ? `Owned by <a href="/users/${d.owner.id}/profile"><b>${esc(d.owner.displayName || d.owner.name)}</b></a> · ` : ''}${fmtFull(d.members)} members · ${d.isPublic ? 'Public' : 'Private'}</div>
      ${d.games.length ? `<div class="rsg-games">${games.map((g) => `
        <div class="rsg-game">
          <a class="rsg-top-icon" href="/games/${g.placeId}">${g.icon ? `<img src="${esc(g.icon)}" alt="" loading="lazy">` : ''}</a>
          <a class="rsg-game-main" href="/games/${g.placeId}">
            <span class="rsg-game-name">${esc(g.name)}</span>
            <span class="rsg-game-sub">${fmt(g.visits)} visits${g.likes != null ? ` · ${pct(g.likes, 0)} liked` : ''} · updated ${esc(ago(g.updated))}</span>
          </a>
          ${g.playing ? `<span class="rsg-live-pill"><i class="rsg-live"></i>${fmtFull(g.playing)}</span>` : '<span class="rsg-game-sub">offline</span>'}
          <button class="rsg-track ${C.tracked.has(g.id) ? 'rsg-on' : ''}" data-track="${g.placeId}" data-uni="${g.id}" ${C.busy.has(g.id) ? 'disabled' : ''}>${icon('star', 12)}${C.tracked.has(g.id) ? 'Tracking' : 'Track'}</button>
        </div>`).join('')}</div>
        ${d.games.length > 8 ? `<button class="rsg-more" data-act="all">${C.showAll ? 'Show less' : `Show all ${d.games.length} games`}</button>` : ''}`
        : '<p class="rsg-empty">This community has no public games.</p>'}`;
  }

  async function mountCard(id) {
    C.id = id; C.data = null; C.showAll = false;
    C.root?.remove();
    C.root = document.createElement('section');
    C.root.className = 'rsg-root rsg-card';
    C.root.addEventListener('click', onCardClick);
    const anchor = await waitFor(() => document.querySelector('.group-header, [class*="community-header"], [class*="group-details"], #group-container, .group-container'), 5000);
    if (id !== C.id) return;
    if (anchor) anchor.insertAdjacentElement('afterend', C.root);
    else (document.querySelector('#content') || document.querySelector('main') || document.body).prepend(C.root);
    renderCard();
    try {
      const [d, tr] = await Promise.all([send({ type: 'groupCard', groupId: id }), chrome.storage.local.get('tracked')]);
      if (id !== C.id) return;
      C.data = d;
      C.tracked = new Set(Object.keys(tr.tracked || {}).map(Number));
    } catch (e) { C.data = { error: e.message }; }
    renderCard();
  }

  async function onCardClick(e) {
    const b = e.target.closest('button');
    if (!b) return;
    if (b.dataset.act === 'all') { C.showAll = !C.showAll; renderCard(); return; }
    if (b.dataset.track) {
      const uni = Number(b.dataset.uni);
      C.busy.add(uni); renderCard();
      try {
        if (C.tracked.has(uni)) { await send({ type: 'untrack', universeId: uni }); C.tracked.delete(uni); }
        else { await send({ type: 'trackPlace', placeId: Number(b.dataset.track) }); C.tracked.add(uni); }
      } catch {}
      C.busy.delete(uni); renderCard();
    }
  }

  // =====================================================================
  let lastPath = '';
  async function check() {
    const key = location.pathname + location.search;
    if (key === lastPath) {
      if (S.root && !S.root.isConnected && SEARCH_RE.test(location.pathname)) mountSearch();
      return;
    }
    lastPath = key;
    S.root?.remove(); S.root = null;
    if (SEARCH_RE.test(location.pathname)) { mountSearch(); return; }
    const gid = Number(location.pathname.match(GROUP_RE)?.[1]) || null;
    if (gid) { if (gid !== C.id || !C.root?.isConnected) mountCard(gid); }
    else { C.root?.remove(); C.root = null; C.id = null; }
  }
  check();
  setInterval(check, 1000);
})();
