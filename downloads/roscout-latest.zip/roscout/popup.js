// RoScout popup — tracked games at a glance.
(() => {
  const {
    esc, fmt, pct, ago, recentRate, ratioClass, sparkline, send,
    DEFAULT_SETTINGS, DEVEX_RATES, getSettings, avgConcurrent, revenueSummary, usd, monetization, withMon,
  } = globalThis.RS;
  const list = document.getElementById('list');
  const foot = document.getElementById('foot');
  const refreshBtn = document.getElementById('refresh');
  const rphInput = document.getElementById('rph');
  const devexSelect = document.getElementById('devex');
  let settings = { ...DEFAULT_SETTINGS };
  let lastData = null;

  devexSelect.innerHTML = DEVEX_RATES.map((r) => `<option value="${r.value}">${esc(r.label)}</option>`).join('');

  const alertSpikes = document.getElementById('alertSpikes');
  const spikeX = document.getElementById('spikeX');
  const alertUpdates = document.getElementById('alertUpdates');
  const profileCard = document.getElementById('profileCard');
  const usePasses = document.getElementById('usePasses');
  usePasses.addEventListener('change', () => saveSettings({ ...settings, usePasses: usePasses.checked }));
  profileCard.addEventListener('change', () => saveSettings({ ...settings, profileCard: profileCard.checked }));

  function showSettings() {
    rphInput.value = settings.rph;
    devexSelect.value = String(settings.devex);
    alertSpikes.checked = !!settings.alertSpikes;
    spikeX.value = String(settings.spikeX);
    spikeX.disabled = !settings.alertSpikes;
    alertUpdates.checked = !!settings.alertUpdates;
    profileCard.checked = settings.profileCard !== false;
    usePasses.checked = settings.usePasses !== false;
  }

  alertSpikes.addEventListener('change', () => { saveSettings({ ...settings, alertSpikes: alertSpikes.checked }); showSettings(); });
  spikeX.addEventListener('change', () => saveSettings({ ...settings, spikeX: parseFloat(spikeX.value) }));
  alertUpdates.addEventListener('change', () => saveSettings({ ...settings, alertUpdates: alertUpdates.checked }));
  // Open the RoScout window on roblox.com: in the current tab if it's Roblox, otherwise a new one.
  async function openWindow(tab) {
    try {
      const [cur] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (cur?.url?.startsWith('https://www.roblox.com/')) {
        await chrome.tabs.sendMessage(cur.id, { type: 'rs-open-window', tab });
        window.close();
        return;
      }
    } catch {}
    chrome.tabs.create({ url: `https://www.roblox.com/home#roscout-${tab}` });
    window.close();
  }
  document.getElementById('appearance').addEventListener('click', () => openWindow('appearance'));
  document.getElementById('dash').addEventListener('click', () => {
    openWindow('compare');
  });

  async function saveSettings(next) {
    settings = next;
    await chrome.storage.sync.set({ settings });
    if (lastData) render(lastData);
  }

  rphInput.addEventListener('change', () => {
    const v = parseFloat(rphInput.value);
    if (Number.isFinite(v) && v >= 0) saveSettings({ ...settings, rph: v });
    else showSettings();
  });
  devexSelect.addEventListener('change', () => saveSettings({ ...settings, devex: parseFloat(devexSelect.value) }));
  document.getElementById('reset').addEventListener('click', () => {
    saveSettings({ ...settings, rph: DEFAULT_SETTINGS.rph, devex: DEFAULT_SETTINGS.devex }); showSettings();
  });

  function row(g) {
    const h = g.history;
    const last = h.at(-1);
    const day = h.filter((p) => p[0] >= Date.now() - 864e5).map((p) => [p[0], p[1]]);
    const up = last?.[4] || 0, down = last?.[5] || 0;
    const ratio = up + down ? up / (up + down) : NaN;
    const rate = recentRate(h);
    const rev = revenueSummary(g.days, withMon(settings, monetization(g.passPrices, settings)), avgConcurrent(h, last?.[1]).avg);
    return `
      <article class="row">
        <div class="row-top">
          <a class="name" href="https://www.roblox.com/games/${encodeURIComponent(g.placeId)}" target="_blank" rel="noopener" title="${esc(g.name)}">${esc(g.name || 'Untitled')}</a>
          <button class="x" data-untrack="${g.universeId}" title="Stop tracking">×</button>
        </div>
        ${g.creator?.name ? `<div class="by">by ${esc(g.creator.name)} · ${g.creator.type === 'Group' ? 'Group' : 'Solo dev'}</div>` : ''}
        <div class="stats">
          <span><b class="live">${fmt(last?.[1])}</b> playing</span>
          <span><b class="${ratioClass(ratio)}">${pct(ratio, 0)}</b> likes</span>
          <span><b>${rate ? fmt(rate.perDay) : '—'}</b> visits/day</span>
          <span title="Estimated DevEx value per day"><b class="money">≈${usd(rev.usdDay)}</b>/day</span>
        </div>
        ${day.length >= 2 ? sparkline(day, 300, 36) : '<div class="nodata">Chart appears after a couple of polls</div>'}
      </article>`;
  }

  function render({ games, lastPoll }) {
    lastData = { games, lastPoll };
    if (!games.length) {
      list.innerHTML = `<div class="empty"><b>No tracked games yet.</b><br>Open any game on roblox.com and hit <b>☆ Track</b> in the RoScout panel.</div>`;
    } else {
      list.innerHTML = games.map(row).join('');
    }
    foot.textContent = `${games.length} tracked · polls every 15 min${lastPoll ? ` · last ${ago(lastPoll)}` : ''}`;
  }

  async function load(type = 'getTracked') {
    try { render(await send({ type })); }
    catch (e) { list.innerHTML = `<div class="empty err">${esc(e.message)}</div>`; }
  }

  list.addEventListener('click', async (e) => {
    const id = e.target.closest('[data-untrack]')?.dataset.untrack;
    if (!id) return;
    await send({ type: 'untrack', universeId: Number(id) });
    load();
  });

  refreshBtn.addEventListener('click', async () => {
    refreshBtn.disabled = true;
    refreshBtn.textContent = '…';
    await load('pollNow');
    refreshBtn.disabled = false;
    refreshBtn.textContent = '↻';
  });

  getSettings().then((s) => { settings = s; showSettings(); load(); });

  // Update banner (unpacked installs). Store installs update themselves.
  const upd = document.getElementById('update');
  function showUpdate(info) {
    if (!info || info.store || !info.available) { upd.hidden = true; return; }
    const notes = (info.notes || []).slice(0, 3).map((n) => `<li>${esc(n)}</li>`).join('');
    upd.innerHTML = `
      <div class="update-top"><b>RoScout ${esc(info.latest)} is out</b><span>You have ${esc(info.current)}</span></div>
      ${notes ? `<ul>${notes}</ul>` : ''}
      ${info.download ? `<a class="btn primary" href="${esc(info.download)}" target="_blank" rel="noopener">Download update</a>` : ''}
      <p>Unzip it over your RoScout folder, then click reload on RoScout in chrome://extensions.</p>`;
    upd.hidden = false;
  }
  send({ type: 'getUpdateInfo' }).then((i) => {
    showUpdate(i);
    if (!i.store && (!i.checked || Date.now() - i.checked > 30 * 60 * 1000)) send({ type: 'checkUpdate' }).then(showUpdate).catch(() => {});
  }).catch(() => {});
})();
